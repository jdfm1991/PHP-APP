Create View dbo.VW_ADM_ITEMSFACTURA AS 
Select it.CodSucu, it.TipoFac, it.NumeroD, it.coditem, it.signo,
       (case when it.esserv=0 then pr.codinst else sr.codinst end) as CodInst,
       it.Descrip1, it.Descrip2,it.Descrip3, it.Descrip4, it.Descrip5, 
       it.Descrip6, it.Descrip7, it.Descrip8,it.Descrip9, it.Descrip10, 
       it.nrolinea, it.nrolineac, it.EsServ,
       F.CodOper,F.CodClie,F.CodVend,F.CodUsua,F.CodEsta,it.CodMeca, 
       F.Signo*it.priceO as PriceO, F.Signo*it.mtoTax As MtoTax, F.Signo*it.precio as Precio,
       F.Signo*it.Cantidad*(IT.Precio-ISNULL((F.Descto1+F.Descto2)*IT.Precio/NULLIF(F.Monto,0),0)) as TotPrecio,
       F.Signo*IT.Cantidad*((IT.Precio-ISNULL((F.Descto1+F.Descto2)*IT.Precio/NULLIF(F.Monto,0),0))-IT.Costo) as Utilidad,
       it.EsUnid, it.DEsComp, it.EsExento, it.CantMayor, F.Signo*it.Cantidad As Cantidad,
       it.CantidadA, it.codUbic, it.nroUnicoL, It.Descto,
       F.Signo*it.Costo As Costo, F.Signo*It.Cantidad*it.Costo As TotCosto, ISNULL(it.NroLote,'') As NroLote,
       it.fechaL, it.Fechav AS FechaVL, F.FechaE AS FechaEF, F.Fechav  AS FechaVF,
       (CASE SUBSTRING((Case when it.esserv=0 Then PR.DESCRIP else sr.descrip end),1,1) WHEN '?' THEN 1 ELSE 0 END) AS ESFREEP,
       (Case when it.esserv=0 Then
           (case it.esunid When 0 Then pr.Existen Else pr.ExUnidad End)
        Else 0 End) as ExActual,
    (Case when it.esserv=0 Then pr.DEsLote else 0 end) As DEsLote,
    (Case when it.esserv=0 Then pr.DEsSeri else 0 end) As DEsSeri,
    (Case when it.esserv=0 Then Pr.DEsVence else 0 end) As DEsVence,
    (Case when it.esserv=0 Then pr.EsPesa else 0 end) As EsPesa,
    (Case when it.esserv=0 Then pr.tara else 0 end) As Tara,
    (Case when it.esserv=0 Then pr.Unidad else sr.Unidad end) As Unidad,
    (Case when it.esserv=0 Then pr.undempaq else '' end) As UndEmpaq,
    (Case when it.esserv=0 Then pr.cantempaq else 0 end) As CantEmpaq,
    (Case when it.esserv=0 Then pr.exdecimal else 0 end) As ExDecimal,
    (Case when it.esserv=0 Then pr.refere else sr.clase end) As Refere,
    (Case when it.esserv=0 Then pr.precio1 else sr.precio1 end) As Precio1,
    (Case when it.esserv=0 Then pr.precio2 else sr.precio2 end) As Precio2,
    (Case when it.esserv=0 Then pr.precio3 else sr.precio3 end) As Precio3,
    (Case when it.esserv=0 Then Pr.precioU else 0 end) As PrecioU,
    (Case when it.esserv=0 Then PR.Preciou2 else 0 end) As PrecioU2,
    (Case when it.esserv=0 Then PR.Preciou3 else 0 end) As PrecioU3,
    (Case when it.esserv=0 Then PR.Peso else 0 end) As Peso,
    (Case when it.esserv=0 Then PR.Volumen else 0 end) As Volumen,
    (Case when it.esserv=0 Then PR.UndVol else '' end) As UndVol,
    (Case when it.esserv=0 Then pr.costpro else sr.costo end) As CostPro,
    (Case when it.esserv=0 Then pr.costAct else sr.costo end) As CostAct,
    (Case when it.esserv=0 Then pr.esImport else sr.EsImport end) As EsImport,
    (Case when it.esserv=0 Then 0 else sr.UsaServ end) As UsaServ
  FROM saitemfac it WITH (NOLOCK)
 INNER JOIN SAFACT F ON
   (it.codSucu=f.codsucu) And (F.TIPOFAC=IT.TIPOFAC) AND (F.NUMEROD=IT.NUMEROD)
 left join saprod pr on
    it.coditem=pr.codprod
 left join saserv sr on
    it.coditem=sr.codserv
go

