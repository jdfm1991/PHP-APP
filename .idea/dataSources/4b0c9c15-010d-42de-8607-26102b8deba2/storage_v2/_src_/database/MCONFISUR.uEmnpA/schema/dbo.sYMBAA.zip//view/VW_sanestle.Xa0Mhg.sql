CREATE VIEW VW_sanestle AS 
   SELECT * FROM sanestle WITH (NOLOCK)
go

