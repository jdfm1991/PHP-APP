CREATE VIEW VW_ADM_CIERRES_INSTA AS 
SELECT DATEADD(dd, DATEDIFF(dd, 0, F.FechaE), 0) as FechaE,  
       F.CodEsta as 'Estacion',It.CodInst as 'Codigo Instancia',  
       IT.Descrip as 'Descripcion Instancia', TV.CodTaxs as 'Codigo Impuesto', 
       TX.Descrip as 'Descripcion Impuesto', Sum(TV.Monto) As 'Total Monto Impuesto', 
       SUM(TV.TGravable) as 'Total Gravable Impuesto'  
  FROM SAITEMFAC I  
  JOIN SAFACT F ON  
       (i.codSucu=f.codsucu) And (I.NumeroD=F.NumeroD) AND (I.TipoFac=F.TipoFac)  
  JOIN SAPROD P ON  
       (I.CodItem=P.CodProd)  
  JOIN SAINSTA IT ON  
       (P.CodInst=IT.CodInst)  
  JOIN SATAXITF TV ON  
       (tv.codSucu=i.codsucu) And (TV.NumeroD=I.NumeroD) aND (TV.TipoFac=I.TipoFac) And  
       (TV.NroLinea=I.NroLinea) And (TV.NroLineaC=I.NroLineaC) 
  JOIN SATAXES TX ON (TV.CodTaxs=TX.CodTaxs)  
GROUP BY DATEADD(dd, DATEDIFF(dd, 0, F.FechaE), 0), F.CodEsta,  
         It.CodInst, IT.Descrip, TV.CodTaxs, TX.Descrip
go

