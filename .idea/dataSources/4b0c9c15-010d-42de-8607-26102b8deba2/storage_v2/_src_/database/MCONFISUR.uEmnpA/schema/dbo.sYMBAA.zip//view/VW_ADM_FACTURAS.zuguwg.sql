CREATE VIEW DBO.VW_ADM_FACTURAS AS 
SELECT Tipofac, Numerod,
NroCtrol, CodSucu, CodEsta,
CodUsua, NumeroC, Signo,
NumeroF, NumeroP, CodClie, CodVend,
CodUbic, Descrip, Direc1, Direc2,
Direc3, ZipCode,
Telef, ID3, DetalChq, FechaT,
FechaE, FechaV, OrdenC,  CodOper,  NGiros, NMeses,
Signo*Monto As Monto,
Signo*MtoTotal as MontoTotal,
Signo*MtoTax As MtoTax, Signo*Fletes As Fletes,
Signo*(TGravable-TGravable*(Descto1+Descto2)/100) As TGravable,
Signo*(TExento-TExento*(Descto1+Descto2)/100+Fletes*(SELECT (case when IMPFLETEV=0 then 1 else 0 end) 
        FROM SACONF WHERE CODSUCU='00000')) As TExento,
Signo*CostoPrd As CostoPrd, Signo*CostoSrv As CostoSrv,
Signo*DesctoP  As DesctoP, Signo*RetenIVA As RetenIVA,
Signo*CancelI  As CancelI, Signo*CancelA As CancelA,
Signo*CancelE  As CancelE, Signo*CancelC As CancelC,
Signo*CancelT  As CancelT, Signo*CancelG As CancelG,
Signo*Cambio   As Cambio, Signo*MtoExtra As MtoExtra,
Signo*Descto1  As Descto1, Signo*Descto2 As Descto2,
Signo*TotalPrd As TotalPrd, Signo*TotalSrv As TotalSrv,
Signo*MtoComiVta As MtoComiVta, Signo*MtoComiCob As MtoComiCob,
Signo*MtoComiVtaD As MtoComiVtaD, Signo*MtoComiCobD As MtoComiCobD,
Signo*MtoFinanc As MtoFinanc,
Signo*(MtoComiVta+MtoComiVtaD) As TotMtoComiVta,
Signo*(MtoComiCob+MtoComiCobD) As TotMtoComiCob,
Signo*(Monto-(Descto1+Descto2)+MtoTax+Fletes) As Monto_Bruto,
Signo*(Monto-(Descto1+Descto2)) As Monto_Neto,
Signo*(Descto1+Descto2) As Monto_Descto,
Signo*(Costoprd+CostoSrv) As Monto_Costo,
Signo*(Contado) As Contado,
Signo*(Credito) As Credito,
Signo*(Monto-(Descto1+Descto2)-(CostoPrd+CostoSrv)) As Monto_Utili,
 (Case (Monto-(Descto1+Descto2))
       When 0  Then 0
       Else Signo*(Monto-(Descto1+Descto2)-(CostoPrd+CostoSrv))/
                  (Monto-(Descto1+Descto2))*100
  End) As Monto_PorUtil,
(Case (Monto-(Descto1+Descto2))
       When 0  Then 0
       Else (Case (MtoComiVta+MtoComiVtaD) When 0 Then 0
                   else Signo*(Monto-(Descto1+Descto2)-(MtoComiVta+MtoComiVtaD))/
                         (Monto-(Descto1+Descto2))*100
             End)
  End) As Monto_PorComi,
 (Case Contado 
       When 0  Then 0
       Else (Case (MtoComiCob+MtoComiCobD) When 0 Then 0
                   else Signo*(Contado-(MtoComiCob+MtoComiCobD))/Contado*100
             End)
  End) As Monto_PorComiCob, 
Notas1, Notas2, Notas3, Notas4, Notas5, Notas6, 
Notas7, Notas8, Notas9, Notas10 
From SAFACT WITH (NOLOCK) 
Where TipoFac in ('A','B')
go

