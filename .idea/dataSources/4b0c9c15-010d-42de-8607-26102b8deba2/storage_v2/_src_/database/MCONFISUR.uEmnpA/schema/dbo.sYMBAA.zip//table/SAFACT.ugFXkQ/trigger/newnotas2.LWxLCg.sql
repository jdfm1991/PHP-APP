create trigger newnotas2 on dbo.SAFACT
for insert 
as
begin
declare @NUMEROD varchar(10)
select @NUMEROD=NUMEROD from inserted
update SAFACT
set mgravable = tgravable
where TIPOFAC='B'
end
go

