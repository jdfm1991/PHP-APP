CREATE TRIGGER [dbo].[tasa]
   ON  [dbo].[SACONF] 
   AFTER UPDATE
AS 
BEGIN
declare @tasa as decimal(28,4)
declare @iva as decimal(28,4)
--select @iva = ((MtoTax * 0.01)+1) from SATAXES where CodTaxs = 'IVA'
select @tasa = factorp from SACONF 

update SAPROD set
saprod.CostAct = round( (SAPROD_02.Costo * @tasa) ,4),
saprod.CostAnt = round( (SAPROD_02.Costo * @tasa) ,4),
saprod.CostPro = round( (SAPROD_02.Costo * @tasa) ,4),
saprod.Precio1 = round( (SAPROD_02.Precio1_B * @tasa)  ,4),
saprod.Precio2 = round( (SAPROD_02.Precio2_B * @tasa)  ,4),
saprod.Precio3 = round( (SAPROD_02.Precio3_B * @tasa)  ,4),
saprod.PrecioU = round( (SAPROD_02.Precio1_P * @tasa)  ,4),
saprod.PrecioU2 = round( (SAPROD_02.Precio2_P * @tasa)  ,4),
saprod.PrecioU3 = round( (SAPROD_02.Precio3_P * @tasa)  ,4)
from SAPROD inner join SAPROD_02 on SAPROD.CodProd = SAPROD_02.CodProd
where SAPROD_02.Costo > 0

END
go

