CREATE VIEW DBO.VW_ADM_LIBROIVAVENTAS AS 
SELECT (CASE WHEN F.TIPOFAC='A' THEN '01-REG' ELSE '03-REG' END) As TipoReg, 
  F.CodSucu, 
  F.TipoFac As Tipo, 
  F.FechaE As FechaEmision, 
  F.FechaI As FechaFactura, 
  F.fechaT, 
  F.ID3 As RifCliente, 
  F.NumeroP as NroImprFiscal, 
  F.NumeroF As NroFacturaFiscal,
  F.Descrip As Nombre, 
  F.CodClie As CodCliente,
  C.tipocli As TipoCliente,
  (Case C.tipocli 
     when 0 then 'Contribuyente'
     when 1 then 'Consumidor final'
     when 2 then 'Exportacion'
     when 3 then 'Interno' 
     when 4 then 'Contribuyente especial'
   End) As DescrTipoClie,
  F.CodOper,
  (Case When F.TipoFac='A' Then 'FAC' Else 
   (CASE IsNull((SELECT CORRELUNC FROM SACONF),0) WHEN 1 THEN 'N/C' ELSE 'DEV' END) END) AS TIPODOC,
     F.NumeroD As NumeroDOC,
     F.NumeroR AS FactAfectada,
     F.NroCtrol, 
     F.Signo*(F.Monto+F.Fletes-(F.Descto1+F.Descto2)) AS TOTALVENTAS,
     F.Signo*(F.Monto+F.Fletes+F.MtoTax-(F.Descto1+F.Descto2)) AS TOTALVENTASCONIVA, 
     F.Signo*(F.TExento+F.Fletes*(SELECT (case when IMPFLETEV=0 then 1 else 0 end) 
                                    FROM SACONF WHERE CODSUCU='00000')) AS MtoExento,
  (Case when C.tipocli<>1 then 
         f.Signo*(F.TGravable-F.TGravable*(F.DESCTO1+F.DESCTO2)/(case when F.Monto=0 then 1 else F.monto end))
        else 0 end) As TotalGravable_Contribuye, 
  (Case when C.tipocli<>1 then f.Signo*f.MtoTax
        else 0 end) As TotalIVAContribuye, 
  (Case when C.tipocli=1 Then 
          f.Signo*(F.TGravable-F.TGravable*(F.DESCTO1+F.DESCTO2)/(case when F.Monto=0 then 1 else F.monto end))
        else 0 end) As TotalGravable_NoContribuye, 
  (Case when C.tipocli=1 Then f.Signo*f.MtoTax
        else 0 end) As TotalIVANoContribuye, 
   (Case when C.tipocli<>1 then 
        F.Signo*isnull((Select top 1 t.tgravable
                         From sataxvta T  WITH (NOLOCK) 
                        Where t.codtaxs='IVA14' And 
                              t.tipofac=f.tipofac and (t.codSucu=f.codsucu) And t.numerod=f.numerod),0)
    else 0 end) As MtoGravable_ContribuyeIVA14, 
   (Case when C.tipocli<>1 then 
         F.Signo*IsNull((Select top 1 t.Monto 
                          From sataxvta t  WITH (NOLOCK) 
                         Where t.codtaxs='IVA14' and 
                               t.tipofac=f.tipofac and (t.codSucu=f.codsucu) And t.numerod=f.numerod),0)
    else 0 end) As MontoIVA_ContribuyeIVA14,
   (Case when C.tipocli<>1 then 
        IsNull((Select top 1 t.MtoTax 
                  From sataxvta t WITH (NOLOCK) 
                 Where t.codtaxs='IVA14' And                        (t.codSucu=f.codsucu) And t.tipofac=f.tipofac and t.numerod=f.numerod),0)
    else 0 end) As Alicuota_ContribuyeIVA14,
   (Case when C.tipocli=1 then 
         F.Signo*isnull((Select top 1 t.tgravable 
                          From sataxvta T WITH (NOLOCK) 
                          Where t.codtaxs='IVA14' and 
                                (t.codSucu=f.codsucu) And t.tipofac=f.tipofac and t.numerod=f.numerod),0)
    else 0 end) As MtoGravable_NoContribuyeIVA14, 
   (Case when C.tipocli=1 then 
         F.Signo*IsNull((Select top 1 t.Monto 
                           From sataxvta t WITH (NOLOCK) 
                          Where t.codtaxs='IVA14' and 
                                (t.codSucu=f.codsucu) And t.tipofac=f.tipofac and t.numerod=f.numerod),0)
    else 0 end) As MontoIVA_NoContribuyeIVA14,
   (Case when C.tipocli=1 then 
         IsNull((Select top 1 t.MtoTax 
                   From sataxvta t WITH (NOLOCK) 
                  Where t.codtaxs='IVA14' and 
                        (t.codSucu=f.codsucu) And t.tipofac=f.tipofac and t.numerod=f.numerod),0)
    else 0 end) As Alicuota_NoContribuyeIVA14,
    F.Signo*F.RetenIVA AS RetencionIVA,
     (case when F.RetenIVA<>0 Then
           F.Signo*(F.MtoTax-F.RetenIVA)
      Else 0 End) As DifRetencion,
     (case when F.RetenIVA<>0 Then
           F.Signo*Round(F.RetenIVA/F.MtoTax*100,2)
      Else 0 End) As PorctReten,
     f.NumeroT As NroRetencion,
     f.FechaR  As FechaRetencion,
     F.NroUnico As NroUnico,
     0 AS DBZ
FROM SAFACT F WITH (NOLOCK) 
 LEFT JOIN SACLIE C ON
   F.CodClie = C.CodClie
WHERE (F.TipoFac IN ('A','B')) 
UNION ALL
 (SELECT (CASE WHEN F.TipoCxc='10' Then '01-REG' 
               WHEN F.TipoCxc='20' THEN '02-REG' 
               WHEN SUBSTRING(F.TipoCxc,1,1) in ('3','8') THEN '03-REG' END) As TipoReg, 
   F.CodSucu, 
   F.TipoCxc, 
   F.FechaE, 
   F.FechaI, 
   F.FechaT, 
   C.ID3, 
   NULL as NroImprFiscal, 
   NULL As NroFacturaFiscal,
   C.Descrip As Nombre, 
   C.codclie As CodCliente,
   C.tipocli As TipoCliente,
   (Case C.tipocli 
     when 0 then 'Contribuyente'
     when 1 then 'Consumidor final'
     when 2 then 'Exportacion'
     when 3 then 'Interno' 
     when 4 then 'Contribuyente especial'
    End) As DescrTipoClie,
   F.CodOper,
   (CASE WHEN F.TipoCxc = '10' THEN 'FAC' 
         WHEN F.TipoCxc = '20' THEN 'N/D' 
         WHEN F.TipoCxc = '31' THEN 'N/C' 
         WHEN F.TipoCxc = '81' THEN 'RET' 
    ELSE null END) AS TIPODOC,
   F.NumeroD As NumeroDoc, 
   f.numeroN As factAfectada,
   F.NroCtrol, 
   F.Monto*
   (CASE WHEN F.TipoCxc in ('10','20') THEN  1 
         WHEN F.TipoCxc in ('31') THEN -1 
         WHEN F.TipoCxc in ('81') THEN 0 END) AS TotalVentas,
   F.MontoNeto*(CASE WHEN F.TipoCxc in ('10','20') THEN 1   
                 WHEN F.TipoCxc in ('31') THEN -1 
                 WHEN F.TipoCxc in ('81') THEN 0 END) As TotalVentasConIVA,
   F.TExento*(CASE WHEN f.TipoCxc in ('10','20') THEN 1 
                  WHEN f.TipoCxc in ('31') THEN -1 
                  WHEN F.TipoCxc in ('81') THEN 0 END) As MtoExento,
   (Case when C.tipocli<>1 then 
        (CASE WHEN f.TipoCxc in ('10','20') THEN 1 
              WHEN f.TipoCxc in ('31') THEN -1 
              WHEN f.TipoCxc in ('81') THEN 1 END)*f.BaseImpo
    else 0 end), 
   (Case when C.tipocli<>1 then 
         (CASE WHEN f.TipoCxc in ('10','20') THEN 1 
               WHEN f.TipoCxc in ('31') THEN -1 
               WHEN f.TipoCxc in ('81') THEN 1 END)*f.MtoTax
    else 0 end), 
   (Case when C.tipocli=1 then 
        (CASE WHEN f.TipoCxc in ('10','20') THEN 1 
              WHEN f.TipoCxc in ('31') THEN -1 
              WHEN f.TipoCxc in ('81') THEN 1 END)*f.BaseImpo
    else 0 end), 
   (Case when C.tipocli=1 then 
         (CASE WHEN f.TipoCxc in ('10','20') THEN 1 
               WHEN f.TipoCxc in ('31') THEN -1 
               WHEN f.TipoCxc in ('81') THEN 1 END)*f.MtoTax
    else 0 end), 
   (Case when C.tipocli<>1 then 
         (CASE WHEN f.TipoCxc IN ('10','20') THEN 1 
               WHEN f.TipoCxc in ('31')  THEN -1 
               WHEN f.TipoCxc in ('81')  THEN 0 END)*
         Isnull((SELECT top 1 T.TGravable FROM SATAXCXC T WITH (NOLOCK) 
                 WHERE T.Codtaxs='IVA14' And
                       T.NroPpal=f.NroUnico),0)
     else 0 end), 
   (Case when C.TipoCli<>1 then 
         (CASE WHEN f.TipoCxc IN ('10','20') THEN 1 
               WHEN f.TipoCxc in ('31') THEN -1 
               WHEN f.TipoCxc in ('81') THEN 0 END)*
         Isnull((SELECT top 1 t.Monto FROM SATAXCXC T WITH (NOLOCK) 
                  WHERE t.codtaxs='IVA14' And
                      t.nroppal=f.nrounico),0)
    else 0 end),
   (Case when C.TipoCli<>1 then 
         (CASE WHEN f.TipoCxc IN ('10','20') THEN 1 
               WHEN f.TipoCxc in ('31') THEN -1 
               WHEN f.TipoCxc in ('81') THEN 0 END)*
         Isnull((SELECT top 1 T.MtoTax FROM SATAXCXC T WITH (NOLOCK) 
                 WHERE t.codtaxs='IVA14' And 
                     t.nroppal=f.nrounico),0)
     else 0 end),
   (Case when C.TipoCli=1 Then 
        (CASE WHEN f.TipoCxc IN ('10','20') THEN 1 
              WHEN f.TipoCxc in ('31') THEN -1 
              WHEN f.TipoCxc in ('81') THEN 0 END)*
          Isnull((SELECT top 1 t.TGravable FROM SATAXCXC T WITH (NOLOCK) 
                  WHERE T.Codtaxs='IVA14' And
                       T.NroPpal=f.NroUnico),0)
         else 0 end), 
   (Case when C.TipoCli=1 then 
         (CASE WHEN f.TipoCxc IN ('10','20') THEN 1 
               WHEN f.TipoCxc in ('31') THEN -1 
               WHEN f.TipoCxc in ('81') THEN 0 END)*
       Isnull((SELECT top 1 t.Monto FROM SATAXCXC T WITH (NOLOCK) 
                WHERE t.codtaxs='IVA14' And 
                     t.nroppal=f.nrounico),0)
    else 0 end),
   (Case when C.tipocli=1 then 
        (CASE WHEN f.TipoCxc IN ('10','20') THEN 1 
              WHEN f.TipoCxc in ('31')  THEN -1 
              WHEN f.TipoCxc in ('81')  THEN 0 END)*
        Isnull((SELECT top 1 t.MtoTax FROM SATAXCXC T WITH (NOLOCK) 
                  WHERE t.codtaxs='IVA14' And 
                     t.nroppal=f.nrounico),0)
    else 0 end),
       F.RetenIVA*(CASE WHEN f.TipoCxc in ('10','20','81') THEN 1
                        WHEN f.TipoCxc in ('31') THEN -1 END), 
       (CASE WHEN f.TipoCxc in ('10','20','81') THEN 1
            WHEN f.TipoCxc in ('31') THEN -1 END)*
       (case when F.RetenIVA<>0 Then
            (F.MtoTax-F.RetenIVA)
        Else 0 End) aS DifRetencion,
       (CASE When f.TipoCxc In ('10','20','81') THEN 1
            When f.TipoCxc in ('31')  THEN -1 END)*
       (case When F.RetenIVA<>0 Then
            Round(F.RetenIVA/F.MtoTax*100,2)
        Else 0 End) AS PorctReten,
      f.NumeroT As NroRetencion,
      f.fechaR  As FechaRetencion,
      F.NroUnico As NroUnico,
      1 AS DBZ
FROM  SAACXC F  WITH (NOLOCK) 
 LEFT JOIN SACLIE C ON 
      C.CodClie=F.CodClie
WHERE (f.TipoCxc IN ('10','20', '31', '81')) AND 
      (f.EsLibroI=1 and f.FROMTRAN=1))
go

