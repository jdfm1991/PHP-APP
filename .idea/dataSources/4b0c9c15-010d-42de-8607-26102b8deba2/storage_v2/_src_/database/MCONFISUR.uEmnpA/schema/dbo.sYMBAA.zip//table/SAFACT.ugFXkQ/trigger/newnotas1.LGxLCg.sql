create trigger newnotas1 on dbo.SAFACT
for insert 
as
begin
declare @NUMEROD varchar(10)
select @NUMEROD=NUMEROD from inserted
update SAFACT
set mexento = texento
where TIPOFAC='B'
end
go

