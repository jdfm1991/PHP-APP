-- =============================================
-- Author:		<Pablo De Genaro>
-- Create date: <05/05/2020>
-- Description:	<Trigger que almacena cabezera de nota de entrea en SANOTA>
-- =============================================
create TRIGGER [dbo].[NOTADEV]
   ON  [dbo].[SAFACT]
   AFTER INSERT
AS
BEGIN
DECLARE @NUMEROD AS VARCHAR(MAX)
DECLARE @TIPO AS VARCHAR(MAX)
DECLARE @NUMEROR AS VARCHAR(MAX)


SELECT @NUMEROD = NumeroD from inserted
SELECT @TIPO = TipoFac from inserted
SELECT @NUMEROR = numeror from inserted

UPDATE SANOTA WITH (ROWLOCK) SET numerodv = @NUMEROD WHERE (numerod=@NUMEROR);

END
go

