CREATE TRIGGER [dbo].[dolarfi]
   ON  [dbo].[SAITEMFAC]
   AFTER INSERT
AS
BEGIN
DECLARE @NUMEROD AS VARCHAR(MAX)
DECLARE @TIPO AS VARCHAR(MAX)
DECLARE @dolar as decimal(28,4)
declare @linea as int
set @dolar = (select factor from SACONF)
SELECT @NUMEROD = NumeroD, @TIPO = TipoFac, @linea = NroLinea FROM inserted
UPDATE SAITEMFAC SET
Tasai = @dolar
WHERE NumeroD = @NUMEROD AND TipoFac = @TIPO AND NroLinea = @linea
UPDATE safact set
Tasa = @dolar
WHERE NumeroD = @NUMEROD AND TipoFac = @TIPO
END
go

