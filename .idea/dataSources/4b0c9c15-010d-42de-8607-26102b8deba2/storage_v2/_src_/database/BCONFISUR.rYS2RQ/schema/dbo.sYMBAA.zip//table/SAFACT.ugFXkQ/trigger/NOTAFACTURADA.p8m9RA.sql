-- =============================================
-- Author:		<Pablo De Genaro>
-- Create date: <05/05/2020>
-- Description:	<Trigger que almacena cabezera de nota de entrea en SANOTA>
-- =============================================
CREATE TRIGGER [dbo].[NOTAFACTURADA]
   ON  [dbo].[SAFACT]
   AFTER DELETE
AS
BEGIN
DECLARE @NUMEROD AS VARCHAR(MAX)
DECLARE @TIPO AS VARCHAR(MAX)
DECLARE @NUMERODFAC AS VARCHAR(MAX)
DECLARE @CODCLIE AS VARCHAR(MAX)

SELECT @CODCLIE = CodClie from deleted
SET @NUMERODFAC = (select top 1 NumeroD from SAFACT where TipoFac ='A' and len(numerod) >5 order by NumeroD desc)
SELECT @NUMEROD = NumeroD from deleted
SELECT @TIPO = TipoFac from deleted

UPDATE SANOTA WITH (ROWLOCK) SET estatus='2', numerof = @NUMERODFAC WHERE (numerod=@NUMEROD);

END

go

