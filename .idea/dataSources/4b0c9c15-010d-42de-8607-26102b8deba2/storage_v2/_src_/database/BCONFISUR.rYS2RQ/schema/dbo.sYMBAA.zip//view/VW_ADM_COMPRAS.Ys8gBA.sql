CREATE VIEW DBO.VW_ADM_COMPRAS AS 
SELECT TipoCOM, Numerod,
       NroCtrol, CodSucu, CodEsta,
       CodUsua, NumeroC, Signo,
       NumeroP, CodProv,
       CodUbic, Descrip, Direc1, Direc2,
       Telef, ID3, DetalChq, FechaT,
       FechaE, FechaV, OrdenC,  CodOper,  NGiros, NMeses,
       Signo*Monto As Monto,
       Signo*MtoTotal as MontoTotal,
       Signo*MtoTax As MtoTax, Signo*Fletes As Fletes,
       Signo*(TGravable-TGravable*(Descto1+Descto2)/100) As TGravable,
       Signo*(TExento  -TExento  *(Descto1+Descto2)/100) As TExento,
       Signo*DesctoP  As DesctoP, Signo*RetenIVA As RetenIVA,
       Signo*CancelI  As CancelI, Signo*CancelA As CancelA,
       Signo*CancelE  As CancelE, Signo*CancelC As CancelC,
       Signo*CancelT  As CancelT, Signo*CancelG As CancelG,
       Signo*Descto1  As Descto1, Signo*Descto2 As Descto2,
       Signo*TotalPrd As TotalPrd, Signo*TotalSrv As TotalSrv,
       Signo*MtoFinanc As MtoFinanc,
       Signo*(Monto-(Descto1+Descto2)+MtoTax+Fletes) As Monto_Bruto,
       Signo*(Monto-(Descto1+Descto2)) As Monto_Neto,
       Signo*(Descto1+Descto2) As Monto_Descto,
       Signo*(Contado) As Contado,
       Signo*(Credito) As Credito,
       Notas1, Notas2, Notas3, Notas4, Notas5, Notas6,
       Notas7, Notas8, Notas9, Notas10
  From SACOMP WITH (NOLOCK)
 Where TipoCOM in ('H','I')
go

