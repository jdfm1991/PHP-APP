
CREATE TRIGGER [dbo].[CTSIAE] ON [dbo].[SAPAGCXP]
	--Version:20170202
	-- Se deben cargar primero las IAE y luego ISLR
AFTER INSERT
AS
DECLARE @CORREL INT
	,@LENCORREL INT
	,@UNICO INT
	,@CODOPER VARCHAR(10)
	,@PPAL INT
	,@NUMEROD VARCHAR(10)
	,@RIAE VARCHAR(10)
	,@RISLR VARCHAR(10)
	,@MONTO DECIMAL(28, 4)
	,@REGISTROS INT
	,@CODRETE VARCHAR(19)
	,@CODSUCU VARCHAR(5)
	,@RETISLR INT
	,@AFECTADO VARCHAR(10)
	,@TIPOCXP INT
	,@ESRETEN INT

-- Guarda el nombre de la constante para IAE
SET @RIAE = 'RIAE'
SET @RISLR = 'RISLR'

-- Guarda el codigo de operacion, ID de la CxP, numero unico del registro (ID), codigo de retencion y Tipo de Operacion
SELECT @CODOPER = CodOper
	,@PPAL = NroPpal
	,@UNICO = NroUnico
	,@CODRETE = CodRete
	,@TIPOCXP = TipoCxP
	,@ESRETEN = EsReten
FROM INSERTED

-- Guarda el numero de registros de IAE actuales
SET @REGISTROS = (
		SELECT COUNT(NroPpal)
		FROM SAPAGCXP
		WHERE NroPpal = @PPAL
			AND CodOper LIKE @RIAE + '_'
		)

-- Guarda el Codigo de la sucursal
SELECT @CODSUCU = CodSucu
FROM SASUCURSAL

-- Verifica que la operacion sea IAE (C/S)
-- Verifica que el Codigo de Retencion este registrado como de IAE en Retenciones
IF EXISTS (
		SELECT *
		FROM SATAXES
		WHERE CodOper LIKE @RIAE + '_'
			AND (
				CodTaxs = @CODRETE
				OR CodTaxs = @CODOPER
				)
		)
BEGIN
	-- Guarda el tamaño del correlativo, prestando atencion a la sucursal
	SET @LENCORREL = (
			SELECT ValueInt
			FROM SACORRELSIS
			WHERE FieldName = 'LenCorrel'
				AND CodSucu = @CODSUCU
			)
	-- Guarda el siguiente correlativo de IAE
	SET @CORREL = (
			SELECT Correl
			FROM CTSCFGIAE
			WHERE CodOper = @RIAE
			)

	-- Verifica si existe mas de un pago relacionado a la cxp
	IF @REGISTROS > 1
	BEGIN
		-- Decrementa el correlativo de IAE
		SET @CORREL = @CORREL - 1
	END
	ELSE
	BEGIN
		-- Decrementa el correlativo de Retenciones
		UPDATE SACORRELSIS
		SET ValueInt = ValueInt - 1
		WHERE FieldName = 'PrxImpue'
	END

	-- Acumula el monto de los pagos
	SET @MONTO = (
			SELECT SUM(Monto)
			FROM SAPAGCXP
			WHERE NroPpal = @PPAL
			)
	-- Guarda el correlativo con el formato adecuado
	SET @NUMEROD = (
			SELECT RIGHT('0000000000' + CAST(@CORREL AS VARCHAR), @LENCORREL)
			)

	-- Actualiza cuentas x pagar
	UPDATE SAACXP
	SET NumeroD = @NUMEROD
		,[Document] = 'RET. IAE ' + @NUMEROD
		,Monto = @MONTO
		,CodOper = @RIAE
	WHERE NroUnico = @PPAL

	-- Incrementa el correlativo de IAE
	UPDATE CTSCFGIAE
	SET Correl = @CORREL + 1
	WHERE CodOper = @RIAE
END
ELSE IF @CODOPER = @RISLR
	-- IF @TIPOCXP IN (
		-- 10
		-- ,21
		-- ,31 -- Reverso
		-- )
	AND @ESRETEN = 1
	AND @REGISTROS > 0
	-- Para Retenciones, TipoCxP deberia ser 21 pero en ciertas versiones era 10
	-- Se consulta Registros para asegurar que existan registros de Impuestos para realizar esta operacion
BEGIN
	IF EXISTS (
			SELECT *
			FROM SAACXP
			WHERE NroRegi = @PPAL
				AND CodOper LIKE @RISLR
			)
		-- Verifica la cantidad de retenciones de islr para saber si debe crear una
	BEGIN
		-- Guarda el identificador de la CXP creada
		SET @PPAL = (
				SELECT TOP 1 NroUnico
				FROM SAACXP
				WHERE NroRegi = @PPAL
					AND CodOper LIKE @RISLR
				)
	END
	ELSE
		-- Crea un registro para impuesto sobre la renta
	BEGIN
		-- Guarda el monto del pago
		SET @MONTO = (
				SELECT Monto
				FROM INSERTED
				)

		-- Verifica la cantidad de parametros en SP_ADM_PROXCORREL
		-- cambia en la version 9000
		IF (
				SELECT COUNT(*)
				FROM INFORMATION_SCHEMA.PARAMETERS
				WHERE SPECIFIC_NAME = 'SP_ADM_PROXCORREL'
				) = 4
			-- Ejecuta el SP interno para obtener el nuevo correlativo
			EXEC SP_ADM_PROXCORREL '00000'
				,NULL
				,'PrxImpue'
				,@NUMEROD OUTPUT
		ELSE
			-- Ejecuta el SP interno para obtener el nuevo correlativo
			EXEC SP_ADM_PROXCORREL '00000'
				,''
				,''
				,'PrxImpue'
				,@NUMEROD OUTPUT

		-- Inserta una nueva cuenta por pagar para la retencion
		INSERT INTO SAACXP (
			[TipoCxP]
			,[CodProv]
			,[NroRegi]
			,[Factor]
			,[FromTran]
			,[CodUsua]
			,[CodEsta]
			,[CodSucu]
			,[FechaT]
			,[NumeroD]
			,[Document]
			,[NumeroN]
			,[FechaI]
			,[FechaE]
			,[FechaV]
			,[Monto]
			,[MontoNeto]
			,[BaseImpo]
			,[EsUnPago]
			,[EsReten]
			,[Descrip]
			,[ID3]
			,[AfectaCom]
			,[NroCtrol]
			,CodOper
			)
		-- Guarda el Numero Principal en Numero de registro
		SELECT [TipoCxP]
			,[CodProv]
			,@PPAL
			,[Factor]
			,[FromTran]
			,[CodUsua]
			,[CodEsta]
			,[CodSucu]
			,[FechaT]
			,@NUMEROD
			,'RETENCIONES'
			,[NumeroN]
			,[FechaI]
			,[FechaE]
			,[FechaV]
			,@MONTO
			,[MontoNeto]
			,[BaseImpo]
			,[EsUnPago]
			,[EsReten]
			,[Descrip]
			,[ID3]
			,[AfectaCom]
			,[NroCtrol]
			,@RISLR
		FROM SAACXP
		WHERE NroUnico = @PPAL

		--AND TipoCxP = @TIPOCXP
		-- Guarda el nuevo numero principal
		SET @PPAL = IDENT_CURRENT('SAACXP')
	END

	-- Asocia el pago a la cuenta por pagar correspondiente
	UPDATE SAPAGCXP
	SET NroPpal = @PPAL
	WHERE NroUnico = @UNICO
END
go

