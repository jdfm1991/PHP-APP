
CREATE TRIGGER [dbo].[DECIMAL]  ON  [dbo].[SAACXC]
   FOR INSERT  
  
AS 
BEGIN
SET NOCOUNT ON;
--
declare @numerod varchar (20) -- numero de factura.
declare @totalitem decimal (28,4) -- total de item en factura.
declare @pordes decimal (28,4) -- % de descuento aplicado en la factura.
declare @descue decimal (28,4) -- descuento aplicado en la factura.
declare @texento decimal (28,4) -- monto exento.
declare @tgravable decimal (28,4) -- base imponible "gravable"
declare @mtotax decimal (28,4) -- impuesto iva.
declare @mtototal decimal (28,4) -- monto total de la factura.
--declare @tax decimal (28,4)

set @numerod = (select top 1 numerod from inserted) -- optenemos el numerod
set @totalitem = (select sum(TotalItem) totalitem from SAITEMFAC where NumeroD = @numerod)
set @pordes = (select (Descto1/monto) descuen from SAFACT where numerod = @numerod)
set @texento = round((select texento from SAFACT where numerod in (@numerod)), 2)
--set @tax = (select mtotax from SAFACT where NumeroD = @numerod
set @descue = round(@totalitem*@pordes, 2)
set @tgravable = round(@totalitem-@descue-@texento, 2)
set @mtototal = @tgravable+@mtotax+@texento
set @mtotax = round(@tgravable*(select @mtotax/100 from SATAXVTA where numerod = @numerod), 2)
IF @texento > 1 and @mtotax =0
	begin
		update SAFACT set monto = @totalitem, Descto1 = @descue, TGravable = @tgravable, MtoTax = 0, MtoTotal = @mtototal where numerod = @numerod
		update SATAXVTA set monto = 0, TGravable = @tgravable where numerod = @numerod
		update SAACXC set Monto = @mtototal, MontoNeto = @tgravable, MtoTax = 0, BaseImpo = @totalitem where numerod = @numerod
	end
	else if @texento > 1 and @mtotax > 1
	begin
		update SAFACT set monto = @totalitem, Descto1 = @descue, TGravable = @tgravable, MtoTax = @mtotax, MtoTotal = @mtototal where numerod = @numerod
		update SATAXVTA set monto = @mtotax, TGravable = @tgravable where numerod = @numerod
		update SAACXC set Monto = @mtototal, MontoNeto = @tgravable, MtoTax = @mtotax, BaseImpo = @totalitem where numerod = @numerod
	end
	else if @texento = 0 and @mtotax > 1
	begin 
		update SAFACT set monto = @totalitem, Descto1 = @descue, TGravable = @tgravable, MtoTax = @mtotax, MtoTotal = @mtototal where numerod = @numerod
		update SATAXVTA set monto = @mtotax, TGravable = @tgravable where numerod = @numerod
		update SAACXC set Monto = @mtototal, MontoNeto = @tgravable, MtoTax = @mtotax, BaseImpo = @totalitem where numerod = @numerod
	end
END
go

