

CREATE TRIGGER [dbo].[DECIMAL]
   ON  [dbo].[SAACXC]
   AFTER INSERT
AS 
BEGIN
SET NOCOUNT ON;

declare @tipocxc varchar (2)
declare @numfac varchar (20)
declare @tipofac varchar (1)
declare @totalitem decimal (28,4)
declare @pordes decimal (28,4)
declare @descue decimal (28,4)
declare @exento decimal (28,4)
declare @tgravab decimal (28,4)
declare @mtotax decimal (28,4)
declare @mtotot decimal (28,4)

SELECT @tipocxc = tipocxc from inserted

IF @tipocxc = '10'
BEGIN
set @tipofac = (select TOP 1 tipofac from SAITEMFAC ORDER BY FechaE DESC)
set @numfac = (select TOP 1 NumeroD from SAITEMFAC where TipoFac = @tipofac ORDER BY FechaE DESC)
set @totalitem = (select sum(TotalItem) totalitem from SAITEMFAC where NumeroD = @numfac and TipoFac = @tipofac)
set @pordes = (select (Descto1/monto) descuen from SAFACT where numerod in (@numfac))
set @exento = round((select texento from SAFACT where numerod in (@numfac)), 2)
set @descue = round(@totalitem*@pordes, 2)
set @tgravab = round(@totalitem-@descue-@exento, 2)
set @mtotax = round(@tgravab*(select MtoTax/100 from SATAXVTA where numerod in (@numfac)), 2)



IF @mtotax is null
	begin
		set @mtotax = 0
	end

set @mtotot = @tgravab+@mtotax+@exento
--select @numfac numerod, @totalitem monto, @descue Descto1, @exento exento, @tgravab TGravable, @mtotax MtoTax, @mtotot MtoTotal
--select sum(TotalItem) totalitem from SAITEMFAC where NumeroD = @numfac and TipoFac = @tipofac
--select TipoFac, numerod, monto, Descto1, TGravable, MtoTax, MtoTotal from SAFACT where numerod in (@numfac)
--select TipoFac, numerod, monto, MtoTax, TGravable from SATAXVTA where numerod in (@numfac)
--select TipoCxc, monto, MontoNeto, MtoTax, BaseImpo from SAACXC where numerod in (@numfac)
update SAFACT set monto = @totalitem, Descto1 = @descue, TGravable = @tgravab, MtoTax = @mtotax, MtoTotal = @mtotot where numerod = @numfac
update SATAXVTA set monto = @mtotax, TGravable = @tgravab where numerod = @numfac
update SAACXC set Monto = @mtotot, MontoNeto = @tgravab, MtoTax = @mtotax, BaseImpo = @totalitem where numerod = @numfac
end
END
go

