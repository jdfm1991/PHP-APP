create FUNCTION dbo.existen
(
@codprod as varchar(max),
@codubic as varchar(max)
)
RETURNS decimal(28,4)
AS
BEGIN
       declare @result as decimal;

       select
       @result = sum(case when cantempaq > 0 then saexis.exunidad + (saexis.Existen * cantempaq) else saexis.Existen end)
       from saexis inner join saprod on saexis.CodProd = saprod.codprod
       where SAEXIS.CodProd = @codprod and SAEXIS.CodUbic = @codubic


return @result;
END
go

