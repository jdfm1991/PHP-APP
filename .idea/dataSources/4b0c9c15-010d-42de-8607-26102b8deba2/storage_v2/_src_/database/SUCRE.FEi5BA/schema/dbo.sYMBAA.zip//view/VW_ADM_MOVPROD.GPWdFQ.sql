create view dbo.VW_ADM_MOVPROD 
 AS 
Select  P.CodProd, 
     P.DESCRIP, 
     P.CODINST, 
     P.ESENSER, 
     P.ESIMPORT, 
     P.ESEMPAQUE, 
     P.EXISTEN,
     P.EXUNIDAD, 
     P.MARCA, 
     SI.TipoFac As Tipo, 
     SI.NumeroD, 
     SI.FechaE, 
     S.CodClie As Codigo, 
     SI.CodUbic As CodUbic1, 
     NULL As CodUbic2, 
     S.Descrip AS DESCRIPT, 
     SI.EsUnid, 
     SI.NroLinea, 
     SUM(SI.Costo) As Costo, 
     SUM(SI.Precio) As Precio, 
 SUM(SI.Cantidad*SI.CantMayor) As Cantidad, 
 SUM(Case si.esunid when 1 Then SI.existAntU
          Else SI.existAnt End) As ExistAnt,
 SUM((Case When SI.TipoFac In ('B','D') Then 1
           Else 0 End)*
          SI.Cantidad*SI.CantMayor) As Entrada,
     SUM((Case When SI.TipoFac In ('A','C') Then 1
           Else 0 End)*
          SI.Cantidad*SI.CantMayor) As Salida,
 SUM((Case si.esunid when 1 Then SI.existAntU
           Else SI.existAnt End)-
         (Case When SI.TipoFac In ('B','D') Then -1
           Else 1 End)*SI.Cantidad*SI.CantMayor) As Saldo
 From SAPROD As P, 
      SAINSTA AS I, 
      SAFACT As S, 
      SAITEMFAC As SI WITH (NOLOCK) 
 Where (P.CodProd=SI.CodItem) AND (P.CODINST=I.CODINST) 
  And (P.DEsComp= 0) And (S.TipoFac=SI.TipoFac) 
  And (S.NumeroD=SI.NumeroD) And (S.codSucu=SI.codsucu) 
  And (SI.TipoFac In ('A' ,'B','C','D'))
 Group By  P.CodProd, si.FechaE, SI.Existant, SI.CodUbic, S.Descrip, 
           SI.EsUnid, SI.NroLinea, SI.TipoFac, SI.ExistantU, S.CodClie, 
           SI.NumeroD, P.DESCRIP, P.CODINST, P.ESENSER, P.ESIMPORT, 
           P.ESEMPAQUE, P.MARCA, P.EXISTEN, P.EXUNIDAD 
Union ALL 
(Select P.CodProd, 
     P.DESCRIP, 
     P.CODINST, 
     P.ESENSER, 
     P.ESIMPORT, 
     P.ESEMPAQUE, 
     P.EXISTEN,
     P.EXUNIDAD, 
     P.MARCA, 
     SI.TipoCOM As Tipo, 
     SI.NumeroD, 
     SI.FechaE, 
     S.CodPROV As Codigo, 
     SI.CodUbic As CodUbic1, 
     NULL AS CODUBIC2, 
     S.DESCRIP AS DESCRIPT, 
     SI.EsUnid, 
     SI.NroLinea, 
     SUM(SI.Costo) As Costo, 
     SUM(SI.Costo) As Precio, 
     SUM(SI.Cantidad) As Cantidad, 
     SUM(case si.esunid when 1 Then SI.existAntU
         else SI.existAnt End) As ExistAnt,
     SUM((Case When si.TipoCom In ('H','J') Then 1
          Else 0 End)*SI.Cantidad) As Entrada,
     SUM((Case When si.TipoCom In ('I','K') Then 1
           Else 0 End)*SI.Cantidad) As Salida, 
     SUM((case si.esunid  when 1 Then SI.existAntU
          else SI.existAnt End)+(Case When si.TipoCom In ('H','J') Then 1
                                Else -1 End)*SI.Cantidad) As Saldo
 From SAPROD As P, 
      SAINSTA AS I, 
      SACOMP As S, 
      SAITEMCOM As SI  WITH (NOLOCK) 
 Where (P.CodProd=SI.CodItem) AND (P.CODINST=I.CODINST)
  And (S.codSucu=SI.codsucu) And (S.TipoCom=SI.TipoCom) 
  And (S.NumeroD=SI.NumeroD) 
  And (S.CodProv=SI.CodProv) 
  And (SI.TipoCom In ('H','I','J','K'))
 Group by  P.CodProd, si.FechaE, si.existAnt, si.CodUbic, S.Descrip, SI.EsUnid, SI.NroLinea, 
           si.TipoCom, SI.ExistantU, S.CodProv, Si.NumeroD, 
           P.DESCRIP, P.CODINST, P.ESENSER, P.ESIMPORT, 
           P.ESEMPAQUE, P.MARCA, P.EXISTEN,P.EXUNIDAD)
Union ALL 
( Select  P.CodProd, 
     P.DESCRIP, 
     P.CODINST, 
     P.ESENSER, 
     P.ESIMPORT, 
     P.ESEMPAQUE, 
     P.EXISTEN,
     P.EXUNIDAD, 
     P.MARCA, 
     SI.TipoOPI As Tipo, 
     SI.NumeroD, 
     SI.FechaE, 
     NULL As Codigo, 
     SI.CodUbic, 
     NULL AS Codubic2, 
     S.USOMAT AS DESCRIPT, 
     SI.EsUnid, 
     SI.NroLinea, 
     SUM(si.Costo) as Costo, 
     SUM(si.Costo) as Precio, 
 SUM(Case When si.TipoOpI In ('O','N','P') Then SI.Cantidad
              Else Abs(SI.CantidadA-SI.Cantidad) 
         End) AS Cantidad, 
     SUM(Case si.esunid when 1 Then SI.existAntU
          Else SI.existAnt End) As ExistAnt,
 SUM((Case When si.TipoOpI='O' Then SI.Cantidad
       When si.TipoOpI In ('N','P') Then 0
       When si.TipoOpI='Q' Then 
              (Case When SI.CantidadA-SI.Cantidad<0 then 
                    Abs(SI.CantidadA-SI.Cantidad)
                Else 0 End) 
           End)) as Entrada,
     SUM((Case When si.TipoOpI='O' Then 0
        When si.TipoOpI In ('N','P') Then SI.Cantidad
       When si.TipoOpI='Q' Then 
              (Case When SI.CantidadA-SI.Cantidad<0 then 0
                Else Abs(SI.CantidadA-SI.Cantidad) End)
          End)) as Salida, 
     SUM((Case si.esunid when 1 Then SI.existAntU
           else SI.existAnt End)+(Case When SI.TipoOpI='O' Then SI.Cantidad
                        When SI.TipoOpI In ('N','P') Then -SI.Cantidad
                        When SI.TipoOpI='Q' Then 
                             (Case When SI.CantidadA-SI.Cantidad<=0 Then 
                                       Abs(SI.CantidadA-SI.Cantidad)
                               Else -Abs(SI.CantidadA-SI.Cantidad) End) 
                      End)) As Saldo 
 From SAPROD as P, 
      SAINSTA AS I, 
      SAOPEI As S, 
      SAITEMOPI As SI WITH (NOLOCK)  
 Where (P.CodProd = SI.CodItem) AND (P.CODINST=I.CODINST)
 And (S.CodSucu=SI.CodSucu) 
 And (S.TipoOpI=SI.TipoOpI) 
 And (S.NumeroD=SI.NumeroD)  
 And (SI.TipoOpI In ('N','O','Q','P'))
 Group by  P.CodProd, si.FechaE, si.existAnt, si.CodUbic, si.CodUbic2, S.UsoMat, 
           SI.EsUnid, SI.ExistantU, SI.NroLinea, si.TipoOpI,  S.Autori, Si.NumeroD, 
           P.DESCRIP, P.CODINST, P.ESENSER, P.ESIMPORT, 
           P.ESEMPAQUE, P.MARCA, P.EXISTEN, P.EXUNIDAD)
Union ALL ( SELECT  P.CodProd, 
     P.DESCRIP, 
     P.CODINST, 
     P.ESENSER, 
     P.ESIMPORT, 
     P.ESEMPAQUE, 
     P.EXISTEN, 
     P.EXUNIDAD, 
     P.MARCA, 
     SI.TipoOPI As Tipo, 
     SI.NumeroD, 
     SI.FechaE+0.001, 
     NULL As Codigo, 
     SI.CodUbic2, 
     SI.CodUbic, 
     S.USOMAT AS DESCRIPT, 
     SI.EsUnid, 
     SI.NroLinea, 
     SUM(SI.Costo) as Costo, 
     SUM(SI.Costo) as Precio, 
     SUM(SI.Cantidad) as Cantidad, 
     SUM(case si.esunid when 1 Then SI.existAntU
         else SI.existAnt End) As ExistAnt,
     SUM(SI.Cantidad) as Entrada,
     SUM(0) as Salida, 
     SUM((case si.esunid when 1 Then SI.existAntU
           else SI.existAnt End)) As Saldo
 From SAPROD as P, 
      SAINSTA AS I, 
      SAOPEI As S, 
      SAITEMOPI As SI WITH (NOLOCK) 
 Where (P.CodProd=SI.CodItem) AND (P.CODINST=I.CODINST)
 And (P.DEsComp= 0) 
 And (S.CODSUCU=SI.CODSUCU) 
 And (S.TipoOpI=SI.TipoOpI) 
 And (S.NumeroD=SI.NumeroD) 
 And (SI.TipoOpI='N') 
Group by  P.CodProd, si.FechaE, si.existAnt, SI.ExistantU, 
  si.CodUbic, si.CodUbic2, S.UsoMat, SI.EsUnid, SI.NroLinea, si.TipoOpI, 
  s.Autori, Si.NumeroD, P.DESCRIP, P.CODINST, P.ESENSER, P.ESIMPORT, 
  P.ESEMPAQUE, P.MARCA, P.EXISTEN,P.EXUNIDAD)
go

