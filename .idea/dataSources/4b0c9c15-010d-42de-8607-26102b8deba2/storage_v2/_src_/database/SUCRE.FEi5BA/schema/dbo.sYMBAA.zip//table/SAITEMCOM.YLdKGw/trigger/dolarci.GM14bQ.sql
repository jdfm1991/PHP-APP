CREATE TRIGGER [dbo].[dolarci]
   ON  [dbo].[SAITEMCOM]
   AFTER INSERT
AS
BEGIN
DECLARE @NUMEROD AS VARCHAR(MAX)
DECLARE @TIPO AS VARCHAR(MAX)
DECLARE @CODPROV AS VARCHAR(MAX)
DECLARE @CODPROD AS VARCHAR(MAX)
declare @linea as int
declare @dolar as decimal(28,4)
declare @iva as decimal(28,4)
select @iva = ((MtoTax * 0.01)+1) from SATAXES where CodTaxs = 'IVA'
set @dolar = (select factor from SACONF)

SELECT @NUMEROD = NumeroD, @TIPO = TipoCom, @CODPROV = CodProv, @linea = NroLinea, @CODPROD = CodItem FROM inserted

UPDATE SAITEMCOM SET
Tasai = @dolar
WHERE NumeroD = @NUMEROD AND TipoCom = @TIPO and CodProv = @CODPROV AND NroLinea = @linea

--INSERT INTO SAPROD_02
--(CodProd, Costo, Precio1_B, Precio2_B, Precio3_B, Precio1_P, Precio2_P, Precio3_P)
--(SELECT CodProd, 0, 0, 0, 0,0,0,0 FROM SAPROD where
--CodProd not in (select SP1.CodProd from SAPROD_02 AS SP1 WHERE SP1.CodProd = @CODPROD))

update SAPROD_02 set
SAPROD_02.Costo = round(SAPROD.Costo/@dolar,4),
SAPROD_02.Precio1_B = round((SAPROD.Precio1*case when EsExento = 0 then @iva else 1 end)/@dolar ,4),
SAPROD_02.Precio2_B = round((SAPROD.Precio2*case when EsExento = 0 then @iva else 1 end)/@dolar ,4),
SAPROD_02.Precio3_B = round((SAPROD.Precio3*case when EsExento = 0 then @iva else 1 end)/@dolar ,4),
SAPROD_02.Precio1_P = round((SAPROD.PrecioU*case when EsExento = 0 then @iva else 1 end)/@dolar ,4),
SAPROD_02.Precio2_P = round((SAPROD.PrecioU2*case when EsExento = 0 then @iva else 1 end)/@dolar ,4),
SAPROD_02.Precio3_P = round((SAPROD.PrecioU3*case when EsExento = 0 then @iva else 1 end)/@dolar ,4)
from SAPROD_02 inner join SAITEMCOM as SAPROD on SAPROD_02.CodProd = SAPROD.CodItem
WHERE SAPROD.NumeroD = @NUMEROD AND SAPROD.TipoCom = @TIPO AND CodProv = @CODPROV AND SAPROD.CodItem = @CODPROD


END
go

