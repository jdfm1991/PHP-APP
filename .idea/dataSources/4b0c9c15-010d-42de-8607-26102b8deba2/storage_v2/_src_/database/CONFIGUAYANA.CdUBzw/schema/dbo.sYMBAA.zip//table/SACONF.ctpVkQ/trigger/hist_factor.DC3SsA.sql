-- =============================================
-- Author:      <Equipo de IT>
-- Create date: <03/09/2019>
-- Description: <generacion de historico para tasas de cambios>
-- =============================================
CREATE TRIGGER [dbo].[hist_factor]
   ON  [dbo].[SACONF]
   AFTER UPDATE
AS 

BEGIN
SET NOCOUNT ON;

declare @tasa decimal (28,4)
set @tasa = (select Factor from SACONF)

       INSERT INTO [hist_tasa] (factor, fechae) VALUES (@tasa, GETDATE())
       
END

go

