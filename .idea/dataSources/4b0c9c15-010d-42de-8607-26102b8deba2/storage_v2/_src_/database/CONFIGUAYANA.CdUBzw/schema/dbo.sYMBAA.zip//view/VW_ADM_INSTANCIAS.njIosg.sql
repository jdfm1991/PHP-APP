Create View dbo.VW_ADM_INSTANCIAS AS 
WITH CTEInsta AS
(SELECT TipoIns, CodInst, InsPadre, Descrip, 0 AS HLevel,
        CAST(RIGHT(REPLICATE('0',5)+CONVERT(VARCHAR(5),CodInst),5) AS VARCHAR(MAX)) AS OrderByField
   FROM SAINSTA WITH (NOLOCK)
  WHERE (InsPadre=0)
  UNION ALL
 SELECT C.TipoIns, C.CodInst, C.InsPadre, C.Descrip,
        (CTE.HLevel+1) AS HLevel,
        CTE.OrderByField+
        CAST(RIGHT(REPLICATE('0',5)+CONVERT(VARCHAR(5),C.CodInst),5) AS VARCHAR(MAX)) AS OrderByField
   FROM SAINSTA C WITH (NOLOCK)
  INNER JOIN CTEInsta CTE ON
        CTE.CodInst=C.InsPadre
  WHERE (C.InsPadre IS NOT NULL))
SELECT C.TIPOINS, C.CODINST,
       C.DESCRIP,
       C.INSPADRE,
       I.Descto,I.DEsComp,I.DEsSeri,I.DEsLote,
       I.DEsComi,I.DEsCorrel,I.DigitosC,I.Nivel,I.DEsTabla,
       C.HLEVEL, C.ORDERBYFIELD
  FROM CTEInsta C WITH (NOLOCK)
 INNER JOIN SAINSTA I ON 
       I.CODINST=C.CODINST
go

