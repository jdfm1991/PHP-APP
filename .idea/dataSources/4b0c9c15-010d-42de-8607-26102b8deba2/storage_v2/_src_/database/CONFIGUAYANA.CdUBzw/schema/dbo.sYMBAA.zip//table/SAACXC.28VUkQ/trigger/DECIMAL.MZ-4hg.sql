-- =============================================
-- Author:		<Pablo De Genaro>
-- Create date: <12/05/2020>
-- Description:	<Trigger que verifica los calculos de cada factura para almacenar de forma correcta>
-- =============================================

CREATE TRIGGER [dbo].[DECIMAL]
ON  [dbo].[SAACXC]
AFTER INSERT
AS
BEGIN
SET NOCOUNT ON;
--
DECLARE @numfac as VARCHAR (MAX)
DECLARE @tipo as VARCHAR (MAX)
DECLARE @totalitem DECIMAL (28,4)
DECLARE @pordes DECIMAL (28,4)
DECLARE @descue DECIMAL (28,4)
DECLARE @exento DECIMAL (28,4)
DECLARE @tgravab DECIMAL (28,4)
DECLARE @mtotax DECIMAL (28,4)
DECLARE @mtotot DECIMAL (28,4)

if (@tipo = 'B')
begin
SELECT TOP 1 @numfac = numerod, @tipo = TipoFac, @pordes = (Descto1/monto), @exento = round(texento,2) FROM SAFACT ORDER BY FechaE DESC
SELECT TOP 1 @totalitem = sum(totalitem) FROM saitemfac WHERE numerod = @numfac AND tipofac = @tipo
SET @descue = round(@totalitem*@pordes, 2)
SET @tgravab = round(@totalitem-@descue-@exento, 2)
SET @mtotax = round(@tgravab*(SELECT MtoTax/100 FROM SATAXVTA WHERE numerod IN (@numfac)), 2)
SET @mtotot = @tgravab+@mtotax+@exento


update SAFACT set monto = @totalitem, Descto1 = @descue, TGravable = @tgravab, MtoTax = @mtotax, MtoTotal = @mtotot where numerod = @numfac
	update SATAXVTA set monto = @mtotax, TGravable = @tgravab where numerod = @numfac
		update SAACXC set Monto = @mtotot, MontoNeto = @tgravab, MtoTax = @mtotax, BaseImpo = @totalitem where numerod = @numfac
end
END
go

