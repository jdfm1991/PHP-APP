create view dbo.VW_ADM_ITEMSCOMPRA AS 
Select IT.codSucu, it.TipoCom, it.NumeroD, it.codprov, it.coditem, c.signo, it.Descrip1, it.Descrip2,
   it.Descrip3, it.Descrip4, it.Descrip5, it.Descrip6,
   it.Descrip7, it.Descrip8, it.Descrip9, it.Descrip10,
   it.precio, it.precioU, it.nrolinea, it.NroUnicoL, it.EsServ, it.EsUnid,
   it.EsExento, it.Cantidad, it.CantidadA, c.Signo*it.cantidad*it.Costo as TotCosto, it.codUbic, it.NroLote,
   it.costo, it.fechaL, it.Fechav AS FechaVL, C.FechaE  AS FechaEC, C.Fechav  AS FechaVC, 
   it.Precio1 As OPrecio1, it.Precio2 As OPrecio2,
   it.Precio3 As OPrecio3, it.faltante, it.descto,
   ip.DocImpo, ip.FechaI, ip.Factor,it.MtoTax, it.CostOrg,
   ip.costo1, ip.costo2, ip.costo3, ip.costo4, ip.costo5,
   ip.costo6, ip.costo7, ip.costo8, ip.costo9, ip.costo10,
   ip.precioU As PrecioIU1, ip.precioU2 As PrecioIU2, ip.precioU3 As PrecioIU3,
   ip.precio1 As PrecioI1, ip.precio2  As PrecioI2,  ip.precio3 As PrecioI3,
   (CASE SUBSTRING((Case when it.esserv=0 Then PR.DESCRIP else sr.descrip end),1,1) 
          WHEN '?' THEN 1 ELSE 0 END) AS ESFREEP,
   (case when it.esserv=0 then
        isnull((select codinst from sainsta where pr.codinst=codInst),0)
    else
        isnull((select codinst from sainsta where sr.codinst=codInst),0)
    end) as CodInst,
   (case when it.esserv=0 then pr.EsImport   else 0 end) As EsImport,
   (case when it.esserv=0 then pr.DEsSeri   else 0 end) As DEsSeri,
   (Case when it.esserv=0 Then pr.DEsLote   else 0 end) As DEsLote,
   (case when it.esserv=0 then Pr.DEsVence  else 0 end) As DEsVence,
   (case when it.esserv=0 then pr.EsPesa    else 0 end) As EsPesa,
   (case when it.esserv=0 then pr.tara      else 0 end) As Tara,
   (case when it.esserv=0 then pr.undempaq  else '' end) As UndEmpaq,
   (case when it.esserv=0 then pr.Unidad    else sr.unidad end) As Unidad,
   (case when it.esserv=0 then pr.cantempaq else 0 end) As CantEmpaq,
   (case when it.esserv=0 then pr.exdecimal else 0 end) As ExDecimal,
   (case when it.esserv=0 then pr.refere    else sr.clase end) As Refere,
   (case when it.esserv=0 then pr.costpro   else sr.costo end) As CostPro,
   (case when it.esserv=0 then pr.costAct   else sr.costo end) As CostAct,
   (case when it.esserv=0 then 0            else sr.UsaServ end) As UsaServ,
   (case when it.esserv=0 then pr.precio1   else sr.precio1 end) As Precio1,
   (case when it.esserv=0 then pr.precio2   else sr.precio2 end) As Precio2,
   (case when it.esserv=0 then pr.precio3   else sr.precio3 end) As Precio3,
   (case when it.esserv=0 then Pr.precioU   else 0 end) As PrecioU1,
   (case when it.esserv=0 then PR.Preciou2  else 0 end) As PrecioU2,
   (case when it.esserv=0 then PR.Preciou3  else 0 end) As PrecioU3,
   (case when it.esserv=0 then PR.Peso      else 0 end) As Peso,
   (case when it.esserv=0 then PR.Volumen   else 0 end) As Volumen,
   (case when it.esserv=0 then PR.UndVol    else '' end) As UndVol
  from SAITEMCOM it WITH (NOLOCK)
   inner Join VW_ADM_COMPRAS C on
      (c.codSucu=it.codsucu) And (c.tipocom=it.tipocom) and 
      (c.numerod=it.numerod) and (c.codprov=it.codprov)
   left Join saprimcom ip on
      (ip.codSucu=it.codsucu) And (ip.tipocom=it.tipocom) and
      (ip.numerod=it.numerod) and (ip.codprov=it.codprov) and
      (ip.nrolinea=it.nrolinea)
   LEFT join saprod pr on
      it.coditem=pr.codprod
   LEFT join saServ sr on
      it.coditem=sr.codServ
go

