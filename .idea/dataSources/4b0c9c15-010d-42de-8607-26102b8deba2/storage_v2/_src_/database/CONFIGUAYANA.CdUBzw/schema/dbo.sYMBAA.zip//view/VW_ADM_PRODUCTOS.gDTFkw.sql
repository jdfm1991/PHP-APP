CREATE VIEW dbo.VW_ADM_PRODUCTOS AS 
SELECT P.CodProd, P.Descrip, P.Descrip2, P.Descrip3, P.Descrip+IsNull(' '+P.Descrip2,'')+IsNull(' '+P.Descrip3,'') As DescripAll, (CASE SUBSTRING(P.DESCRIP,1,1) WHEN '?' THEN 1 ELSE 0 END) AS ESFREEP, 
P.Precio1, P.Precio2, P.Precio3, P.Preciou2, P.Preciou3, P.EsReten, P.fechaUV, p.FechaUC,P.DiasTole, P.Refere, P.Marca, P.Unidad, P.ACTIVO, P.UndEmpaq, P.CantEmpaq, P.PrecioU, P.CostAct, P.CostPro, P.CostAnt, P.Peso, P.Volumen, P.UndVol, P.Existen, P.ExUnidad, P.Compro, P.Pedido, P.Minimo, P.Maximo, P.DEsVence, P.EsPesa, P.Tara,P.EsImport, P.EsExento, P.EsOferta, P.EsEnser, P.EsEmpaque, P.ExDecimal, I.Descto, P.DEsComp, P.DEsSeri, P.DEsLote, I.DEsComi, I.DEsCorrel, I.DigitosC, I.CodInst FROM SAPROD P WITH (NOLOCK) INNER JOIN SAINSTA I ON P.CodInst=I.CodInst
go

