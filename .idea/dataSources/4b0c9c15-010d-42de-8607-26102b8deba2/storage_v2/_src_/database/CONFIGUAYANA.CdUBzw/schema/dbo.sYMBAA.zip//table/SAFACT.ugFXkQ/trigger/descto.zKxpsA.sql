-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[descto]
   ON  [dbo].[safact]
   AFTER insert
AS 
declare
  @tipo varchar(2),
  @numero varchar (15),
  @porcentaje decimal(28,4),
  @baseimpo decimal (28,4),
  @descto decimal (28,4),
  @monto decimal (28,4),
  @gravable decimal (28,4),
  @exento decimal (28,4)
BEGIN
set @tipo = (select tipofac from inserted)
set @numero = (select numerod from inserted)
set @descto = (select Descto1+Descto2 from SAFACT where TipoFac=@tipo and NumeroD=@numero)
set @monto = (select Monto from SAFACT where TipoFac=@tipo and NumeroD=@numero)
set @gravable = (select TGravable from SAFACT where TipoFac=@tipo and NumeroD=@numero)
set @exento = (select TExento from SAFACT where TipoFac=@tipo and NumeroD=@numero)
set @porcentaje = (@descto * 100) / @monto

update SAFACT set TGravable = @gravable -((@gravable * @porcentaje) / 100) 
			  where (TGravable > 0) and (TipoFac = @tipo) and (NumeroD = @numero)

update SAFACT set TExento =  @exento - ((@exento * @porcentaje) / 100)
			  where (TExento > 0) and (TipoFac = @tipo) and (NumeroD = @numero)
	SET NOCOUNT ON;

    -- Insert statements for trigger here

END
go

