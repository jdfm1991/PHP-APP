
CREATE TRIGGER [dbo].[CTSUT]
   ON  [dbo].[SATAXES]
   AFTER INSERT,UPDATE
AS 
BEGIN
DECLARE
	@codtaxs VARCHAR(5),
	@monto decimal(28,4),
	@FACTOR decimal(28,4)

	SET NOCOUNT ON

	SELECT @codtaxs=CodTaxs, @monto=MontoMax FROM inserted

	IF @codtaxs = 'UT'
	BEGIN
		-- Factor de ISLR
		SET @FACTOR = 83.3334

		-- Actualiza los impuestos de ISLR
		UPDATE SATAXES 
		SET 
			MontoMax=@monto * @FACTOR, 
			Sustraendo=@monto * @FACTOR * (R.Monto/100)
		FROM 
			SATAXES T, SARGORET R
		WHERE 
			T.CodTaxs=R.CodTaxs AND R.NroUnico=1 AND T.Descrip LIKE '%PNR%'

		-- Actualiza las retenciones de ISLR
		UPDATE SARGORET
		SET
			Desde=@monto * @FACTOR
		FROM 
			SATAXES T, SARGORET R
		WHERE 
			T.CodTaxs=R.CodTaxs AND R.NroUnico=1 AND T.Descrip LIKE '%PNR%'

		-- Factor de IAE
		SET @FACTOR = 20

		-- Actualiza los impuestos de IAE
		UPDATE SATAXES 
		SET 
			MontoMax=@monto * @FACTOR 
		FROM 
			SATAXES T, SARGORET R
		WHERE 
			T.CodTaxs=R.CodTaxs AND R.NroUnico=1 AND T.CodOper LIKE 'RIAE%'

		-- Actualiza las retenciones de ISLR
		UPDATE SARGORET
		SET
			Desde=@monto * @FACTOR
		FROM 
			SATAXES T, SARGORET R
		WHERE 
			T.CodTaxs=R.CodTaxs AND R.NroUnico=1 AND T.CodOper LIKE 'RIAE%'
	END
END
go

