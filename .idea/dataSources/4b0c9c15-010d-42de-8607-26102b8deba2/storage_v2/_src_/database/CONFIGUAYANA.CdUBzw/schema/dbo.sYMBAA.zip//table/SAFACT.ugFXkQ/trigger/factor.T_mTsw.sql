-- =============================================
-- Author:      <Equipo de IT>
-- MODIFICADO date: <20/09/2019>
-- Description: <ALMACENA FACTOR DE CAMBIO POR FACTURA PARA REFERENCIA SAFACTAUX1>
-- =============================================
CREATE TRIGGER [dbo].[factor]
   ON  [dbo].[SAFACT]
   AFTER INSERT
AS 

BEGIN
SET NOCOUNT ON;

declare @tasaf decimal (28,4)
declare @tasad decimal (28,4)
declare @numerod varchar(20)
declare @numeror varchar(20)
declare @codclie varchar(15)
declare @tipofac varchar(1)
declare @mtotalbs decimal(28, 4)
declare @mtotald decimal(28, 4)
declare @mtotaldd decimal(28, 4)
declare @saldoact decimal (28,4)
declare @fechae datetime
declare @totalsrv decimal (28,4)
declare @saldonew decimal (28,4)


set @tasaf = (select Factor from SACONF)
set @numerod = (select top 1 numerod from inserted)
set @codclie = (select top 1 CodClie from inserted)
set @tipofac = (select top 1 TipoFac from inserted)
set @mtotalbs = (select top 1 MtoTotal from inserted)
set @numeror = (select top 1 numeror from SAFACT where numerod =@numerod and TipoFac='B')
set @tasad = (select top 1 tasa from SAFACTAUX1 where numerod =@numeror)
set @mtotald = (@mtotalbs/@tasaf)
set @mtotaldd = (@mtotalbs/@tasad)
set @fechae = (select top 1 fechae from SAFACT where numerod =@numerod)
set @totalsrv =( select top 1 totalsrv from SAFACT where numerod =@numerod)
set @saldonew =(select saldo from SAACXCAUX1 where numerod =@numeror and tipofac='a') -@mtotald

IF @tipofac ='A'
    IF exists (select saldoact from SAACXCAUX1 where codclie = @codclie)
    begin
        set @saldoact = (select sum(saldo) from SAACXCAUX1 where codclie= @codclie and tipocxc ='10' ) +@mtotald
    end
    else
    begin
        set @saldoact = @mtotald
    end
    else
    IF exists (select saldoact from SAACXCAUX1 where codclie = @codclie and saldoact > 1) 
    begin
    set @saldoact = (select sum(saldo) from SAACXCAUX1 where codclie= @codclie and tipocxc ='10' ) -@mtotald
    end
    else 
    set @saldoact = 0
end
  
  IF @tipofac = 'A'
begin
       INSERT INTO [SAFACTAUX1] (numerod, codclie, TipoFac, mtotalbs, mtotald, fechae, tasa  ) VALUES (@numerod, @codclie, @tipofac, @mtotalbs, @mtotald, @fechae, @tasaf)
       INSERT INTO [SAACXCAUX1] (codclie, fechae, tipocxc, numerod,mtotalbs, tasa, mtotald, saldo, tipofac, estado, saldoact ) VALUES (@codclie,@fechae, 10, @numerod, @mtotalbs, @tasaf, @mtotald, @mtotald, @tipofac,0,  @saldoact)
end

else if (@tipofac = 'B' and @totalsrv = '0')
begin
    INSERT INTO [SAFACTAUX1] (numerod, codclie, TipoFac, mtotalbs, mtotald, fechae, tasa  ) VALUES (@numerod, @codclie, @tipofac, @mtotalbs, @mtotald,@fechae, @tasad)
    INSERT INTO [SAACXCAUX1] (codclie, fechae, tipocxc, numerod,mtotalbs, tasa, mtotald, saldo,  tipofac, mabonado, estado,fechap, saldoact, docafectado) VALUES 
    (@codclie,@fechae, 31, @numerod, @mtotalbs, @tasad, @mtotaldd,@mtotaldd, @tipofac, @mtotaldd,2,@fechae,  @saldoact, @numeror)
    UPDATE SAACXCAUX1 SET saldo = @saldonew where numerod=@numeror
    end
go

