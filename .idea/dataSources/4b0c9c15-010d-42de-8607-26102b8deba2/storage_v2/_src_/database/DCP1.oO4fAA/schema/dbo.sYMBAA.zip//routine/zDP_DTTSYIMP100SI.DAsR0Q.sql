CREATE PROC dbo.zDP_DTTSYIMP100SI (@TAXDTLID char(15), @TipoImpuesto smallint, @Vigente datetime, @TipoImpISLR char(25), @AplicaSustraendo tinyint, @MontoUT numeric(19,5), @DEX_ROW_ID int OUT) AS /* 12.00.0323.000 */ set nocount on BEGIN INSERT INTO .DTTSYIMP100 (TAXDTLID, TipoImpuesto, Vigente, TipoImpISLR, AplicaSustraendo, MontoUT) VALUES ( @TAXDTLID, @TipoImpuesto, @Vigente, @TipoImpISLR, @AplicaSustraendo, @MontoUT) SELECT @DEX_ROW_ID = @@IDENTITY END set nocount off
go

