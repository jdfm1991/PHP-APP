 CREATE PROC dbo.zDP_SVC06301SI (@DATE1 datetime, @TIME1 datetime, @Status smallint, @STRTDATE datetime, @STRTTIME datetime, @ENDDATE datetime, @ENDTIME datetime, @DEX_ROW_ID int OUT) AS  set nocount on BEGIN INSERT INTO .SVC06301 (DATE1, TIME1, Status, STRTDATE, STRTTIME, ENDDATE, ENDTIME) VALUES ( @DATE1, @TIME1, @Status, @STRTDATE, @STRTTIME, @ENDDATE, @ENDTIME) SELECT @DEX_ROW_ID = @@IDENTITY END set nocount off
 go

