 CREATE PROC dbo.zDP_AF40110SD (@USERNAME char(31), @RowsAffected int OUT, @RID int = 0, @TN char(99) = 'TN') AS  set nocount on BEGIN IF @RID > 0 DELETE FROM .AF40110 WHERE USERNAME = @USERNAME AND ( NOT EXISTS ( SELECT 1 FROM tempdb.dbo.DEX_LOCK WHERE row_id = @RID AND table_path_name = @TN ) ) ELSE DELETE FROM .AF40110 WHERE USERNAME = @USERNAME SELECT @RowsAffected = @@rowcount END set nocount off
 go

