 CREATE PROC dbo.zDP_UPR42502SI (@Batch_Prefix char(15), @DEPRTMNT char(7), @DEX_ROW_ID int OUT) AS  set nocount on BEGIN INSERT INTO .UPR42502 (Batch_Prefix, DEPRTMNT) VALUES ( @Batch_Prefix, @DEPRTMNT) SELECT @DEX_ROW_ID = @@IDENTITY END set nocount off
 go

