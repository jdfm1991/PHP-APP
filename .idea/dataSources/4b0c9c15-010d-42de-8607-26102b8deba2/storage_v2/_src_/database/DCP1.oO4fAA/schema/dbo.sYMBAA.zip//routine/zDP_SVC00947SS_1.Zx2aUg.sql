 CREATE PROC dbo.zDP_SVC00947SS_1 (@SVC_Tech_Inventory_ID char(11), @LNITMSEQ int) AS  set nocount on SELECT TOP 1  SVC_Tech_Inventory_ID, ITEMNMBR, LNITMSEQ, QTY_Required, UOFM, NOTEINDX, DEX_ROW_ID FROM .SVC00947 WHERE SVC_Tech_Inventory_ID = @SVC_Tech_Inventory_ID AND LNITMSEQ = @LNITMSEQ ORDER BY SVC_Tech_Inventory_ID ASC, LNITMSEQ ASC set nocount off
 go

