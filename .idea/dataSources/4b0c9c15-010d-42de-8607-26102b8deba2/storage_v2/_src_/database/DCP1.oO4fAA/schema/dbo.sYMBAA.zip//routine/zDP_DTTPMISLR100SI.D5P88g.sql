CREATE PROC dbo.zDP_DTTPMISLR100SI (@NroComprobante char(21), @VENDORID char(15), @SujetoRetenido char(15), @YEAR1 smallint, @DATE1 datetime, @CONSECUTIVOISLR int, @BACHNUMB char(15), @USERID char(15), @CREATDDT datetime, @DEX_ROW_ID int OUT) AS /* 12.00.0323.000 */ set nocount on BEGIN INSERT INTO .DTTPMISLR100 (NroComprobante, VENDORID, SujetoRetenido, YEAR1, DATE1, CONSECUTIVOISLR, BACHNUMB, USERID, CREATDDT) VALUES ( @NroComprobante, @VENDORID, @SujetoRetenido, @YEAR1, @DATE1, @CONSECUTIVOISLR, @BACHNUMB, @USERID, @CREATDDT) SELECT @DEX_ROW_ID = @@IDENTITY END set nocount off
go

