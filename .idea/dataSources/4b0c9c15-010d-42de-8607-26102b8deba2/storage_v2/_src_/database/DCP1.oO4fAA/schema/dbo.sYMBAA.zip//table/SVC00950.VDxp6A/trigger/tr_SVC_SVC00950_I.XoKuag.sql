 CREATE TRIGGER tr_SVC_SVC00950_I ON dbo.SVC00950  FOR INSERT AS declare @Opt smallint select @Opt = SVC_Address_Option from SVC00998 update SVC00950 set SVC00950.SVC_Address_Option = @Opt from inserted i where SVC00950.CUSTNMBR = i.CUSTNMBR and   SVC00950.ADRSCODE = i.ADRSCODE and   (i.SVC_Address_Option < 1 or i.SVC_Address_Option > 4)
 go

