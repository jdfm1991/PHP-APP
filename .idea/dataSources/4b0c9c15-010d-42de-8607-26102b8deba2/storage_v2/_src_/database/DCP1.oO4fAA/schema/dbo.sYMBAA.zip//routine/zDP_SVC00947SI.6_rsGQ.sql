 CREATE PROC dbo.zDP_SVC00947SI (@SVC_Tech_Inventory_ID char(11), @ITEMNMBR char(31), @LNITMSEQ int, @QTY_Required numeric(19,5), @UOFM char(9), @NOTEINDX numeric(19,5), @DEX_ROW_ID int OUT) AS  set nocount on BEGIN INSERT INTO .SVC00947 (SVC_Tech_Inventory_ID, ITEMNMBR, LNITMSEQ, QTY_Required, UOFM, NOTEINDX) VALUES ( @SVC_Tech_Inventory_ID, @ITEMNMBR, @LNITMSEQ, @QTY_Required, @UOFM, @NOTEINDX) SELECT @DEX_ROW_ID = @@IDENTITY END set nocount off
 go

