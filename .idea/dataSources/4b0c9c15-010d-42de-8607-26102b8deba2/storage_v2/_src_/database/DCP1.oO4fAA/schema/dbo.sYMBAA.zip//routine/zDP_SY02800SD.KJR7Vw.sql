 CREATE PROC dbo.zDP_SY02800SD (@ENDTYPE smallint, @SERIES smallint, @MODULE1 smallint, @RowsAffected int OUT, @RID int = 0, @TN char(99) = 'TN') AS  set nocount on BEGIN IF @RID > 0 DELETE FROM .SY02800 WHERE ENDTYPE = @ENDTYPE AND SERIES = @SERIES AND MODULE1 = @MODULE1 AND ( NOT EXISTS ( SELECT 1 FROM tempdb.dbo.DEX_LOCK WHERE row_id = @RID AND table_path_name = @TN ) ) ELSE DELETE FROM .SY02800 WHERE ENDTYPE = @ENDTYPE AND SERIES = @SERIES AND MODULE1 = @MODULE1 SELECT @RowsAffected = @@rowcount END set nocount off
 go

