 CREATE PROC dbo.zDP_FA49900SD (@CMPANYID smallint, @RowsAffected int OUT, @RID int = 0, @TN char(99) = 'TN') AS  set nocount on BEGIN IF @RID > 0 DELETE FROM .FA49900 WHERE CMPANYID = @CMPANYID AND ( NOT EXISTS ( SELECT 1 FROM tempdb.dbo.DEX_LOCK WHERE row_id = @RID AND table_path_name = @TN ) ) ELSE DELETE FROM .FA49900 WHERE CMPANYID = @CMPANYID SELECT @RowsAffected = @@rowcount END set nocount off
 go

