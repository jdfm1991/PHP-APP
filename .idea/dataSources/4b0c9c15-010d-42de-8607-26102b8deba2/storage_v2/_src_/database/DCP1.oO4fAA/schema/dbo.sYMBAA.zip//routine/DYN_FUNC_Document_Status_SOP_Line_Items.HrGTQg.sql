create function [dbo].[DYN_FUNC_Document_Status_SOP_Line_Items] (@iIntEnum integer) returns varchar(100) as  begin  declare @oVarcharValuestring varchar(100) set @oVarcharValuestring = case  when @iIntEnum = 1 then 'Sin contabilizar' when @iIntEnum = 2 then 'Contabilizado' else ''  end  RETURN(@oVarcharValuestring)  END
go

