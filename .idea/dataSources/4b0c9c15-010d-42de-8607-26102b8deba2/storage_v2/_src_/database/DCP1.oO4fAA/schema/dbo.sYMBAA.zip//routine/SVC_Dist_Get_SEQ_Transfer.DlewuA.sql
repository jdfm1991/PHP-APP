 CREATE PROCEDURE SVC_Dist_Get_SEQ_Transfer (@Number as char(15),  @Line as integer,  @NextLine as integer output)  AS  select @NextLine = isnull(max(SEQNUMBR),0)+16384   from SVC00731  where ORDDOCID = @Number and LNITMSEQ =@Line  return
 go

