CREATE PROC dbo.zDP_DTTPMIMP000SS_1 (@Expediente char(21)) AS /* 12.00.0323.000 */ set nocount on SELECT TOP 1  Expediente, Liquidado, DEX_ROW_ID FROM .DTTPMIMP000 WHERE Expediente = @Expediente ORDER BY Expediente ASC set nocount off
go

