 CREATE PROC dbo.zDP_CM20600SS_1 (@Xfr_Record_Number numeric(19,5)) AS  set nocount on SELECT TOP 1  Xfr_Record_Number, CMXFRNUM, CMFRMRECNUM, CMTORECNUM, CMFRMSTATUS, CMTOSTATUS, CMFRMCHKBKID, CMCHKBKID, CMXFTDATE, NOTEINDX, DEX_ROW_ID FROM .CM20600 WHERE Xfr_Record_Number = @Xfr_Record_Number ORDER BY Xfr_Record_Number ASC set nocount off
 go

