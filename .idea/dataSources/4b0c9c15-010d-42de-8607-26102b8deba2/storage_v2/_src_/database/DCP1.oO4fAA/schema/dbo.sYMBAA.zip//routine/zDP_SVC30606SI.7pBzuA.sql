 CREATE PROC dbo.zDP_SVC30606SI (@CONSTS smallint, @CONTNBR char(11), @LNSEQNBR numeric(19,5), @ITEMNMBR char(31), @SVC_Contract_Version smallint, @DEX_ROW_ID int OUT) AS  set nocount on BEGIN INSERT INTO .SVC30606 (CONSTS, CONTNBR, LNSEQNBR, ITEMNMBR, SVC_Contract_Version) VALUES ( @CONSTS, @CONTNBR, @LNSEQNBR, @ITEMNMBR, @SVC_Contract_Version) SELECT @DEX_ROW_ID = @@IDENTITY END set nocount off
 go

