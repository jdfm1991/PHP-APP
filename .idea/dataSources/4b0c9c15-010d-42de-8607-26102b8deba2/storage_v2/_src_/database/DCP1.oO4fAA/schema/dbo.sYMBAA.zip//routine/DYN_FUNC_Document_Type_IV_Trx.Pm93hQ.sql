create function [dbo].[DYN_FUNC_Document_Type_IV_Trx] (@iIntEnum integer) returns varchar(100) as  begin  declare @oVarcharValuestring varchar(100) set @oVarcharValuestring = case  when @iIntEnum = 1 then 'Ajuste' when @iIntEnum = 2 then 'Variación' when @iIntEnum = 3 then 'Transferencia' when @iIntEnum = 4 then 'Recibo' when @iIntEnum = 5 then 'Devolución' when @iIntEnum = 6 then 'Venta' when @iIntEnum = 7 then 'Lista de materiales' else ''  end  RETURN(@oVarcharValuestring)  END
go

