-- =============================================
-- Author:		<Pablo De Genaro>
-- Create date: <25/05/2020>
-- Description:	<Trigger que inserta el tipo de documento en los appfacturasdet>
-- =============================================
CREATE TRIGGER [dbo].[TIPODOC_DESPACHOS]
   ON  [dbo].[appfacturas_det]
   AFTER INSERT
AS
BEGIN
DECLARE @NUMEROD AS VARCHAR(MAX)
DECLARE @TIPO AS VARCHAR(MAX)

SELECT @NUMEROD = numeros from inserted
SET @TIPO = (SELECT top 1 tipofac from SAFACT where numerod = @NUMEROD and TipoFac in ('A','C') order by fechae desc)


   UPDATE [appfacturas_det] SET TipoFac = @TIPO  WHERE NUMEROS = @NUMEROD


END
go

