-- =============================================
-- Author:		<Pablo De Genaro>
-- Create date: <05/05/2020>
-- Description:	<Trigger que almacena cabezera de nota de entrea en SANOTA>
-- =============================================
CREATE TRIGGER [dbo].[NOTAENTREGA]
   ON  [dbo].[SAFACT]
   AFTER INSERT
AS

DECLARE @NUMEROD AS VARCHAR(MAX)
DECLARE @TIPO AS VARCHAR(MAX)
DECLARE @CODCLIE AS VARCHAR(MAX)
DECLARE @RIF AS VARCHAR(MAX)
DECLARE @RSOCIAL AS VARCHAR(MAX)
DECLARE @DIRECCION AS VARCHAR(MAX)
DECLARE @TELEFONO AS VARCHAR(MAX)
DECLARE @CODVEND AS VARCHAR(MAX)
DECLARE @FECHA AS DATETIME
DECLARE @NOTAS1 AS VARCHAR(MAX)
DECLARE @ESTATUS AS SMALLINT

SELECT @NUMEROD = numerod from inserted
SELECT @TIPO = TipoFac from inserted
SELECT @CODCLIE = CodClie from inserted
SELECT @RIF = ID3 from inserted
SELECT @RSOCIAL = Descrip from inserted
SELECT @DIRECCION = Direc1 from inserted
SELECT @TELEFONO = Telef from inserted
SELECT @CODVEND = CodVend from inserted
SELECT @FECHA = FechaE from inserted
SELECT @NOTAS1 = Notas1 from inserted


-- 0 PENDIENTE
-- 1 ABONADO
-- 2 FACTURADA
-- 3 PAGADA
-- 4 DEVOLUCION

IF (@TIPO ='C')
BEGIN
   INSERT INTO [SANOTA] (numerod, tipofac, codclie, rif, rsocial, direccion, telefono, codvend,  fechae, notas1, estatus)
   VALUES (@NUMEROD, @TIPO, @CODCLIE, @RIF, @RSOCIAL, @DIRECCION, @TELEFONO, @CODVEND,  @FECHA, @NOTAS1, '0')
   end
   ELSE IF (@TIPO='D')
   begin
      INSERT INTO [SANOTA] (numerod, tipofac, codclie, rif, rsocial, direccion, telefono, codvend,  fechae, notas1, estatus)
   VALUES (@NUMEROD, @TIPO, @CODCLIE, @RIF, @RSOCIAL, @DIRECCION, @TELEFONO, @CODVEND,  @FECHA, @NOTAS1, '4')
END
go

