create trigger Ctrl_saitemFac
on Saitemfac 
after insert
as
declare 
@TipoFac varchar(2),
@NumeroD varchar(50),
@NroLinea int, 
@Descto decimal(38,4)

select @TipoFac = Tipofac from inserted;
select @NumeroD = NumeroD from inserted;
select @NroLinea = NroLinea from inserted;
select @Descto = Descto from inserted;

if @Descto < 0
begin
update saitemfac set descto = Descto*-1
where TipoFac = @TipoFac and NumeroD = @NumeroD and NroLinea = @NroLinea 
end



go

