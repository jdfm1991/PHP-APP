

/****** Objeto: vista dbo.XVE3    fecha de la secuencia de comandos: 29/03/2005 04:04:34 a.m. ******/
CREATE VIEW dbo.XVE3
AS
SELECT     dbo.VE3.VE3_NUMERO AS VE3_NUMERO, dbo.VE3.VE3_FECHA AS VE3_FECHA, dbo.VE3.VE3_MONTO AS VE3_MONTO, 
                      dbo.VEN.VEN_VENCE AS VEN_VENCE, dbo.VEN.VEN_SALDO1 AS VEN_SALDO1, dbo.VEN.VEN_OPE, dbo.VEN.VEN_FECHA, dbo.VEN.VEN_NUMERO, 
                      dbo.VEN.VEN_CONTROL, dbo.VEN.VEN_SALDO, dbo.CLI.CLI_CODIGO, dbo.CLI.CLI_NOMBRE
FROM         dbo.CLI LEFT OUTER JOIN
                      dbo.VEN ON dbo.CLI.CLI_PK = dbo.VEN.VEN_CLIFK RIGHT OUTER JOIN
                      dbo.VE3 ON dbo.VEN.VEN_PK = dbo.VE3.VE3_VENFK

go

