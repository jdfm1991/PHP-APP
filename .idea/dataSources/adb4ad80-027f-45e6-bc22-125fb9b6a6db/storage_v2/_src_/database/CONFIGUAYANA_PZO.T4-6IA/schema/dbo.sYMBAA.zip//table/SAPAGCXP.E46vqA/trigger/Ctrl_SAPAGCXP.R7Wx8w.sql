
-- =============================================
-- Author:		@Author,,Name
-- Create date: @Create Date,,
-- Description:	@Description,,
-- =============================================
CREATE TRIGGER [dbo].[Ctrl_SAPAGCXP]
   ON  [dbo].[SAPAGCXP]
   INSTEAD OF INSERT
AS 
DECLARE
		    @CodSucu varchar(5)
           ,@NroPpal int
           ,@NroRegi int
           ,@TipoCxP varchar(2)
           ,@MontoDocA decimal(28,4)
           ,@Monto decimal(28,4)
           ,@NumeroD varchar(25)
           ,@Descrip varchar(40)
           ,@FechaE datetime
           ,@FechaO datetime
           ,@EsReten smallint
           ,@BaseReten decimal(28,4)
           ,@CodOper varchar(10)
           ,@CodRete varchar(10)
           ,@BaseImpo decimal(28,4)
           ,@TExento decimal(28,4)
           ,@MtoTax decimal(28,4)
           ,@RetenIVA decimal(28,4)
           ,@Sustraendo decimal(28,4)
           ,@CodReten2 varchar (10)
           
           
SELECT @CodSucu = CodSucu FROM inserted;
SELECT @NroPpal = NroPpal FROM inserted;
SELECT @NroRegi = NroRegi FROM inserted;
SELECT @TipoCxP = TipoCxP FROM inserted;
SELECT @MontoDocA = MontoDocA FROM inserted;
SELECT @Monto= Monto FROM inserted;
SELECT @NumeroD = NumeroD FROM inserted;
SELECT @Descrip = Descrip FROM inserted;
SELECT @FechaE = FechaE FROM inserted;
SELECT @FechaO = FechaO FROM inserted;
SELECT @EsReten = EsReten FROM inserted;
SELECT @BaseReten = BaseReten FROM inserted;
SELECT @CodOper = CodOper FROM inserted;
SELECT @CodRete = CodRete FROM inserted;
SELECT @BaseImpo = BaseImpo FROM inserted;
SELECT @TExento = TExento FROM inserted;
SELECT @MtoTax = MtoTax FROM inserted;
SELECT @RetenIVA = RetenIVA FROM inserted;
SELECT @Sustraendo = Sustraendo FROM inserted;

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
if @CodOper not in (SELECT CodOper FROM SAOPER)	
begin
select @CodReten2 = CodOper from SATAXES where CodTaxs = @CodOper
 
	INSERT INTO [SAPAGCXP]
           ([CodSucu]
           ,[NroPpal]
           ,[NroRegi]
           ,[TipoCxP]
           ,[MontoDocA]
           ,[Monto]
           ,[NumeroD]
           ,[Descrip]
           ,[FechaE]
           ,[FechaO]
           ,[EsReten]
           ,[BaseReten]
           ,[CodOper]
           ,[CodRete]
           ,[BaseImpo]
           ,[TExento]
           ,[MtoTax]
           ,[RetenIVA]
           ,[Sustraendo])
           
           VALUES
           (
            @CodSucu 
           ,@NroPpal 
           ,@NroRegi
           ,@TipoCxP 
           ,@MontoDocA 
           ,@Monto 
           ,@NumeroD 
           ,@Descrip 
           ,@FechaE 
           ,@FechaO 
           ,@EsReten 
           ,@BaseReten 
           ,@CodReten2
           ,@CodOper 
           ,@BaseImpo 
           ,@TExento 
           ,@MtoTax 
           ,@RetenIVA 
           ,@Sustraendo 
           )    
end
else
begin
			INSERT INTO [SAPAGCXP]
           ([CodSucu]
           ,[NroPpal]
           ,[NroRegi]
           ,[TipoCxP]
           ,[MontoDocA]
           ,[Monto]
           ,[NumeroD]
           ,[Descrip]
           ,[FechaE]
           ,[FechaO]
           ,[EsReten]
           ,[BaseReten]
           ,[CodOper]
           ,[CodRete]
           ,[BaseImpo]
           ,[TExento]
           ,[MtoTax]
           ,[RetenIVA]
           ,[Sustraendo]) 
           VALUES
           (
            @CodSucu 
           ,@NroPpal 
           ,@NroRegi
           ,@TipoCxP 
           ,@MontoDocA 
           ,@Monto 
           ,@NumeroD 
           ,@Descrip 
           ,@FechaE 
           ,@FechaO 
           ,@EsReten 
           ,@BaseReten 
           ,@CodOper 
           ,@CodRete 
           ,@BaseImpo 
           ,@TExento 
           ,@MtoTax 
           ,@RetenIVA 
           ,@Sustraendo 
           )         
end
    -- Insert statements for trigger here

END

go

