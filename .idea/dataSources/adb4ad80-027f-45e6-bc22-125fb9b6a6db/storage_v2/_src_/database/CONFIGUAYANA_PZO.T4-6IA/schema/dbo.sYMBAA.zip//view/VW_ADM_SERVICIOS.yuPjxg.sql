CREATE VIEW dbo.VW_ADM_SERVICIOS AS 
SELECT S.CodServ, S.Descrip, S.Descrip2, S.Descrip3,S.Descrip+IsNull(' '+S.Descrip2,'')+IsNull(' '+S.Descrip3,'') As DescripAll, (CASE SUBSTRING(S.DESCRIP,1,1) WHEN '?' THEN 1 ELSE 0 END) AS ESFREEP, 
S.Precio1, S.Precio2, S.Precio3,S.ESIMPORT, S.ACTIVO, s.EsVenta, s.EsCompra,S.Unidad, S.Clase, S.Costo, S.EsExento, I.CodInst, I.Descto,S.EsPorCost, S.usaServ, S.comision, S.esporcomi, S.fechauv, S.fechauc FROM SASERV S WITH (NOLOCK) INNER JOIN SAINSTA I ON S.CodInst = I.CodInst
go

