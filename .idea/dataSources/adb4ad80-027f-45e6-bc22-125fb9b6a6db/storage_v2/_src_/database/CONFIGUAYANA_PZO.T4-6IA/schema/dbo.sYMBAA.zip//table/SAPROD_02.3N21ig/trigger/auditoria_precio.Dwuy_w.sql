-- =============================================
-- Author:      <Equipo de IT>
-- Create date: <08/02/2021>
-- Description: <>
-- =============================================
create TRIGGER [dbo].[auditoria_precio]
   ON  [dbo].[SAPROD_02]
   for  UPDATE
AS 

BEGIN
SET NOCOUNT ON;

DECLARE 
@CODPROD AS VARCHAR(MAX), 
@COSTOA AS DECIMAL(28,3),
@COSTON AS DECIMAL(28,3),
@PRECIO1_B_A AS DECIMAL(28,3),
@PRECIO1_B_N AS DECIMAL(28,3),
@PRECIO1_P_A AS DECIMAL(28,3),
@PRECIO1_P_N AS DECIMAL(28,3),
@PRECIO2_B_A AS DECIMAL(28,3),
@PRECIO2_B_N AS DECIMAL(28,3),
@PRECIO2_P_A AS DECIMAL(28,3),
@PRECIO2_P_N AS DECIMAL(28,3),
@PRECIO3_B_A AS DECIMAL(28,3),
@PRECIO3_B_N AS DECIMAL(28,3),
@PRECIO3_P_A AS DECIMAL(28,3),
@PRECIO3_P_N AS DECIMAL(28,3),
@FECHA AS DATETIME

SELECT @CODPROD = CodProd from inserted

SELECT @COSTON = costo from inserted
SELECT @COSTOA = costo from deleted
--SET @COSTOA = (select top 1 Costo from SAPROD_02 where CodProd =@CODPROD)

SELECT @PRECIO1_B_N = precio1_b from inserted
SELECT @PRECIO1_B_A = precio1_b from deleted
--SET @PRECIO1_B_A = (select top 1 precio1_b from SAPROD_02 where CodProd =@CODPROD)

SELECT @PRECIO1_P_N = precio1_P from inserted
SELECT @PRECIO1_P_A = precio1_P from deleted
--SET @PRECIO1_P_A = (select top 1 precio1_P from SAPROD_02 where CodProd =@CODPROD)

SELECT @PRECIO2_B_N = precio2_b from inserted
SELECT @PRECIO2_B_A = precio2_b from deleted
--SET @PRECIO2_B_A = (select top 1 precio2_b from SAPROD_02 where CodProd =@CODPROD)

SELECT @PRECIO2_P_N = precio2_P from inserted
SELECT @PRECIO2_P_A = precio2_P from deleted
--SET @PRECIO2_P_A = (select top 1 precio2_P from SAPROD_02 where CodProd =@CODPROD)

SELECT @PRECIO3_B_N = precio3_b from inserted
SELECT @PRECIO3_B_A = precio3_b from deleted
--SET @PRECIO3_B_A = (select top 1 precio3_b from SAPROD_02 where CodProd =@CODPROD)

SELECT @PRECIO3_P_N = precio3_P from inserted
SELECT @PRECIO3_P_A = precio3_P from deleted
--SET @PRECIO3_P_A = (select top 1 precio3_P from SAPROD_02 where CodProd =@CODPROD)




       INSERT INTO [auditoria_divisas] (CodProd,costoa ,coston,precio1_b_a ,precio1_b_n,precio1_p_a ,precio1_p_n,precio2_b_a,precio2_b_n
	   ,precio2_p_a ,precio2_p_n ,precio3_b_a ,precio3_b_n ,precio3_p_a ,precio3_p_n ,fecha) VALUES (@CODPROD,@COSTOA, @COSTON, @PRECIO1_B_A, @PRECIO1_B_N,
	   @PRECIO1_P_A, @PRECIO1_P_N, @PRECIO2_B_A, @PRECIO2_B_N, @PRECIO2_P_A, @PRECIO2_P_N, @PRECIO3_B_A, @PRECIO3_B_N, @PRECIO3_P_A, @PRECIO3_P_N, GETDATE())
       
END

go

disable trigger auditoria_precio on SAPROD_02
go

