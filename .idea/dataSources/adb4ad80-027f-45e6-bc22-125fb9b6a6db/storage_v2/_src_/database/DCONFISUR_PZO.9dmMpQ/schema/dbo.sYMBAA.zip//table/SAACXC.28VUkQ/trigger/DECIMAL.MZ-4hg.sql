

CREATE TRIGGER [dbo].[DECIMAL]
   ON  [dbo].[SAACXC]
   AFTER INSERT
AS 
BEGIN
SET NOCOUNT ON;
--
declare @numfac varchar (20)
declare @totalitem decimal (28,4)
declare @pordes decimal (28,4)
declare @descue decimal (28,4)
declare @exento decimal (28,4)
declare @tgravab decimal (28,4)
declare @mtotax decimal (28,4)
declare @mtotot decimal (28,4)
set @numfac = (select TOP 1 NumeroD from SAITEMFAC where TipoFac = 'A' ORDER BY FechaE DESC)
set @totalitem = (select sum(TotalItem) totalitem from SAITEMFAC where NumeroD = @numfac and TipoFac = 'A')
set @pordes = (select (Descto1/monto) descuen from SAFACT where numerod in (@numfac))
set @exento = round((select texento from SAFACT where numerod in (@numfac)), 2)
set @descue = round(@totalitem*@pordes, 2)
set @tgravab = round(@totalitem-@descue-@exento, 2)
set @mtotax = round(@tgravab*(select MtoTax/100 from SATAXVTA where numerod in (@numfac)), 2)
set @mtotot = @tgravab+@mtotax+@exento
update SAFACT set monto = @totalitem, Descto1 = @descue, TGravable = @tgravab, MtoTax = @mtotax, MtoTotal = @mtotot where numerod = @numfac
update SATAXVTA set monto = @mtotax, TGravable = @tgravab where numerod = @numfac
update SAACXC set Monto = @mtotot, MontoNeto = @tgravab, MtoTax = @mtotax, BaseImpo = @totalitem where numerod = @numfac
--
END
go

disable trigger DECIMAL on SAACXC
go

