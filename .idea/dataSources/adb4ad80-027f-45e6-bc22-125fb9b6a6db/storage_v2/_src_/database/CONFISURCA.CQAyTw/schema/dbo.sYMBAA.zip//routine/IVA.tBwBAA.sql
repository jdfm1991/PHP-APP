CREATE function [dbo].[IVA] (@codvend varchar,@fechai date,@fechaf date)
Returns date -- Indicamos el tipo de parámetros que retornará la función.
as

Begin

 Declare @resultado date
 /*set @resultado  = (SELECT count(distinct(SAFACT.CodClie)) AS CODCLIE FROM SAFACT WHERE SAFACT.CodVend = @codvend AND TipoFac = 'A' AND SAFACT.CodClie IN 
(SELECT SACLIE.CodClie FROM SACLIE INNER JOIN SACLIE_01 ON SACLIE.CodClie = SACLIE_01.CodClie 
WHERE ACTIVO = 1 AND (SACLIE.CodVend = @codvend or Ruta_Alternativa = @codvend OR Ruta_Alternativa_2 = @codvend)) 
AND DATEADD(dd, 0, DATEDIFF(dd, 0, SAFACT.FechaE)) between @fechai and @fechaf AND NumeroD NOT IN 
(SELECT X.NumeroD FROM SAFACT AS X WHERE X.TipoFac = 'A' AND x.NumeroR is not NULL 
AND cast(X.Monto as int) = cast((select Z.Monto from SAFACT AS Z where Z.NumeroD = x.NumeroR and Z.TipoFac = 'B')as int)))*/
set @resultado = CONVERT(CHAR(10), @fechai, 103);
-- Cuando terminamos la función ponemos el Return
 Return (@resultado) -- Y la variable que devolverá la función @resultado.
End
go

