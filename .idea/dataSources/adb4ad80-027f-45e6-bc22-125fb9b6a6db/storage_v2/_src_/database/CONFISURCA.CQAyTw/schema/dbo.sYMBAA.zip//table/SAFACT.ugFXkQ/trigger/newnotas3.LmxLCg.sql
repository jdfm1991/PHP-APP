create trigger newnotas3 on dbo.SAFACT
for insert 
as
begin
declare @NUMEROD varchar(10)
select @NUMEROD=NUMEROD from inserted
update SAFACT
set mimpuesto = mtotax
where TIPOFAC='B'
end
go

