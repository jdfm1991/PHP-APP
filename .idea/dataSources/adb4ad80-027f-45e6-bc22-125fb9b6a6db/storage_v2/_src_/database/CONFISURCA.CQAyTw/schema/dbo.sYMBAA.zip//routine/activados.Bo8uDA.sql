CREATE FUNCTION [dbo].[activados](@codvend varchar)
RETURNS varchar 
AS 
-- Returns the stock level for the product.
BEGIN
    DECLARE @ret varchar;
    
    set @ret = @codvend;
        
     IF (@ret IS NULL) 
        SET @ret = '';
    RETURN @codvend;
END;
go

