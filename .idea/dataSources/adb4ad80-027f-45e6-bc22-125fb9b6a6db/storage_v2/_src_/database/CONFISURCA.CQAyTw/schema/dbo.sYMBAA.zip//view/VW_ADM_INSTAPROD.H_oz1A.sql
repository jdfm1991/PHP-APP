Create View dbo.VW_ADM_INSTAPROD AS 
 WITH CTEInsta AS
 (SELECT CodInst, InsPadre, Descrip, 0 AS HLevel,
         CAST(RIGHT(REPLICATE('0',4)+CONVERT(VARCHAR(4),CodInst),4) AS VARCHAR(MAX)) AS OrderByField
    FROM SAINSTA WITH (NOLOCK)
   WHERE (InsPadre=0) AND (TIPOINS=0)
   UNION ALL
  SELECT C.CodInst, C.InsPadre, C.Descrip,
         (CTE.HLevel+1) AS HLevel,
         CTE.OrderByField+
         CAST(RIGHT(REPLICATE('0',4)+CONVERT(VARCHAR(4),C.CodInst),4) AS VARCHAR(MAX)) AS OrderByField
    FROM SAINSTA C WITH (NOLOCK)
   INNER JOIN CTEInsta CTE ON
         CTE.CodInst=C.InsPadre
   WHERE (C.InsPadre IS NOT NULL) AND (C.TIPOINS=0))
 SELECT C.CodInst,C.InsPadre,C.Descrip,
        I.Descto,I.DEsComp,I.DEsSeri,I.DEsLote,
        I.DEsComi,I.DEsCorrel,I.DigitosC,I.Nivel,I.DEsTabla,I.TipoIns,
        C.HLevel, C.OrderByField
   FROM CTEInsta C WITH (NOLOCK)
  INNER JOIN SAINSTA I ON
        I.CODINST=C.CODINST
go

