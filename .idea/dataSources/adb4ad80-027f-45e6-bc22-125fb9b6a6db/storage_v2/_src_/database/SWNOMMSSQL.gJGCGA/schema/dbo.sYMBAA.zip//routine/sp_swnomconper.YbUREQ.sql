
CREATE PROCEDURE sp_swnomconper @parEstado VARCHAR(50) AS

DECLARE @NameTable sysname, @IDTable INT, @NameField sysname, @Y INT,
@SQLQry VARCHAR(8000), @SQLFields VARCHAR(8000),@SQLFieldsA VARCHAR(8000), @Estado VARCHAR(20),
@NumNom VARCHAR(10), @Ceros VARCHAR(10), @CodTip INT, @Total INT, @ORDEN INT

delete from SWNOMMSSQL999999.dbo.swnomper
delete from SWNOMMSSQL999999.dbo.swnomfam
delete from SWNOMMSSQL999999.dbo.swnomHVA
delete from SWNOMMSSQL999999.dbo.swnomPPE
SET @Ceros = '000000'
SET @Estado = @parEstado
DECLARE cur_CodTip CURSOR FOR
Select S.CodTip
From SWNOMMSSQL.dbo.SwNomTip S
Where S.CodTip <> 999999 and markar=1
Order By S.CodTip
OPEN cur_CodTip
FETCH NEXT FROM cur_CodTip
INTO @CodTip
while @@fetch_status=0 begin
SET @NumNom = SUBSTRING(@Ceros,1, LEN(@Ceros)-LEN(CONVERT(VARCHAR,@CodTip)))+CONVERT(VARCHAR,@CodTip)
IF EXISTS( Select * From master.dbo.sysdatabases Where Name = ('SWNOMMSSQL'+@NumNom)) Begin
DECLARE cur_tables cursor for
Select ID, Name,
Case When Name='SwNomPer' Then 1 else 2 end as Orden  From SWNOMMSSQL999999.dbo.SysObjects
Where XType = 'U' And
Name In ('SwNomPer','SwNomFam','SwNomHVA','SwNomPPE')
Order by 3
open cur_tables
fetch next from cur_tables
into @IDTable, @NameTable,@ORDEN
while @@fetch_status = 0 begin
DECLARE cur_fields cursor for
Select Name From SWNOMMSSQL999999.dbo.SysColumns
Where ID = @IDTable
Order by Name
open cur_fields
fetch next from cur_fields
into @NameField
SET @SQLFields = ''
SET @SQLFieldsA = ''
while @@fetch_status = 0 begin
SET @SQLFields = @SQLFields + @NameField + ','
IF @NameField = 'CONTROL'
SET @SQLFieldsA = @SQLFieldsA +'CONVERT(INT,CONVERT(VARCHAR,A.'+@NameField+')+CONVERT(VARCHAR,'+CONVERT(VARCHAR,@CodTip)+')), '
ELSE
SET @SQLFieldsA = @SQLFieldsA + 'A.'+@NameField + ', '

fetch next from cur_fields
into @NameField
end
SET @SQLFields = SUBSTRING(@SQLFields,1,LEN(@SQLFields)-1)
SET @SQLFieldsA = SUBSTRING(@SQLFieldsA,1,LEN(@SQLFieldsA)-1)
SET @NameTable = UPPER(@NameTable)
IF (@NameTable = 'SWNOMPER')
SET @SQLQry = ' INSERT INTO SWNOMMSSQL999999.dbo.'+@NameTable+'('+@SQLFields+') '+
' Select '+@SQLFields+' From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+
' Where SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+'.Estado IN (SELECT SITUACION FROM SWNOMMSSQL.dbo.SWNOMSIT WHERE MARKAR=1) '+
'  And SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+'.Ficha COLLATE DATABASE_DEFAULT NOT IN (Select Ficha From SWNOMMSSQL999999.dbo.'+@NameTable+')'
ELSE IF (@NameTable = 'SWNOMFAM')
SET @SQLQry = ' INSERT INTO swnommssql999999.dbo.'+@NameTable+' ('+@SQLFields+') '+
' Select '+@SQLFieldsA+' From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
' INNER JOIN SWNOMMSSQL'+@NumNom+'.dbo.SWNOMPER AS B ON B.FICHA=A.FICHA COLLATE DATABASE_DEFAULT '+
' Where B.Ficha COLLATE DATABASE_DEFAULT  IN (Select Ficha From swnommssql999999.dbo.SWNOMPER)'
ELSE IF (@NameTable = 'SWNOMHVA')
SET @SQLQry = ' INSERT INTO swnommssql999999.dbo.'+@NameTable+' ('+@SQLFields+') '+
' Select '+@SQLFieldsA+' From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
' INNER JOIN SWNOMMSSQL'+@NumNom+'.dbo.SWNOMPER AS B ON B.FICHA=A.FICHA COLLATE DATABASE_DEFAULT '+
' Where B.Ficha COLLATE DATABASE_DEFAULT  IN (Select Ficha From swnommssql999999.dbo.SWNOMPER)'
ELSE IF (@NameTable = 'SWNOMPPE')
SET @SQLQry = ' INSERT INTO swnommssql999999.dbo.'+@NameTable+' ('+@SQLFields+') '+
' Select '+@SQLFieldsA+' From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
' INNER JOIN SWNOMMSSQL'+@NumNom+'.dbo.SWNOMPER AS B ON B.FICHA=A.FICHA COLLATE DATABASE_DEFAULT '+
' Where B.Ficha COLLATE DATABASE_DEFAULT  IN (Select Ficha From swnommssql999999.dbo.SWNOMPER)'
exec(@SQLQry)
print @SQLQry
close cur_fields
deallocate cur_fields
fetch next from cur_tables
into  @IDTable, @NameTable,@ORDEN
end
close cur_tables
deallocate cur_tables
End
FETCH NEXT FROM cur_CodTip
INTO @CodTip
end
close cur_CodTip
deallocate cur_CodTip

go

