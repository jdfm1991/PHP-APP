
CREATE PROCEDURE dbo.sp_swnomContador
@DATABASE NVARCHAR(100)
AS
BEGIN
SET NOCOUNT ON;
DECLARE @PARAMETRO			NVARCHAR(300)
DECLARE @TODOS				int
DECLARE @ACTIVOS			int
DECLARE @NUEVOS				int
DECLARE @SUSPENDIDOS		int
DECLARE @JUBILADOS			int
DECLARE @VACACIONES			int
DECLARE @RETIRADOS			int

DECLARE @NORMAL_ABIERTAS	int
DECLARE @NORMAL_CERRADAS	int
DECLARE @EGRESO_ABIERTAS	int
DECLARE @EGRESO_CERRADAS	int
DECLARE @VAC_ABIERTAS		int
DECLARE @VAC_CERRADAS		int
DECLARE @PREST_ABIERTAS		int
DECLARE @PREST_CERRADAS		int

DECLARE @SQLSTRING NVARCHAR(MAX);

-- ===============================================================
-- TODOS
-- ===============================================================
SET @SQLSTRING = N'SELECT @TODOSOUT = COUNT(*) FROM ' + @DATABASE + N'.dbo.swnomper ' ;
SET @PARAMETRO = N'@TODOSOUT INT OUTPUT' ;

EXECUTE sp_executesql
@SQLSTRING
,@PARAMETRO
,@TODOSOUT = @TODOS OUTPUT
-- ===============================================================
-- ACTIVOS
-- ===============================================================
SET @SQLSTRING = N'SELECT @TODOSOUT = COUNT(*) FROM ' + @DATABASE + N'.dbo.swnomper WHERE UPPER(ESTADO) = ' + N'''ACTIVO'''  ;

EXECUTE sp_executesql
@SQLSTRING
,@PARAMETRO
,@TODOSOUT = @ACTIVOS OUTPUT

-- ===============================================================
-- SUSPENDIDOS
-- ===============================================================
SET @SQLSTRING = N'SELECT @TODOSOUT = COUNT(*) FROM ' + @DATABASE + N'.dbo.swnomper WHERE UPPER(ESTADO) = ' + N'''SUSPENDIDO'''  ;

EXECUTE sp_executesql
@SQLSTRING
,@PARAMETRO
,@TODOSOUT = @SUSPENDIDOS OUTPUT

-- ===============================================================
-- VACACIONES
-- ===============================================================
SET @SQLSTRING = N'SELECT @TODOSOUT = COUNT(*) FROM ' + @DATABASE + N'.dbo.swnomper WHERE UPPER(ESTADO) = ' + N'''VACACIONES'''  ;

EXECUTE sp_executesql
@SQLSTRING
,@PARAMETRO
,@TODOSOUT = @VACACIONES OUTPUT

-- ===============================================================
-- NOMINAS NORMAL ABIERTAS
-- ===============================================================
SET @SQLSTRING=	  N'SELECT @SALIDAOUT= COUNT(*) FROM '+ @DATABASE + N'.dbo.swnomhmv WHERE STATUS =''A'' AND TIPNOM = ''0'''
SET @PARAMETRO =  N'@SALIDAOUT INT OUTPUT'
EXECUTE dbo.SP_EXECUTESQL @SQLSTRING
,@PARAMETRO
,@SALIDAOUT = @NORMAL_ABIERTAS OUTPUT

-- ===============================================================
-- NOMINAS NORMAL CERRADAS
-- ===============================================================
SET @SQLSTRING= N'SELECT @SALIDAOUT= COUNT(*) FROM '+ @DATABASE + N'.dbo. swnomhmv WHERE STATUS =''C'' AND TIPNOM = ''0'''
EXECUTE dbo.SP_EXECUTESQL @SQLSTRING
,@PARAMETRO
,@SALIDAOUT = @NORMAL_CERRADAS OUTPUT


-- ===============================================================
-- NOMINAS EGRESO ABIERTAS
-- ===============================================================
SET @SQLSTRING=	  N'SELECT @SALIDAOUT= COUNT(*) FROM '+ @DATABASE + N'.dbo.swnomhmv WHERE STATUS =''A'' AND TIPNOM = ''4'''
SET @PARAMETRO =  N'@SALIDAOUT INT OUTPUT'
EXECUTE dbo.SP_EXECUTESQL @SQLSTRING
,@PARAMETRO
,@SALIDAOUT = @EGRESO_ABIERTAS OUTPUT

-- ===============================================================
-- NOMINAS EGRESO CERRADAS
-- ===============================================================
SET @SQLSTRING= N'SELECT @SALIDAOUT= COUNT(*) FROM '+ @DATABASE + N'.dbo. swnomhmv WHERE STATUS =''C'' AND TIPNOM = ''4'''
EXECUTE dbo.SP_EXECUTESQL @SQLSTRING
,@PARAMETRO
,@SALIDAOUT = @EGRESO_CERRADAS OUTPUT

-- ===============================================================
-- NOMINAS VACACIONES ABIERTAS
-- ===============================================================
SET @SQLSTRING=	  N'SELECT @SALIDAOUT= COUNT(*) FROM '+ @DATABASE + N'.dbo.swnomhmv WHERE STATUS =''A'' AND TIPNOM = ''2'''
SET @PARAMETRO =  N'@SALIDAOUT INT OUTPUT'
EXECUTE dbo.SP_EXECUTESQL @SQLSTRING
,@PARAMETRO
,@SALIDAOUT = @VAC_ABIERTAS OUTPUT

-- ===============================================================
-- NOMINAS VACACIONES CERRADAS
-- ===============================================================
SET @SQLSTRING= N'SELECT @SALIDAOUT= COUNT(*) FROM '+ @DATABASE + N'.dbo. swnomhmv WHERE STATUS =''C'' AND TIPNOM = ''2'''
EXECUTE dbo.SP_EXECUTESQL @SQLSTRING
,@PARAMETRO
,@SALIDAOUT = @VAC_CERRADAS OUTPUT

-- ===============================================================
-- NOMINAS PRESTACIONES ABIERTAS
-- ===============================================================
SET @SQLSTRING=	  N'SELECT @SALIDAOUT= COUNT(*) FROM '+ @DATABASE + N'.dbo.swnomhmv WHERE STATUS =''A'' AND TIPNOM = ''3'''
SET @PARAMETRO =  N'@SALIDAOUT INT OUTPUT'
EXECUTE dbo.SP_EXECUTESQL @SQLSTRING
,@PARAMETRO
,@SALIDAOUT = @PREST_ABIERTAS OUTPUT

-- ===============================================================
-- NOMINAS PRESTACIONES CERRADAS
-- ===============================================================
SET @SQLSTRING= N'SELECT @SALIDAOUT= COUNT(*) FROM '+ @DATABASE + N'.dbo. swnomhmv WHERE STATUS =''C'' AND TIPNOM = ''3'''
EXECUTE dbo.SP_EXECUTESQL @SQLSTRING
,@PARAMETRO
,@SALIDAOUT = @PREST_CERRADAS OUTPUT


TRUNCATE TABLE dbo.DUMMYES;

INSERT INTO dbo.DUMMYES (CAMPO01,CAMPO02,CAMPO03,CAMPO04,CAMPO05,CAMPO06,CAMPO07,CAMPO08,CAMPO09,CAMPO10,CAMPO11,CAMPO12,CAMPO13)
SELECT
convert(VARCHAR,@TODOS)
,convert(VARCHAR,@ACTIVOS)
,convert(VARCHAR,@VACACIONES)
,convert(VARCHAR,@SUSPENDIDOS)
,convert(VARCHAR,@TODOS -(@ACTIVOS +  @SUSPENDIDOS  + @VACACIONES ) )
,convert(VARCHAR,@NORMAL_ABIERTAS)
,convert(VARCHAR,@NORMAL_CERRADAS)
,convert(VARCHAR,@EGRESO_ABIERTAS)
,convert(VARCHAR,@EGRESO_CERRADAS)
,convert(VARCHAR,@VAC_ABIERTAS)
,convert(VARCHAR,@VAC_CERRADAS)
,convert(VARCHAR,@PREST_ABIERTAS)
,convert(VARCHAR,@PREST_CERRADAS)

END
go

