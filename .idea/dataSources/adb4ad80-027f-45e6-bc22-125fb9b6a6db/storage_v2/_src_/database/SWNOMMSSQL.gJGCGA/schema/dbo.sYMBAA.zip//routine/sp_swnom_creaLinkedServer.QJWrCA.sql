
	-- =============================================
	-- Author:		CARLOS PACHECO
	-- Create date: 10/07/2016
	-- Description:	Crea linked servers de tipos de nómina
	-- =============================================
	CREATE PROCEDURE [dbo].[sp_swnom_creaLinkedServer] 
		@nameLink sysname 
		,@Servidor sysname
	AS
	BEGIN
		SET NOCOUNT ON;
		IF (LEN(@Servidor) > 0 AND LEN(@nameLink) > 0 )
		BEGIN
			IF EXISTS(SELECT * FROM sys.servers WHERE name = @nameLink)
			EXEC master.sys.sp_dropserver @nameLink,'droplogins'  
			EXEC sp_addlinkedserver     
				@server=@nameLink,   
				@srvproduct=N'',  
				@provider=N'SQLNCLI',
				@datasrc= @Servidor ;
		END
		ELSE PRINT 'ERROR: Falta al menos, un parámetro'
	END
    go

