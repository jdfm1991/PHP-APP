
CREATE PROCEDURE sp_swnombuscaficha @parFicha VARCHAR(15), @parCodTip INT AS

DECLARE @NumNom VARCHAR(10), @Ceros VARCHAR(10), @CodTip INT, @Total INT,
@Ficha VARCHAR(15), @FichaF VARCHAR(15), @TotalF  INT, @TotalS VARCHAR(15)
create table #tmp_per
(
Ficha VARCHAR(15)
)

create table #tmp_tableexist
(
Name sysname
)


SET @Ceros = '000000'
SET @FichaF = @parFicha
DECLARE cur_CodTip CURSOR FOR
Select N.CodTip
From SWNOMMSSQL.dbo.SwNomTip as N
Where N.CodTip <> 999999 and N.CodTip < 100000
Order By N.CodTip
OPEN cur_CodTip
FETCH NEXT FROM cur_CodTip
INTO @CodTip
while @@fetch_status=0 begin
SET @NumNom = SUBSTRING(@Ceros,1, LEN(@Ceros)-LEN(CONVERT(VARCHAR,@CodTip)))+CONVERT(VARCHAR,@CodTip)
insert into #tmp_tableexist
EXEC('Select Name From master.dbo.sysdatabases Where Name ='''+'SWNOMMSSQL'+@NumNom+'''')
if exists(Select Name From #tmp_tableexist)
begin
insert into #tmp_per
EXEC('Select Ficha From SWNOMMSSQL'+@NumNom+'.dbo.SWNOMPER as P Where P.Ficha = '''+@FichaF+'''')
end
FETCH NEXT FROM cur_CodTip
INTO @CodTip
delete from #tmp_tableexist
end
close cur_CodTip
deallocate cur_CodTip
SET @NumNom = SUBSTRING(@Ceros,1, LEN(@Ceros)-LEN(CONVERT(VARCHAR,@parCodTip)))+CONVERT(VARCHAR,@parCodTip)
EXEC('delete SWNOMMSSQL'+@NumNom+'.dbo.dummyloc')
select @TotalF = COUNT(Ficha) From #tmp_per
SET @TotalS = ''''+CONVERT(VARCHAR,@TotalF)+''''
EXEC('insert into SWNOMMSSQL'+@NumNom+'.dbo.dummyloc Select '+@TotalS)
drop table #tmp_per
drop table #tmp_tableexist
go

