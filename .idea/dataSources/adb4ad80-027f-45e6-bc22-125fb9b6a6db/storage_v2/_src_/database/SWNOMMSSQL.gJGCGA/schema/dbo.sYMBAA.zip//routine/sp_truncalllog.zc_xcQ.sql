
CREATE PROCEDURE sp_truncalllog AS

DECLARE @NameTable sysname, @IDTable INT, @NameField sysname, @Y INT,
@SQLQry VARCHAR(8000), @SQLFields VARCHAR(8000),
@NumNom VARCHAR(10), @Ceros VARCHAR(10), @CodTip INT, @Total INT

SET @Ceros = '000000'

DECLARE cur_CodTip CURSOR FOR
Select CodTip From SWNOMMSSQL.dbo.SwNomTip
Order By CodTip
OPEN cur_CodTip
FETCH NEXT FROM cur_CodTip
INTO @CodTip
while @@fetch_status=0 begin
SET @NumNom = SUBSTRING(@Ceros,1, LEN(@Ceros)-LEN(CONVERT(VARCHAR,@CodTip)))+CONVERT(VARCHAR,@CodTip)
IF EXISTS( Select * From master.dbo.sysdatabases Where Name = ('SWNOMMSSQL'+@NumNom)) Begin
print 'Trucando el Archivo de transacciones de la base de datos SWNOMMSSQL'+@NumNom
exec(
'SET NOCOUNT ON
DECLARE @NombreLogicoArchivo sysname,
@MaxMinutos INT,
@NuevoTamano INT

USE SWNOMMSSQL'+@NumNom+'
SELECT  @NombreLogicoArchivo = ''SWNOMMSSQL'+@NumNom+'_log'',
@MaxMinutos = 10,    -- LÝmite de tiempo permitido para dar la vuelta al registro.
@NuevoTamano = 1   -- en MB

-- Configuraci¾n e inicio
DECLARE @TamanoOriginal int
SELECT @TamanoOriginal = size -- en pßginas de 8 KB
FROM sysfiles
WHERE name = @NombreLogicoArchivo
SELECT '' El tama±o original del registro de '' + db_name() + '' es '' + CONVERT(VARCHAR(30),@TamanoOriginal) + '' pßginas de 8 KB ¾ '' + CONVERT(VARCHAR(30),(@TamanoOriginal *8/1024)) + ''MB''
FROM sysfiles
WHERE name = @NombreLogicoArchivo

if exists(select * from sysobjects where name = ''DummyTrans'' and Xtype = ''U'')
drop table DummyTrans

CREATE TABLE DummyTrans(DummyColumna char (8000) not null)


-- Dar la vuelta al registro y truncarlo.
DECLARE @Contador   INT,
@HoraInicio DATETIME,
@TruncReg  VARCHAR(255)
SELECT  @HoraInicio = GETDATE(),@TruncReg = ''BACKUP LOG '' + db_name() + '' WITH TRUNCATE_ONLY''
-- Intentar una reducci¾n inicial.
DBCC SHRINKFILE (@NombreLogicoArchivo, @NuevoTamano)
EXEC (@TruncReg)
-- Dar la vuelta al registro, si es necesario.
-- no se ha excedido el mßximo tiempo establecido
WHILE     @MaxMinutos > DATEDIFF (mi, @HoraInicio, GETDATE())
-- no se ha reducido el registro
AND @TamanoOriginal = (SELECT size FROM sysfiles WHERE name = @NombreLogicoArchivo)
-- El valor pasado para el tama±o nuevo es mßs peque±o que el tama±o actual.
AND (@TamanoOriginal * 8 /1024) > @NuevoTamano
BEGIN -- Bucle externo.
SELECT @Contador = 0 WHILE  ((@Contador < @TamanoOriginal / 16) AND (@Contador < 50000))

BEGIN -- Actualizaci¾n
-- Como es un campo de tipo char, inserta 8000 bytes.

INSERT DummyTrans VALUES (''Llenar registro'')
DELETE DummyTrans
SELECT @Contador = @Contador + 1
END   -- Actualizaci¾n Probar si un truncamiento reduce de tama±o el registro.
EXEC (@TruncReg)
END   -- Bucle externo

SELECT '' El tama±o final del registro de '' + db_name() + '' es de '' + CONVERT(VARCHAR(30),size) + '' pßginas de 8 KB ¾ '' + CONVERT(VARCHAR(30),(size*8/1024)) + ''MB''
FROM sysfiles
WHERE name = @NombreLogicoArchivo
DROP TABLE DummyTrans
PRINT ''*** RECUERDE: DEBE REALIZAR UNA COPIA DE SEGURIDAD COMPLETA DE LA BASE DE DATOS***''
SET NOCOUNT OFF
')
End
FETCH NEXT FROM cur_CodTip
INTO @CodTip
end
close cur_CodTip
deallocate cur_CodTip
go

