
CREATE PROCEDURE sp_trunclog @prmNameLog sysname AS
SET NOCOUNT ON
DECLARE @NombreLogicoArchivo sysname,
@MaxMinutos INT,
@NuevoTamano INT


-- Indique aquÝ su configuraci¾n.
-- Use sp_helpfile para identificar el nombre de archivo l¾gico que desea reducir.
SELECT  @NombreLogicoArchivo = @prmNameLog,
@MaxMinutos = 10,    -- LÝmite de tiempo permitido para dar la vuelta al registro.
@NuevoTamano = 1   -- en MB

-- Configuraci¾n e inicio
DECLARE @TamanoOriginal int
SELECT @TamanoOriginal = size -- en pßginas de 8 KB
FROM sysfiles
WHERE name = @NombreLogicoArchivo
SELECT ' El tama±o original del registro de ' + db_name() + ' es ' + CONVERT(VARCHAR(30),@TamanoOriginal) + ' pßginas de 8 KB ¾ ' + CONVERT(VARCHAR(30),(@TamanoOriginal *8/1024)) + 'MB'
FROM sysfiles
WHERE name = @NombreLogicoArchivo
if exists(select * from sysobjects where name = 'DummyTrans' and Xtype = 'U')
drop table DummyTrans

CREATE TABLE DummyTrans(DummyColumna char (8000) not null)


-- Dar la vuelta al registro y truncarlo.
DECLARE @Contador   INT,
@HoraInicio DATETIME,
@TruncReg  VARCHAR(255)
SELECT  @HoraInicio = GETDATE(),@TruncReg = 'BACKUP LOG ' + db_name() + ' WITH TRUNCATE_ONLY'
-- Intentar una reducci¾n inicial.
DBCC SHRINKFILE (@NombreLogicoArchivo, @NuevoTamano)
EXEC (@TruncReg)
-- Dar la vuelta al registro, si es necesario.
-- no se ha excedido el mßximo tiempo establecido
WHILE     @MaxMinutos > DATEDIFF (mi, @HoraInicio, GETDATE())
-- no se ha reducido el registro
AND @TamanoOriginal = (SELECT size FROM sysfiles WHERE name = @NombreLogicoArchivo)
-- El valor pasado para el tama±o nuevo es mßs peque±o que el tama±o actual.
AND (@TamanoOriginal * 8 /1024) > @NuevoTamano
BEGIN -- Bucle externo.
SELECT @Contador = 0 WHILE  ((@Contador < @TamanoOriginal / 16) AND (@Contador < 50000))

BEGIN -- Actualizaci¾n
-- Como es un campo de tipo char, inserta 8000 bytes.

INSERT DummyTrans VALUES ('Llenar registro')
DELETE DummyTrans
SELECT @Contador = @Contador + 1
END   -- Actualizaci¾n Probar si un truncamiento reduce de tama±o el registro.
EXEC (@TruncReg)
END   -- Bucle externo

SELECT ' El tama±o final del registro de ' + db_name() + ' es de ' + CONVERT(VARCHAR(30),size) + ' pßginas de 8 KB ¾ ' + CONVERT(VARCHAR(30),(size*8/1024)) + 'MB'
FROM sysfiles
WHERE name = @NombreLogicoArchivo
DROP TABLE DummyTrans
PRINT '*** RECUERDE: DEBE REALIZAR UNA COPIA DE SEGURIDAD COMPLETA DE LA BASE DE DATOS***'
SET NOCOUNT OFF
go

