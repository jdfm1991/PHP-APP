
CREATE PROCEDURE sp_swnomeliminarnominas  AS

begin tran eliminar_nominas

delete from swnommssql999999.dbo.swnommdt
Where CodNom In (Select CodNom from swnommssql999999.dbo.swnomhmv where markar <> 1)
delete from swnommssql999999.dbo.swnomhmd
Where CodNom In (Select CodNom from swnommssql999999.dbo.swnomhmv where markar <> 1)
delete from swnommssql999999.dbo.swnomhmv where markar <> 1

IF @@ERROR = 0
commit tran eliminar_nominas
ELSE
rollback tran eliminar_nominas
go

