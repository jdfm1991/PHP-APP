
CREATE PROCEDURE sp_swnomgetnextcontpre @parContPre INT OUTPUT, @parCodTip INT, @parNameT VARCHAR(255) AS

declare @ContPre INT, @SQL VARCHAR(8000), @Next INT, @NumNom VARCHAR(255), @CNT INT

create table #numprestamo (
Numpre INT
)

SET @NumNom = CONVERT(VARCHAR,@parCodTip)
SET @NumNom = REPLICATE('0',6-LEN(@NumNom))+@NumNom
SET @NumNom = 'SWNOMMSSQL'+@NumNom+'.dbo.'+@parNameT

SET @ContPre = @parContPre+1

SET @SQL = ' Select DISTINCT Numpre From '+@NumNom+
' Where Numpre = '+CONVERT(VARCHAR,@ContPre)

SET @Next  = 1

WAITFOR DELAY '00:00:00.005'

WHILE @Next = 1 BEGIN
Insert Into #numprestamo
EXEC (@SQL)
SELECT @CNT = COUNT(Numpre) From #numprestamo
if @CNT> 0 begin
SET @ContPre = @ContPre + 1
SET @SQL = ' Select DISTINCT Numpre From '+@NumNom+
' Where Numpre = '+CONVERT(VARCHAR,@ContPre)
delete from #numprestamo
end
Else
SET @Next  = 0
END

SELECT @parContPre = @ContPre

drop table #numprestamo
go

