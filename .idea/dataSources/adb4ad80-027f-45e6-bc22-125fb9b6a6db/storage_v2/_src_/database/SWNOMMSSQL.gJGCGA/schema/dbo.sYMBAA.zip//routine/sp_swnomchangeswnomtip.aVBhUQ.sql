
create procedure sp_swnomchangeswnomtip @parServidor VARCHAR(255), @parUser VARCHAR(225), @parPass VARCHAR(255),
@parServidorN VARCHAR(255), @parUserN VARCHAR(225), @parPassN VARCHAR(255) As


update swnomtip set OWNER = replace(replace(replace(owner,@parServidor,@parServidorN),@parUser,@parUserN),@parPass,@parPassN)

go

