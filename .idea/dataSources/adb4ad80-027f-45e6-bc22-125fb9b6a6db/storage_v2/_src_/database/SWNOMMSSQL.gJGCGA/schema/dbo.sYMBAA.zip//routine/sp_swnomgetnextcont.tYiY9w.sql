
CREATE PROCEDURE sp_swnomgetnextcont @CodTip INT,
@Year INT OUTPUT,
@Mes INT OUTPUT,
@Dia INT OUTPUT,
@Hora INT OUTPUT,
@Min INT OUTPUT,
@Seg INT OUTPUT,
@Mili INT OUTPUT,
@parNumControl VARCHAR(15) OUTPUT AS

declare @NumControl VARCHAR(15), @SQL VARCHAR(8000), @NumNom VARCHAR(50), @Next INT

create table #numcontrol (
NumControl VARCHAR(15)
)

SET @NumNom = CONVERT(VARCHAR,@CodTip)
SET @NumNom = REPLICATE('0',6-LEN(@NumNom))+@NumNom
SET @NumNom = 'SWNOMMSSQL'+@NumNom+'.dbo.SWNOMPTA'

SET @Mili = @Mili + 1
IF @Mili = 1000  BEGIN
SET @Seg = @Seg + 1
SET @Mili = 1
END
IF @Seg = 60  BEGIN
SET @Min = @Min +  1
SET @Seg = 1
END
IF @Min = 60  BEGIN
SET @Hora = @Hora + 1
SET @Min = 1
END
IF @Hora = 24  BEGIN
SET @DIA = @DIA + 1
SET @Hora = 1
END
IF @Dia > 30  BEGIN
SET @Mes = @Mes + 1
SET @Dia = 1
END
IF @Mes > 12  BEGIN
SET @Year = @Year + 1
SET @Mes = 1
END

SET @NumControl = CONVERT(VARCHAR,@Year)+CONVERT(VARCHAR,@Mes)+CONVERT(VARCHAR,@Dia)+
CONVERT(VARCHAR,@Hora)+CONVERT(VARCHAR,@Min)+CONVERT(VARCHAR,@Seg)+
CONVERT(VARCHAR,@Mili)

SET @SQL = ' Select NumControl From '+@NumNom+
' Where NumControl = '+''''+@NumControl+''''

SET @Next  = 1

WAITFOR DELAY '00:00:00.005'

WHILE @Next = 1 BEGIN
Insert Into #numcontrol
exec (@SQL)
if (Select COUNT(NumControl) From #numcontrol) > 0 begin
SET @Mili = @Mili + 1
IF @Mili = 1000  BEGIN
SET @Seg = @Seg + 1
SET @Mili = 1
END
IF @Seg = 60  BEGIN
SET @Min = @Min +  1
SET @Seg = 1
END
IF @Min = 60  BEGIN
SET @Hora = @Hora + 1
SET @Min = 1
END
IF @Hora = 24  BEGIN
SET @DIA = @DIA + 1
SET @Hora = 1
END
IF @Dia > 30  BEGIN
SET @Mes = @Mes + 1
SET @Dia = 1
END
IF @Mes > 12  BEGIN
SET @Year = @Year + 1
SET @Mes = 1
END
SET @NumControl = CONVERT(VARCHAR,@Year)+CONVERT(VARCHAR,@Mes)+CONVERT(VARCHAR,@Dia)+
CONVERT(VARCHAR,@Hora)+CONVERT(VARCHAR,@Min)+CONVERT(VARCHAR,@Seg)+
CONVERT(VARCHAR,@Mili)

SET @SQL = ' Select NumControl From '+@NumNom+
' Where NumControl = '+''''+@NumControl+''''
delete from #numcontrol
end
Else
SET @Next  = 0
END

SET @parNumControl = @NumControl

drop table #numcontrol
go

