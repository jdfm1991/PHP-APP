
CREATE PROCEDURE dbo.sp_QryCuentasEstados
@DATABASE NVARCHAR(100)

AS
BEGIN
SET NOCOUNT ON;
DECLARE @PARAMETRO			NVARCHAR(300)
DECLARE @TODOS				int
DECLARE @ACTIVOS			int
DECLARE @NUEVOS				int
DECLARE @SUSPENDIDOS		int
DECLARE @JUBILADOS			int
DECLARE @VACACIONES			int
DECLARE @RETIRADOS			int

DECLARE @SQLSTRING NVARCHAR(MAX);

-- ===============================================================
-- TODOS
-- ===============================================================
SET @SQLSTRING = N'SELECT @TODOSOUT = COUNT(*) FROM ' + @DATABASE + N'.dbo.swnomper ' ;
SET @PARAMETRO = N'@TODOSOUT INT OUTPUT' ;

EXECUTE sp_executesql
@SQLSTRING
,@PARAMETRO
,@TODOSOUT = @TODOS OUTPUT
-- ===============================================================
-- ACTIVOS
-- ===============================================================
SET @SQLSTRING = N'SELECT @TODOSOUT = COUNT(*) FROM ' + @DATABASE + N'.dbo.swnomper WHERE UPPER(ESTADO) = ' + N'''ACTIVO'''  ;

EXECUTE sp_executesql
@SQLSTRING
,@PARAMETRO
,@TODOSOUT = @ACTIVOS OUTPUT
-- ===============================================================
-- RETIRADO
-- ===============================================================
SET @SQLSTRING = N'SELECT @TODOSOUT = COUNT(*) FROM ' + @DATABASE + N'.dbo.swnomper WHERE UPPER(ESTADO) = ' + N'''INACTIVO'''  ;

EXECUTE sp_executesql
@SQLSTRING
,@PARAMETRO
,@TODOSOUT = @RETIRADOS OUTPUT
-- ===============================================================
-- SUSPENDIDOS
-- ===============================================================
SET @SQLSTRING = N'SELECT @TODOSOUT = COUNT(*) FROM ' + @DATABASE + N'.dbo.swnomper WHERE UPPER(ESTADO) = ' + N'''SUSPENDIDO'''  ;

EXECUTE sp_executesql
@SQLSTRING
,@PARAMETRO
,@TODOSOUT = @SUSPENDIDOS OUTPUT
-- ===============================================================
-- JUBILADOS
-- ===============================================================
SET @SQLSTRING = N'SELECT @TODOSOUT = COUNT(*) FROM ' + @DATABASE + N'.dbo.swnomper WHERE UPPER(ESTADO) = ' + N'''JUBILADOS'''  ;

EXECUTE sp_executesql
@SQLSTRING
,@PARAMETRO
,@TODOSOUT = @JUBILADOS OUTPUT
-- ===============================================================
-- VACACIONES
-- ===============================================================
SET @SQLSTRING = N'SELECT @TODOSOUT = COUNT(*) FROM ' + @DATABASE + N'.dbo.swnomper WHERE UPPER(ESTADO) = ' + N'''VACACIONES'''  ;

EXECUTE sp_executesql
@SQLSTRING
,@PARAMETRO
,@TODOSOUT = @VACACIONES OUTPUT
-- ===============================================================
-- NUEVOS
-- ===============================================================
SET @SQLSTRING = N'SELECT @TODOSOUT = COUNT(*) FROM ' + @DATABASE + N'.dbo.swnomper WHERE UPPER(ESTADO) = ' + N'''NUEVO'''  ;

EXECUTE sp_executesql
@SQLSTRING
,@PARAMETRO
,@TODOSOUT = @NUEVOS OUTPUT

TRUNCATE TABLE dbo.DUMMYES;

INSERT INTO dbo.DUMMYES(CAMPO01,CAMPO02,CAMPO03,CAMPO04,CAMPO05,CAMPO06,CAMPO07,CAMPO08)
SELECT
convert(VARCHAR,@TODOS)
,convert(VARCHAR,@ACTIVOS)
,convert(VARCHAR,@RETIRADOS)
,convert(VARCHAR,@SUSPENDIDOS)
,convert(VARCHAR,@JUBILADOS)
,convert(VARCHAR,@VACACIONES)
,convert(VARCHAR,@NUEVOS)
,convert(VARCHAR,@TODOS -(@ACTIVOS + @NUEVOS + @SUSPENDIDOS + @JUBILADOS + @VACACIONES + @RETIRADOS ) )

END
go

