
CREATE PROCEDURE dbo.spu_AsignaNacionalidad 
	-- Add the parameters for the stored procedure here
	@Nacionalidad varchar(80)
AS
BEGIN
		SET NOCOUNT ON;
		PRINT 'Actualizando filas de Nacionalidad en gselegibles'
        PRINT '-- Asignando nacionalidad ''' + @Nacionalidad +'''';
		UPDATE [dbo].[gselegibles]
		SET NACIONALIDAD = @Nacionalidad

		PRINT 'Actualizando filas de Nacionalidad en swnomper, swnomfam, swnomrper en cada base de datos'

		DECLARE @CMDA VARCHAR(8000);
		SET @CMDA = 'USE ? ; 
		IF ''?'' LIKE ''SWNOMMSSQL%'' AND ''?'' != ''SWNOMMSSQL''  
		BEGIN 
			DECLARE @ExecuteString	NVARCHAR(MAX) ;
			PRINT ''	Procesando a swnomper en '' + DB_NAME(); 
			SET @ExecuteString = ''	UPDATE swnomper SET Nacionalidad = '''''+ @Nacionalidad + ''''''';
			EXECUTE (@ExecuteString) ; 
		END '
		--PRINT 'CMDA = ' + @CMDA ;
		EXEC sp_MSForEachDB  @command1 = @CMDA ;

		DECLARE @CMDB VARCHAR(8000);
		SET @CMDB = 'USE ? ; 
		  IF ''?'' LIKE ''SWNOMMSSQL%'' AND ''?'' != ''SWNOMMSSQL''  
		  BEGIN 
			DECLARE @ExecuteString	NVARCHAR(MAX) ;
			PRINT ''	Procesando a swnomfam en '' + DB_NAME(); 
			SET @ExecuteString = ''	UPDATE swnomfam SET Nacionalidad = '''''+ @Nacionalidad + ''''''';
			EXECUTE (@ExecuteString) ; 
		  END '
		--PRINT 'CMDB = ' + @CMDB ;
		EXEC sp_MSForEachDB  @command1 = @CMDB ;

		DECLARE @CMDC VARCHAR(8000);
		SET @CMDC = 'USE ? ; 
		  IF ''?'' LIKE ''SWNOMMSSQL%'' AND ''?'' != ''SWNOMMSSQL''  
		  BEGIN 
			DECLARE @ExecuteString	NVARCHAR(MAX) ;
			PRINT ''	Procesando a swnomrper en '' + DB_NAME(); 
			SET @ExecuteString = ''	UPDATE swnomrper SET Nacionalidad = '''''+ @Nacionalidad + ''''''';
			EXECUTE (@ExecuteString) ; 
		   END '
		--PRINT 'CMDC = ' + @CMDC ;
		EXEC sp_MSForEachDB  @command1 = @CMDC ;

END
go

