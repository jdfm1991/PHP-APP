
CREATE PROCEDURE sp_swnomconmov @parFechaD INT, @parFechaH INT AS

DECLARE @NameTable sysname, @IDTable INT, @NameField sysname, @Y INT,
@SQLQry VARCHAR(8000), @SQLFields VARCHAR(8000),
@NumNom VARCHAR(10), @Ceros VARCHAR(10), @CodTip INT, @Total INT,
@FechaD INT, @FechaH INT, @SQLFieldsA VARCHAR(8000), @Paso2 INT, @Paso3 INT , @ORDEN INT

delete from swnommssql999999.dbo.swnomper
delete from swnommssql999999.dbo.swnomhmv
delete from swnommssql999999.dbo.swnommdt
delete from swnommssql999999.dbo.swnomhmd
delete from swnommssql999999.dbo.swnompta
delete from swnommssql999999.dbo.swnomdes
delete from swnommssql999999.dbo.swnomhth
delete from swnommssql999999.dbo.swnomhtd
delete from swnommssql999999.dbo.swnompca
delete from swnommssql999999.dbo.swnomhpr
delete from swnommssql999999.dbo.swnomdpr
delete from SWNOMMSSQL999999.dbo.swnomfam
delete from SWNOMMSSQL999999.dbo.swnomHVA
delete from SWNOMMSSQL999999.dbo.swnomPPE

SET @Ceros = '000000'
SET @FechaD = @parFechaD
SET @FechaH = @parFechaH
SET @Paso2 = 1
SET @Paso3 = 1
DECLARE cur_CodTip
CURSOR FOR  Select S.CodTip
From SWNOMMSSQL.dbo.SwNomTip S
Where S.CodTip <> 999999  And S.MARKAR = 1
Order By S.CodTip
OPEN cur_CodTip
FETCH NEXT FROM cur_CodTip
INTO @CodTip
while @@fetch_status=0 begin
SET @NumNom = SUBSTRING(@Ceros,1, LEN(@Ceros)-LEN(CONVERT(VARCHAR,@CodTip)))+CONVERT(VARCHAR,@CodTip)
IF EXISTS( Select * From master.dbo.sysdatabases Where Name = ('SWNOMMSSQL'+@NumNom)) Begin
DECLARE cur_tables cursor for
Select SO.ID, SO.Name,Case When SO.Name='SwNomPer' Then 1 else 2 end as Orden  From swnommssql999999.dbo.SysObjects SO
Where SO.Name Like 'SwNom%' And XType = 'U' And
SO.Name In ('SwNomPer','SwNomHmv','SwNomMdt','SwNomHmd','SwNomPta',
'SwNomDes','SwNomHth','SwNomHtd','SwNomPca','SwNomHpr','SwNomFam','SwNomHVA','SwNomPPE',
'SwNomDpr')
Order by 3
open cur_tables
fetch next from cur_tables
into @IDTable, @NameTable,@ORDEN
while @@fetch_status = 0 begin
DECLARE cur_fields cursor for
Select SC.Name From swnommssql999999.dbo.SysColumns SC
Where SC.ID = @IDTable
Order by SC.Name
open cur_fields
fetch next from cur_fields
into @NameField
SET @SQLFields = ''
SET @SQLFieldsA = ''
while @@fetch_status = 0 begin
SET @SQLFields = @SQLFields + @NameField + ', '
IF @NameField = 'CODNOM'
SET @SQLFieldsA = @SQLFieldsA +'CONVERT(INT,CONVERT(VARCHAR,A.'+@NameField+')+CONVERT(VARCHAR,'+CONVERT(VARCHAR,@CodTip)+')), '
ELSE IF @NameField = 'CODHT'
SET @SQLFieldsA = @SQLFieldsA +'CONVERT(INT,CONVERT(VARCHAR,A.'+@NameField+')+CONVERT(VARCHAR,'+CONVERT(VARCHAR,@CodTip)+')), '
ELSE IF @NameField = 'CONTROL'
SET @SQLFieldsA = @SQLFieldsA +'CONVERT(INT,CONVERT(VARCHAR,A.'+@NameField+')+CONVERT(VARCHAR,'+CONVERT(VARCHAR,@CodTip)+')), '
ELSE
SET @SQLFieldsA = @SQLFieldsA + 'A.'+@NameField + ', '
fetch next from cur_fields
into @NameField
end
SET @SQLQry = ''
SET @SQLFields = SUBSTRING(@SQLFields,1,LEN(@SQLFields)-1)
SET @SQLFieldsA = SUBSTRING(@SQLFieldsA,1,LEN(@SQLFieldsA)-1)
SET @NameTable = UPPER(@NameTable)
IF (@NameTable = 'SWNOMPER')
SET @SQLQry = ' INSERT INTO swnommssql999999.dbo.'+@NameTable+' ('+@SQLFields+') '+
' Select '+@SQLFieldsA+' From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
' Where A.Ficha COLLATE DATABASE_DEFAULT NOT IN (Select Ficha From swnommssql999999.dbo.'+@NameTable+')'
IF (@NameTable = 'SWNOMPCA')
SET @SQLQry = ' INSERT INTO swnommssql999999.dbo.'+@NameTable+' ('+@SQLFields+') '+
' Select '+@SQLFieldsA+' From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
' INNER JOIN SWNOMMSSQL'+@NumNom+'.dbo.SWNOMPER AS B ON B.FICHA=A.FICHA COLLATE DATABASE_DEFAULT '+
' Where B.Ficha COLLATE DATABASE_DEFAULT  IN (Select Ficha From swnommssql999999.dbo.SWNOMPER)'
ELSE IF (@NameTable = 'SWNOMHPR')
SET @SQLQry = ' INSERT INTO swnommssql999999.dbo.'+@NameTable+' ('+@SQLFields+') '+
' Select '+@SQLFieldsA+' From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
' INNER JOIN SWNOMMSSQL'+@NumNom+'.dbo.SWNOMPER AS B ON B.FICHA=A.FICHA COLLATE DATABASE_DEFAULT '+
' Where B.Ficha COLLATE DATABASE_DEFAULT IN (Select Ficha From swnommssql999999.dbo.SWNOMPER)'
ELSE IF (@NameTable = 'SWNOMDPR')
SET @SQLQry = ' INSERT INTO swnommssql999999.dbo.'+@NameTable+' ('+@SQLFields+') '+
' Select '+@SQLFieldsA+' From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
' INNER JOIN SWNOMMSSQL'+@NumNom+'.dbo.SWNOMHPR AS B ON B.NUMPRE=A.NUMPRE '+
' INNER JOIN SWNOMMSSQL'+@NumNom+'.dbo.SWNOMPER AS C ON B.FICHA=C.FICHA COLLATE DATABASE_DEFAULT '+
' Where C.Ficha COLLATE DATABASE_DEFAULT  IN (Select Ficha From swnommssql999999.dbo.SWNOMPER)'
ELSE IF (@NameTable = 'SWNOMHTH')
SET @SQLQry = ' INSERT INTO swnommssql999999.dbo.'+@NameTable+' ('+@SQLFields+') '+
' Select '+@SQLFieldsA+' From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
' Where A.CodTip = '+CONVERT(VARCHAR,@CodTip)
ELSE IF (@NameTable = 'SWNOMHTD')
SET @SQLQry = ' INSERT INTO swnommssql999999.dbo.'+@NameTable+' ('+@SQLFields+') '+
' Select '+@SQLFieldsA+' From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
' INNER JOIN SWNOMMSSQL'+@NumNom+'.dbo.SWNOMHTH AS B ON B.CODHT=A.CODHT '+
' Where B.CodTip = '+CONVERT(VARCHAR,@CodTip)
ELSE IF (@NameTable = 'SWNOMHMV') And (@Paso2 = 1) BEGIN
SET @SQLQry = ' INSERT INTO swnommssql999999.dbo.'+@NameTable+' ('+@SQLFields+') '+
' Select '+@SQLFieldsA+' From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
' Where (A.FechaPago >= '+CONVERT(VARCHAR,@FechaD)+' And A.FechaPago <= '+CONVERT(VARCHAR,@FechaH)+')'
END
ELSE IF ((@NameTable = 'SWNOMMDT') OR (@NameTable = 'SWNOMHMD') OR (@NameTable = 'SWNOMDES')) And (@Paso2 = 1) BEGIN
SET @SQLQry = ' INSERT INTO swnommssql999999.dbo.'+@NameTable+' ('+@SQLFields+') '+
' Select '+@SQLFieldsA+' From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
' INNER JOIN SWNOMMSSQL'+@NumNom+'.dbo.SWNOMHMV AS B ON B.CODNOM=A.CODNOM '+
' Where (B.FechaPago >= '+CONVERT(VARCHAR,@FechaD)+' And B.FechaPago <= '+CONVERT(VARCHAR,@FechaH)+')'
END
ELSE IF (@NameTable = 'SWNOMPTA') And (@Paso3 = 1) BEGIN
SET @SQLQry = ' INSERT INTO swnommssql999999.dbo.'+@NameTable+' ('+@SQLFields+') '+
' Select '+@SQLFieldsA+' From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
' Where (A.Fecha >= '+CONVERT(VARCHAR,@FechaD)+' And A.Fecha <= '+CONVERT(VARCHAR,@FechaH)+')'

END
ELSE IF (@NameTable = 'SWNOMFAM')
SET @SQLQry = ' INSERT INTO swnommssql999999.dbo.'+@NameTable+' ('+@SQLFields+') '+
' Select '+@SQLFieldsA+' From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
' INNER JOIN SWNOMMSSQL'+@NumNom+'.dbo.SWNOMPER AS B ON B.FICHA=A.FICHA COLLATE DATABASE_DEFAULT '+
' Where B.Ficha COLLATE DATABASE_DEFAULT  IN (Select Ficha From swnommssql999999.dbo.SWNOMPER)'
ELSE IF (@NameTable = 'SWNOMHVA')
SET @SQLQry = ' INSERT INTO swnommssql999999.dbo.'+@NameTable+' ('+@SQLFields+') '+
' Select '+@SQLFieldsA+' From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
' INNER JOIN SWNOMMSSQL'+@NumNom+'.dbo.SWNOMPER AS B ON B.FICHA=A.FICHA COLLATE DATABASE_DEFAULT '+
' Where B.Ficha COLLATE DATABASE_DEFAULT  IN (Select Ficha From swnommssql999999.dbo.SWNOMPER)'
ELSE IF (@NameTable = 'SWNOMPPE')
SET @SQLQry = ' INSERT INTO swnommssql999999.dbo.'+@NameTable+' ('+@SQLFields+') '+
' Select '+@SQLFieldsA+' From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
' INNER JOIN SWNOMMSSQL'+@NumNom+'.dbo.SWNOMPER AS B ON B.FICHA=A.FICHA COLLATE DATABASE_DEFAULT '+
' Where B.Ficha COLLATE DATABASE_DEFAULT  IN (Select Ficha From swnommssql999999.dbo.SWNOMPER)'
IF @SQLQry <> ''
EXEC(@SQLQry)
close cur_fields
deallocate cur_fields
fetch next from cur_tables
into  @IDTable, @NameTable,@ORDEN
end
close cur_tables
deallocate cur_tables
End
FETCH NEXT FROM cur_CodTip
INTO @CodTip
end
close cur_CodTip
deallocate cur_CodTip
go

