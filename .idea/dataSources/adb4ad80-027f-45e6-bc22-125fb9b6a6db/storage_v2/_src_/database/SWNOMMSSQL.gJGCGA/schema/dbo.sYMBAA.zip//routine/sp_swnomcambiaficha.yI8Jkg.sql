
CREATE PROCEDURE sp_swnomcambiaficha @parFicha VARCHAR(15), @parNomina INT AS

DECLARE @NameTable sysname, @IDTable INT, @NameField sysname, @Y INT,   @SQLQry VARCHAR(8000),
@NumNom VARCHAR(10), @CodTip INT, @Total INT, @FICHA VARCHAR(255), @NOMINA VARCHAR(10),
@CNT INT, @FICHAN VARCHAR(20), @POS INT, @CHAR VARCHAR(2), @NCHAR INT

SET @NOMINA = CONVERT(VARCHAR,@parNomina)
SET @FICHAN = @parFicha
SET @NOMINA = REPLICATE('0',6-LEN(@NOMINA))+@NOMINA

create table #sysobjects (
ID int,
Name SysName
)

create table #ficha (
CNT VARCHAR(200)
)


insert into #sysobjects
(Id, Name)
EXEC(' Select SO.ID, SO.Name From SWNOMMSSQL'+@NOMINA+'.dbo.SysObjects AS SO '+
' INNER JOIN SWNOMMSSQL'+@NOMINA+'.dbo.SysColumns SC ON SC.ID=SO.ID'+
' Where SO.Name Like ''SwNom%'' And SO.XType = ''U'' And '+
'      SC.Name In (''Ficha'')'+
' ORder By SO.Name')

SET @CNT = 1
SET @POS = 1
SET @NCHAR = 88
SET @CHAR = NCHAR(@NCHAR)

WHILE @CNT >= 1 BEGIN
IF LEN(@FICHAN)+1 > 10
BEGIN
SET @FICHAN = SUBSTRING(@FICHAN,1,LEN(@FICHAN)-@POS)+REPLICATE(@CHAR,@POS)
SET @POS = @POS + 1
IF @POS > 10 BEGIN
SET @NCHAR = @NCHAR + 1
SET @CHAR = NCHAR(@NCHAR)
SET @FICHAN = @parFicha
SET @POS = 1
END
END
ELSE
SET @FICHAN = @FICHAN+@CHAR
exec sp_swnombuscaficha @FICHAN, @parNomina
insert into #ficha
EXEC('Select * From SWNOMMSSQL'+@NOMINA+'.dbo.dummyloc')
SELECT @CNT = ISNULL(CONVERT(INT,ISNULL(CNT,0)),0) FROM #ficha
delete from #ficha
END

DECLARE cur_tables cursor for
Select ID, Name From #sysobjects
open cur_tables
fetch next from cur_tables
into @IDTable, @NameTable
while @@fetch_status = 0 begin
SET @NameTable = UPPER(@NameTable)
IF @NameTable = 'SWNOMPER'
SET @SQLQry = ' USE SWNOMMSSQL'+@NOMINA+
' UPDATE '+@NameTable+' SET Ficha = '+''''+@FICHAN+''''+','+
'                                                      Estado = '+''''+'Transferido'+''''+
'  Where Ficha  = '+''''+@parFicha+''''
ELSE
SET @SQLQry = ' USE SWNOMMSSQL'+@NOMINA+
' UPDATE '+@NameTable+' SET Ficha = '+''''+@FICHAN+''''+
'  Where Ficha  = '+''''+@parFicha+''''
EXEC(@SQLQry)
fetch next from cur_tables
into  @IDTable, @NameTable
end
close cur_tables
deallocate cur_tables

drop table #sysobjects
drop table #ficha
go

