
CREATE PROCEDURE sp_swnomtransferirficha @parFicha VARCHAR(15), @parCodNomO INT, @parCodNomD INT AS

DECLARE @NameTable sysname, @IDTable INT, @NameField sysname, @Y INT,  @NumControl VARCHAR(150),
@SQLQry VARCHAR(8000), @SQLQry1 VARCHAR(8000), @SQLFields VARCHAR(8000), @CodTipD INT, @NumPre INT,
@NumNom VARCHAR(10), @NumNomD VARCHAR(10), @CodTip INT, @CodTipO INT, @Total INT,
@SQLFieldsA VARCHAR(8000), @CodNom VARCHAR(10), @Ficha VARCHAR(20)

create table #sysobjects (
ID int,
Name SysName
)

create table #syscolumns (
Name SysName
)

SET @CodTipO=@parCodNomO
SET @CodTipD=@parCodNomD
SET @Ficha=@parFicha

SET @NumNom = REPLICATE('0',6-LEN(CONVERT(VARCHAR,@CodTipO)))+CONVERT(VARCHAR,@CodTipO)
SET @NumNomD = REPLICATE('0',6-LEN(CONVERT(VARCHAR,@CodTipD)))+CONVERT(VARCHAR,@CodTipD)
SET @NumControl = 'CONVERT(VARCHAR,@ANO)+ CONVERT(VARCHAR,@MES)+ CONVERT(VARCHAR,@DIA)+CONVERT(VARCHAR,@H)+'+
'CONVERT(VARCHAR,@M)+CONVERT(VARCHAR,@S)+CONVERT(VARCHAR,@MS)'
Select @NumPre = CONPRESTAMOS FROM SWNOMMSSQL.dbo.SWNOMPAR

insert into #sysobjects
(Id, Name)
EXEC(' Select SO.ID, SO.Name From swnommssql'+@NumNom+'.dbo.SysObjects SO '+
' Where SO.Name Like ''SwNom%'' And XType = ''U'' And '+
'       SO.Name In (''SwNomPer'',''SwNomPca'',''SwNomHva'',''SwNomPta'', '+
'                   ''SwNomFam'',''SwNomHpr'',''SwNomDpr'')')

DECLARE cur_tables cursor for
Select SO.Name
From #sysobjects SO
Order by SO.Name
open cur_tables
fetch next from cur_tables
into @NameTable
while @@fetch_status = 0 begin
IF @NameTable IN ('SWNOMPER','SWNOMPCA','SWNOMHPR','SWNOMFAM','SWNOMHVA','SWNOMPTA')
SET @SQLQry = 'Delete From SWNOMMSSQL'+@NumNomD+'.dbo.'+@NameTable+' Where Ficha = '+''''+@Ficha+''''
ELSE
SET @SQLQry = ' DELETE SWNOMMSSQL'+@NumNomD+'.dbo.'+@NameTable+
' FROM SWNOMMSSQL'+@NumNomD+'.dbo.'+@NameTable+
' INNER JOIN SWNOMMSSQL'+@NumNomD+'.dbo.SWNOMHPR ON SWNOMMSSQL'+@NumNomD+'.dbo.SWNOMHPR.NUMPRE=SWNOMMSSQL'+@NumNomD+'.dbo.'+@NameTable+'.NUMPRE '+
' INNER JOIN SWNOMMSSQL'+@NumNomD+'.dbo.SWNOMPER ON SWNOMMSSQL'+@NumNomD+'.dbo.SWNOMHPR.FICHA=SWNOMMSSQL'+@NumNomD+'.dbo.SWNOMPER.FICHA COLLATE DATABASE_DEFAULT '+
' Where SWNOMMSSQL'+@NumNomD+'.dbo.SWNOMPER.Ficha = '+''''+@Ficha+''''
IF @SQLQry <> ''
EXEC(@SQLQry)
fetch next from cur_tables
into @NameTable
end
close cur_tables
deallocate cur_tables

DECLARE cur_tables cursor for
Select SO.ID, SO.Name
From #sysobjects SO
Order by SO.Name
open cur_tables
fetch next from cur_tables
into @IDTable, @NameTable
while @@fetch_status = 0 begin
SET @SQLQry = ' Select SC.Name '+
' From swnommssql'+@NumNom+'.dbo.SysColumns SC '+
' Where SC.ID = '+CONVERT(VARCHAR,@IDTable)
insert into #syscolumns
(Name)
EXEC(@SQLQry)

DECLARE cur_fields cursor for
Select SC.Name
From #syscolumns as SC
Order by SC.Name
open cur_fields
fetch next from cur_fields
into @NameField
SET @SQLFields = ''
SET @SQLFieldsA = ''
while @@fetch_status = 0 begin
SET @SQLFields = @SQLFields + @NameField + ', '
IF @NameField = 'CODNOM'
SET @SQLFieldsA = @SQLFieldsA +''''+''''+', '
ELSE IF @NameField = 'TIPNOM'
SET @SQLFieldsA = @SQLFieldsA +''''+CONVERT(VARCHAR,@CodTipD)+''''+', '
ELSE IF @NameField = 'NUMCONTROL'
SET @SQLFieldsA = @SQLFieldsA +'@numcontroln, '
ELSE IF @NameField = 'CONTROL'
SET @SQLFieldsA = @SQLFieldsA +'@CONTROL, '
ELSE IF @NameField = 'NUMPRE'
SET @SQLFieldsA = @SQLFieldsA +' @NUMPREN , '
ELSE
SET @SQLFieldsA = @SQLFieldsA + 'A.'+@NameField + ', '
fetch next from cur_fields
into @NameField
end          	SET @SQLQry = ''
SET @SQLFields = SUBSTRING(@SQLFields,1,LEN(@SQLFields)-1)
SET @SQLFieldsA = SUBSTRING(@SQLFieldsA,1,LEN(@SQLFieldsA)-1)
SET @NameTable = UPPER(@NameTable)
SET @SQLQry1 =  ''
IF (@NameTable = 'SWNOMPER')
SET @SQLQry = ' INSERT INTO swnommssql'+@NumNomD+'.dbo.'+@NameTable+' ('+@SQLFields+') '+
' Select '+@SQLFieldsA+' From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
' Where A.Ficha = '+''''+@Ficha+''''
ELSE IF (@NameTable = 'SWNOMPCA')
SET @SQLQry = ' INSERT INTO swnommssql'+@NumNomD+'.dbo.'+@NameTable+' ('+@SQLFields+') '+
' Select '+@SQLFieldsA+' From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
' INNER JOIN SWNOMMSSQL'+@NumNom+'.dbo.SWNOMPER AS B ON B.FICHA=A.FICHA COLLATE DATABASE_DEFAULT '+
' Where B.Ficha = '+''''+@Ficha+''''
ELSE IF (@NameTable = 'SWNOMHPR')  BEGIN
SET @SQLQry = ' declare @NUMPRE INT, @NUMPREN INT'+
' SET @NUMPREN = '+CONVERT(VARCHAR,@NumPre)+
' declare cur_numc cursor for  '+
' Select  NumPre '+
' From swnommssql'+@NumNom+'.dbo.'+@NameTable+' AS A   '+
' INNER JOIN SWNOMMSSQL'+@NumNom+'.dbo.SWNOMPER AS B ON B.FICHA=A.FICHA COLLATE DATABASE_DEFAULT '+
' Where A.Ficha = '+''''+@Ficha+'''' +
' open cur_numc  '+
' fetch next from cur_numc  '+
' into @NUMPRE  '+
' while @@fetch_status = 0 begin '+
'         exec sp_swnomgetnextcontpre @NUMPREN OUTPUT, '+CONVERT(VARCHAR,@parCodNomD)+', '+''''+@NameTable+''''+
'         INSERT INTO swnommssql'+@NumNomD+'.dbo.'+@NameTable+' ('+@SQLFields+') '+
'         Select '+@SQLFieldsA+' From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
'         INNER JOIN SWNOMMSSQL'+@NumNom+'.dbo.SWNOMPER AS B ON B.FICHA=A.FICHA COLLATE DATABASE_DEFAULT '+
'	   Where A.Ficha = '+''''+@Ficha+''''+' And A.NumPre = @NUMPRE  '+
'	   fetch next from cur_numc  '+
'	    into @NUMPRE  '+
'	    SET @NUMPREN = @NUMPREN + 1 '+
' end '+
' close cur_numc  '+
' deallocate cur_numc  '
END
ELSE IF (@NameTable = 'SWNOMFAM')
SET @SQLQry = ' declare @numcontrol INT, @CONTROL INT '+
' SELECT @CONTROL = CONFAMILIARES FROM SWNOMMSSQL.dbo.SWNOMPAR'+
' declare cur_numc cursor for  '+
' Select  Control '+
' From swnommssql'+@NumNom+'.dbo.'+@NameTable+' AS A   '+
' Where A.Ficha = '+''''+@Ficha+'''' +
' open cur_numc  '+
' fetch next from cur_numc  '+
' into @numcontrol  '+
' while @@fetch_status = 0 begin '+
'         INSERT INTO swnommssql'+@NumNomD+'.dbo.'+@NameTable+' ('+@SQLFields+') '+
'         Select '+@SQLFieldsA+' From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
'	   Where A.Ficha = '+''''+@Ficha+''''+' And A.Control = @numcontrol  '+
'	   fetch next from cur_numc  '+
'	    into @numcontrol  '+
'	    SET @CONTROL = @CONTROL + 1 '+
' end '+
' close cur_numc  '+
' deallocate cur_numc  '+
' UPDATE SWNOMMSSQL.dbo.SWNOMPAR SET CONFAMILIARES = @CONTROL '
ELSE IF (@NameTable = 'SWNOMHVA')
SET @SQLQry = ' INSERT INTO swnommssql'+@NumNomD+'.dbo.'+@NameTable+' ('+@SQLFields+') '+
' Select '+@SQLFieldsA+' From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
' INNER JOIN SWNOMMSSQL'+@NumNom+'.dbo.SWNOMPER AS B ON B.FICHA=A.FICHA COLLATE DATABASE_DEFAULT '+
' Where B.Ficha = '+''''+@Ficha+''''	ELSE IF (@NameTable = 'SWNOMDPR') BEGIN
SET @SQLQry = ' declare @NUMPRE INT, @NUMPREN INT '+
' SET @NUMPREN = '+CONVERT(VARCHAR,@NumPre)+
' declare cur_numc cursor for  '+
' Select DISTINCT A.NumPre From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
' INNER JOIN SWNOMMSSQL'+@NumNom+'.dbo.SWNOMHPR AS B ON B.NUMPRE=A.NUMPRE '+
' INNER JOIN SWNOMMSSQL'+@NumNom+'.dbo.SWNOMPER AS C ON B.FICHA=C.FICHA COLLATE DATABASE_DEFAULT '+
' Where C.Ficha = '+''''+@Ficha+''''+
' open cur_numc  '+
' fetch next from cur_numc  '+
' into @NUMPRE  '+
' while @@fetch_status = 0 begin '+
'         exec sp_swnomgetnextcontpre @NUMPREN OUTPUT, '+CONVERT(VARCHAR,@parCodNomD)+', '+''''+@NameTable+''''+
'         INSERT INTO swnommssql'+@NumNomD+'.dbo.'+@NameTable+' ('+@SQLFields+') '+
'         Select '+@SQLFieldsA+' From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
'         INNER JOIN SWNOMMSSQL'+@NumNom+'.dbo.SWNOMHPR AS B ON B.NUMPRE=A.NUMPRE '+
'         INNER JOIN SWNOMMSSQL'+@NumNom+'.dbo.SWNOMPER AS C ON B.FICHA=C.FICHA COLLATE DATABASE_DEFAULT '+
'	   Where C.Ficha = '+''''+@Ficha+''''+' And A.NumPre = @NUMPRE  '+
'	   fetch next from cur_numc  '+
'	    into @NUMPRE  '+
'	    SET @NUMPREN = @NUMPREN + 1 '+
' end '+
' close cur_numc  '+
' deallocate cur_numc '
END
ELSE IF (@NameTable = 'SWNOMPTA') BEGIN
SET @SQLQry = ' declare @numcontrol varchar(20), @numcontroln varchar(20), @ANO INT, @MES INT, @DIA INT, @H INT, @M INT, @S INT, @MS INT, @NUMPRE INT, @NUMPREN INT '+
' SET @NUMPREN = '+CONVERT(VARCHAR,@NumPre)+
' SET @ANO = YEAR(GETDATE())-2000 '+
' SET @MES = MONTH(GETDATE()) '+
' SET @DIA = DAY(GETDATE()) '+
' SET @H = DATEPART(hh,GETDATE()) '+
' SET @M = DATEPART(mi,GETDATE()) '+
' SET @S = DATEPART(ss,GETDATE()) '+
' SET @MS = DATEPART(ms,GETDATE()) '+
/**********************************************************************/
' declare cur_numpre cursor for  '+
' Select DISTINCT A.NumPre From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
' INNER JOIN SWNOMMSSQL'+@NumNom+'.dbo.SWNOMHPR AS B ON B.NUMPRE=A.NUMPRE '+
' INNER JOIN SWNOMMSSQL'+@NumNom+'.dbo.SWNOMPER AS C ON B.FICHA=C.FICHA COLLATE DATABASE_DEFAULT '+
' Where C.Ficha = '+''''+@Ficha+''''+
' open cur_numpre  '+
' fetch next from cur_numpre  '+
' into @NUMPRE  '+
' while @@fetch_status = 0 begin '+
/**********************************************************************/
' 	declare cur_numc cursor for  '+
' 	Select  NumControl '+
' 	From swnommssql'+@NumNom+'.dbo.'+@NameTable+' AS A   '+
' 	Where A.Ficha = '+''''+@Ficha+'''' +
' 	open cur_numc  '+
' 	fetch next from cur_numc  '+
' 	into @numcontrol  '+
' 	while @@fetch_status = 0 begin '+
' 	        exec sp_swnomgetnextcont '+CONVERT(VARCHAR,@CodTipD)+', @Ano OUTPUT, @Mes OUTPUT, @Dia OUTPUT,  '+
' 	                                                             @H OUTPUT, @M OUTPUT, @S OUTPUT, @MS OUTPUT, '+
' 	                                                             @numcontroln OUTPUT  '+
'               INSERT INTO swnommssql'+@NumNomD+'.dbo.'+@NameTable+' ('+@SQLFields+') '+
'	        Select '+@SQLFieldsA+' From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
'	         Where A.Ficha = '+''''+@Ficha+''''+' And A.NumControl = @numcontrol  '+' And A.NumPre = @NUMPRE  '+
'                fetch next from cur_numc  '+
'	         into @numcontrol  '+
'	end '+
'	close cur_numc  '+
'	deallocate cur_numc  '+
'	fetch next from cur_numpre  '+
'	into @NUMPRE  '+
'	SET @NUMPREN = @NUMPREN + 1 '+
' end '+
' close cur_numpre  '+
' deallocate cur_numpre '+
' UPDATE SWNOMMSSQL.dbo.SWNOMPAR SET CONPRESTAMOS = @NUMPREN '
/**********************************************************************/
SET @SQLQry1 =  ' declare cur_numpre cursor for  '+
' Select A.NumControl From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
' INNER JOIN SWNOMMSSQL'+@NumNom+'.dbo.SWNOMPER AS C ON A.FICHA=C.FICHA COLLATE DATABASE_DEFAULT '+
' Where (A.NumPre = 0 Or A.NumPre Is Null) And C.Ficha = '+''''+@Ficha+''''+
' open cur_numpre  '+
' fetch next from cur_numpre  '+
' into @numcontrol '+
' while @@fetch_status = 0 begin '+
' 	        exec sp_swnomgetnextcont '+CONVERT(VARCHAR,@CodTipD)+', @Ano OUTPUT, @Mes OUTPUT, @Dia OUTPUT,  '+
' 	                                                             @H OUTPUT, @M OUTPUT, @S OUTPUT, @MS OUTPUT, '+
' 	                                                             @numcontroln OUTPUT  '+
'               INSERT INTO swnommssql'+@NumNomD+'.dbo.'+@NameTable+' ('+@SQLFields+') '+
'	        Select '+@SQLFieldsA+' From SWNOMMSSQL'+@NumNom+'.dbo.'+@NameTable+' AS A '+
'	         Where A.Ficha = '+''''+@Ficha+''''+' And A.NumControl = @numcontrol   '+
'	          fetch next from cur_numpre  '+
'	         into @numcontrol  '+
' end '+
' close cur_numpre  '+
' deallocate cur_numpre '
END
IF @SQLQry <> ''
EXEC(@SQLQry+@SQLQry1)
close cur_fields
deallocate cur_fields
fetch next from cur_tables
into  @IDTable, @NameTable
delete from #syscolumns
end
close cur_tables
deallocate cur_tables

drop table #sysobjects
drop table #syscolumns
go

