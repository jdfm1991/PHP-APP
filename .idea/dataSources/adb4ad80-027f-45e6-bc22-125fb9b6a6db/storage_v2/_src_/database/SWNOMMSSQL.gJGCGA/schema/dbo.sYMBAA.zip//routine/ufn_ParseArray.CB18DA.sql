
	create function [dbo].[ufn_ParseArray]
		(   @Input      nvarchar(4000), 
			@Delimiter  char(1) = ',',
			@BaseIdent  int
		)
	returns table as
	return  
		(   select  row_number() over (order by n asc) + (@BaseIdent - 1) [i],
					substring(@Input, n, charindex(@Delimiter, @Input + @Delimiter, n) - n) s
			from    (select distinct number n from master..spt_values where number between 1 and 2048) as Number
			where   n <= convert(int, len(@Input)) and
					substring(@Delimiter + @Input, n, 1) = @Delimiter
		);
    go

