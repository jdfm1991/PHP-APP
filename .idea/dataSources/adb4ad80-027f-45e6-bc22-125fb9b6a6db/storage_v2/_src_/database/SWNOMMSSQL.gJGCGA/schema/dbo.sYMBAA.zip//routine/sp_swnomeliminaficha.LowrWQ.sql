
CREATE PROCEDURE sp_swnomeliminaficha @parFicha VARCHAR(15), @parNomina INT AS
DECLARE @NameTable sysname, @IDTable INT, @NameField sysname, @Y INT,   @SQLQry VARCHAR(8000),
@NumNom VARCHAR(10), @CodTip INT, @Total INT,
@FICHA VARCHAR(255), @NOMINA VARCHAR(10)

SET @NOMINA = CONVERT(VARCHAR,@parNomina)
SET @FICHA = @parFicha

SET @NOMINA = REPLICATE('0',6-LEN(@NOMINA))+@NOMINA

create table #sysobjects (
ID int,
Name SysName
)

insert into #sysobjects
(Id, Name)
EXEC(' Select SO.ID, SO.Name From SWNOMMSSQL'+@NOMINA+'.dbo.SysObjects AS SO '+
' INNER JOIN SWNOMMSSQL'+@NOMINA+'.dbo.SysColumns SC ON SC.ID=SO.ID'+
' Where SO.Name Like ''SwNom%'' And SO.XType = ''U'' And '+
'      SC.Name In (''Ficha'')'+
' ORder By SO.Name')

DECLARE cur_tables cursor for
Select ID, Name From #sysobjects
open cur_tables
fetch next from cur_tables
into @IDTable, @NameTable
while @@fetch_status = 0 begin
SET @NameTable = UPPER(@NameTable)
SET @SQLQry = ' USE SWNOMMSSQL'+@NOMINA+
' DELETE FROM '+@NameTable+
' Where Ficha  = '+''''+@FICHA+''''
EXEC(@SQLQry)
fetch next from cur_tables
into  @IDTable, @NameTable
end
close cur_tables
deallocate cur_tables

drop table #sysobjects

go

