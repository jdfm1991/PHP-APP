

/****** Objeto: vista dbo.XCO3    fecha de la secuencia de comandos: 29/03/2005 04:04:04 a.m. ******/
CREATE VIEW dbo.XCO3
AS
SELECT     dbo.CO3.CO3_NUMERO, dbo.CO3.CO3_FECHA, dbo.CO3.CO3_MONTO, dbo.COM.COM_VENCE, dbo.COM.COM_SALDO1, dbo.COM.COM_OPE, 
                      dbo.COM.COM_FECHA, dbo.COM.COM_NUMERO, dbo.COM.COM_CONTROL, dbo.COM.COM_SALDO, dbo.PRO.PRO_CODIGO, 
                      dbo.PRO.PRO_NOMBRE
FROM         dbo.PRO LEFT OUTER JOIN
                      dbo.COM ON dbo.PRO.PRO_PK = dbo.COM.COM_PROFK RIGHT OUTER JOIN
                      dbo.CO3 ON dbo.COM.COM_PK = dbo.CO3.CO3_COMFK

go

