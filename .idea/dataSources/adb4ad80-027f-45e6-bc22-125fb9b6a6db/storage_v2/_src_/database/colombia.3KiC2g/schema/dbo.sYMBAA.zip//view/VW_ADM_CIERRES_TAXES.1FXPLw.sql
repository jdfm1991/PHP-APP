create view VW_ADM_CIERRES_TAXES 
 AS 
SELECT CONVERT(datetime, CONVERT(char(8), F.FechaE, 112)) AS FECHAE,F.CodEsta, T.CodTaxs,
       ISNULL(SUM(T.Monto * F.Signo), 0.00) AS TOTMTOTAX, 
       ISNULL(SUM(T.TGravable * F.Signo), 0.00) AS TOTGRAVABLETAX
  FROM dbo.SATAXVTA AS T INNER JOIN
       dbo.SAFACT AS F ON 
         (t.codSucu=f.codsucu) And T.NumeroD = F.NumeroD AND T.TipoFac = F.TipoFac
GROUP BY CONVERT(datetime, CONVERT(char(8), F.FechaE, 112)), F.CodEsta,T.CodTaxs
go

