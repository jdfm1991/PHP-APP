create view VW_ADM_CIERRES 
 AS 
SELECT '0' AS TIPO, CONVERT(datetime, CONVERT(char(8), FechaE, 112)) AS FECHAE, CodEsta, 
       ISNULL(SUM(Signo*(CancelE + CancelC + CancelT + CancelA + CancelI)), 0.00) AS TOTCONTADO,
       ISNULL(SUM(Signo*(Monto-(Descto1+Descto2)+Fletes+(MtoTax-RetenIVA)-(CancelE+CancelC+CancelT+CancelA+CancelI))), 0.00) AS TOTCREDITO, 
       ISNULL(SUM(Signo*(Monto-(Descto1+Descto2)+Fletes)), 0.00) AS TOTAL,
       ISNULL(SUM(TGravable * Signo), 0.00) AS TOTGRAVABLE, 
       ISNULL(SUM(MtoTax * Signo), 0.00) AS TOTIMPUESTO,
       ISNULL(SUM(RetenIVA * Signo), 0.00) AS TOTRETENIVA,
       ISNULL(SUM(CancelE * Signo), 0.00) AS TOTEFECTIVO,
       ISNULL(SUM(CancelG * Signo), 0.00) AS TOTOTROS,
       ISNULL(SUM(CancelC * Signo), 0.00) AS TOTCHEQUE, 
       ISNULL(SUM(CancelT * Signo), 0.00) AS TOTTARJETA,
       ISNULL(SUM(CancelA * Signo), 0.00) AS TOTADELANTOS,
       ISNULL(SUM(TotalPrd * Signo), 0.00) AS TOTPRODUCTOS,
       ISNULL(SUM(TotalSrv * Signo), 0.00) AS TOTSERVICIOS,
       ISNULL(SUM(TExento * Signo), 0.00) AS TOTVENTAEXENTA, 
       ISNULL(SUM(Fletes * Signo), 0.00) AS TOTFLETES,
       ISNULL(SUM((Descto1 + Descto2) * Signo), 0.00) AS TOTDESCUENTOS,
       CAST(0.0 AS decimal(18, 2)) AS TOTEXCLUIDO,
       ISNULL(SUM(CASE WHEN TIPOFAC = 'A' THEN 1 ELSE 0 END), 0) AS CONTFACTURAS, 
       ISNULL(SUM(CASE WHEN TIPOFAC = 'B' THEN 1 ELSE 0 END), 0) AS CONTDEVOLUCIONES,
      (SELECT MIN(NumeroD) AS Expr1
         FROM dbo.SAFACT AS F
        WHERE (TipoFac = 'A') AND
              (CONVERT(datetime, CONVERT(char(8), FechaE, 112)) =
              CONVERT(datetime, CONVERT(char(8), SF.FechaE, 112)))) 
        AS NUMFACI,
        (SELECT MAX(NumeroD) AS Expr1
        FROM    dbo.SAFACT AS F
        WHERE   (TipoFac='A') AND (CONVERT(datetime, CONVERT(char(8), FechaE, 112)) =
                 CONVERT(datetime, CONVERT(char(8), SF.FechaE, 112)))) 
        AS NUMFACF
FROM  dbo.SAFACT AS SF
WHERE (TipoFac IN ('A', 'B'))
GROUP BY CONVERT(datetime, CONVERT(char(8), FechaE, 112)), CodEsta
go

