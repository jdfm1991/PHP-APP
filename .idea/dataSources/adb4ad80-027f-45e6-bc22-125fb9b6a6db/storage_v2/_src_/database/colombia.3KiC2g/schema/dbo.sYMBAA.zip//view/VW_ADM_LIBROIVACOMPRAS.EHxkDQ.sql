CREATE VIEW DBO.VW_ADM_LIBROIVACOMPRAS AS 
SELECT 
 '0' AS DBZ,
 C.CODSUCU, 
 C.TipoCom AS Tipo, 
 (CASE WHEN C.Tipocom='H' THEN '01-REG' ELSE '02-REG' END) AS TipoReg,
 C.FechaE AS FECHATRAN, 
 C.FechaI AS FECHACOMPRA, 
 C.FechaT, 
 C.ID3,
 C.CODPROV,
 C.Descrip,
 (Case When P.TipoPrv=1 Then (select RIF from saconf WITH (NOLOCK) ) else C.ID3 end) as ID3Ex, 
 (Case When P.TipoPrv=1 Then (select Descrip from saconf WITH (NOLOCK) ) else C.Descrip end) as DescripEx, 
 C.CodOper,
 (Case When C.Tipocom='H' Then 'FAC' Else 
   (CASE IsNull((SELECT CORRELUNC FROM SACONF),0) WHEN 1 THEN 'N/D' ELSE 'DEV' END) END) AS TIPODOC,
 C.NumeroD AS NUMERODOC, 
 (CASE WHEN C.TIPOCOM='I' THEN C.NumeroN ELSE NULL END) AS DOCAFECTADO, 
 C.NroCtrol, 
 C.NumeroP AS Planilla_Import,
 C.Signo*(CASE WHEN P.TIPOPRV=0 THEN (C.Monto+C.Fletes-(C.Descto1+C.Descto2)) ELSE 0 END) AS TOTALNACIONAL,
 C.Signo*(CASE WHEN P.TIPOPRV=1 THEN (C.Monto+C.Fletes-(C.Descto1+C.Descto2)) ELSE 0 END) AS TOTALIMPORTADO,
 C.Signo*(C.Monto+C.Fletes-(C.Descto1+C.Descto2)) AS TOTALCOMPRA, 
 C.Signo*(C.Monto+C.Fletes+C.MtoTax-(C.Descto1+C.Descto2)) AS TOTALCOMPRACONIVA, 
 C.Signo*C.MtoTax AS TOTALALICUOTA, 
 C.Signo*C.TExento AS MtoExento,
 C.Signo*(C.TGravable-C.TGravable*(C.DESCTO1+C.DESCTO2)/(case when C.Monto=0 then 1 else C.monto end)) As TotalGravable,  (Case when P.TipoPrv=0 Then
  C.Signo*isnull((Select top 1 t.tgravable 
    From SATAXCOM T WITH (NOLOCK) 
    Where (t.codtaxs='IAL') And (t.TIPOCOM=C.TIPOCOM) And 
   (t.codSucu=c.codsucu) And (t.codprov=c.codprov) And (t.numerod=C.numerod)),0) Else 0 End) AS MtoGravable_IAL, 
 (Case when P.TipoPrv=0 Then
 C.Signo*IsNull((Select top 1 t.Monto 
  From  SATAXCOM t WITH (NOLOCK) 
  Where (t.codtaxs='IAL') And (t.codprov=c.codprov) And 
       (t.TIPOCOM=C.TIPOCOM) and (t.codSucu=c.codsucu) And (t.numerod=C.numerod)),0) Else 0 End) As Monto_IAL,
 (Case when P.TipoPrv=0 Then
 IsNull((Select top 1 t.MtoTax 
  From  SATAXCOM t WITH (NOLOCK) 
  Where (t.codtaxs='IAL') And (t.TIPOCOM=C.TIPOCOM) And 
   (t.codprov=c.codprov) And (t.codSucu=c.codsucu) And (t.numerod=C.numerod)),0) Else 0 End) As Alicuota_IAL,
 (Case when P.TipoPrv=1 Then
  C.Signo*isnull((Select top 1 t.tgravable 
    From SATAXCOM T WITH (NOLOCK) 
    Where (t.codtaxs='IAL') And (t.TIPOCOM=C.TIPOCOM) And 
   (t.codprov=c.codprov) And (t.codSucu=c.codsucu) And (t.numerod=C.numerod)),0) Else 0 End) AS MtoGravableImpo_IAL, 
 (Case when P.TipoPrv=1 Then
 C.Signo*IsNull((Select Top 1 T.Monto 
                   From SATAXCOM T WITH (NOLOCK) 
                  Where (T.Codtaxs='IAL') And (t.codprov=c.codprov) And 
                        (T.TIPOCOM=C.TIPOCOM) and (t.codSucu=c.codsucu) And (t.numerod=C.numerod)),0) Else 0 End) As MontoImpo_IAL,
 (Case when P.TipoPrv=1 Then
       IsNull((Select top 1 t.MtoTax 
  From  SATAXCOM t WITH (NOLOCK) 
  Where (t.codtaxs='IAL') And (t.TIPOCOM=C.TIPOCOM) And 
   (t.codprov=c.codprov) And (t.codSucu=c.codsucu) And (t.numerod=C.numerod)),0) Else 0 End) As AlicuotaImpo_IAL, (Case when P.TipoPrv=0 Then
  C.Signo*isnull((Select top 1 t.tgravable 
    From SATAXCOM T WITH (NOLOCK) 
    Where (t.codtaxs='IVA') And (t.TIPOCOM=C.TIPOCOM) And 
   (t.codSucu=c.codsucu) And (t.codprov=c.codprov) And (t.numerod=C.numerod)),0) Else 0 End) AS MtoGravable_IVA, 
 (Case when P.TipoPrv=0 Then
 C.Signo*IsNull((Select top 1 t.Monto 
  From  SATAXCOM t WITH (NOLOCK) 
  Where (t.codtaxs='IVA') And (t.codprov=c.codprov) And 
       (t.TIPOCOM=C.TIPOCOM) and (t.codSucu=c.codsucu) And (t.numerod=C.numerod)),0) Else 0 End) As Monto_IVA,
 (Case when P.TipoPrv=0 Then
 IsNull((Select top 1 t.MtoTax 
  From  SATAXCOM t WITH (NOLOCK) 
  Where (t.codtaxs='IVA') And (t.TIPOCOM=C.TIPOCOM) And 
   (t.codprov=c.codprov) And (t.codSucu=c.codsucu) And (t.numerod=C.numerod)),0) Else 0 End) As Alicuota_IVA,
 (Case when P.TipoPrv=1 Then
  C.Signo*isnull((Select top 1 t.tgravable 
    From SATAXCOM T WITH (NOLOCK) 
    Where (t.codtaxs='IVA') And (t.TIPOCOM=C.TIPOCOM) And 
   (t.codprov=c.codprov) And (t.codSucu=c.codsucu) And (t.numerod=C.numerod)),0) Else 0 End) AS MtoGravableImpo_IVA, 
 (Case when P.TipoPrv=1 Then
 C.Signo*IsNull((Select Top 1 T.Monto 
                   From SATAXCOM T WITH (NOLOCK) 
                  Where (T.Codtaxs='IVA') And (t.codprov=c.codprov) And 
                        (T.TIPOCOM=C.TIPOCOM) and (t.codSucu=c.codsucu) And (t.numerod=C.numerod)),0) Else 0 End) As MontoImpo_IVA,
 (Case when P.TipoPrv=1 Then
       IsNull((Select top 1 t.MtoTax 
  From  SATAXCOM t WITH (NOLOCK) 
  Where (t.codtaxs='IVA') And (t.TIPOCOM=C.TIPOCOM) And 
   (t.codprov=c.codprov) And (t.codSucu=c.codsucu) And (t.numerod=C.numerod)),0) Else 0 End) As AlicuotaImpo_IVA, (Case when P.TipoPrv=0 Then
  C.Signo*isnull((Select top 1 t.tgravable 
    From SATAXCOM T WITH (NOLOCK) 
    Where (t.codtaxs='IVA5') And (t.TIPOCOM=C.TIPOCOM) And 
   (t.codSucu=c.codsucu) And (t.codprov=c.codprov) And (t.numerod=C.numerod)),0) Else 0 End) AS MtoGravable_IVA5, 
 (Case when P.TipoPrv=0 Then
 C.Signo*IsNull((Select top 1 t.Monto 
  From  SATAXCOM t WITH (NOLOCK) 
  Where (t.codtaxs='IVA5') And (t.codprov=c.codprov) And 
       (t.TIPOCOM=C.TIPOCOM) and (t.codSucu=c.codsucu) And (t.numerod=C.numerod)),0) Else 0 End) As Monto_IVA5,
 (Case when P.TipoPrv=0 Then
 IsNull((Select top 1 t.MtoTax 
  From  SATAXCOM t WITH (NOLOCK) 
  Where (t.codtaxs='IVA5') And (t.TIPOCOM=C.TIPOCOM) And 
   (t.codprov=c.codprov) And (t.codSucu=c.codsucu) And (t.numerod=C.numerod)),0) Else 0 End) As Alicuota_IVA5,
 (Case when P.TipoPrv=1 Then
  C.Signo*isnull((Select top 1 t.tgravable 
    From SATAXCOM T WITH (NOLOCK) 
    Where (t.codtaxs='IVA5') And (t.TIPOCOM=C.TIPOCOM) And 
   (t.codprov=c.codprov) And (t.codSucu=c.codsucu) And (t.numerod=C.numerod)),0) Else 0 End) AS MtoGravableImpo_IVA5, 
 (Case when P.TipoPrv=1 Then
 C.Signo*IsNull((Select Top 1 T.Monto 
                   From SATAXCOM T WITH (NOLOCK) 
                  Where (T.Codtaxs='IVA5') And (t.codprov=c.codprov) And 
                        (T.TIPOCOM=C.TIPOCOM) and (t.codSucu=c.codsucu) And (t.numerod=C.numerod)),0) Else 0 End) As MontoImpo_IVA5,
 (Case when P.TipoPrv=1 Then
       IsNull((Select top 1 t.MtoTax 
  From  SATAXCOM t WITH (NOLOCK) 
  Where (t.codtaxs='IVA5') And (t.TIPOCOM=C.TIPOCOM) And 
   (t.codprov=c.codprov) And (t.codSucu=c.codsucu) And (t.numerod=C.numerod)),0) Else 0 End) As AlicuotaImpo_IVA5, C.Signo*C.RetenIVA AS RetencionIVA,
 (Case when C.MtoTax<>C.RetenIVA Then C.Signo*(C.MtoTax-C.RetenIVA)
  Else 0 End) As DifRetencion,
 (Case when C.MtoTax<>0 Then C.Signo*Round(C.RetenIVA/C.MtoTax*100,2) 
  Else 0 End) As PorctReten,
 C.NUMEROR AS NRORETENCION,
 C.fechaR  As FechaRetencion,
 C.NroUnico As NroUnico
FROM SACOMP C WITH (NOLOCK) 
 LEFT JOIN SAPROV P ON
   C.CodProv = P.CodProv
WHERE (C.TipoCom IN ('H', 'I'))
UNION ALL
(SELECT 
   '1' AS DBZ,
   T.CODSUCU,
   T.TipoCxP AS Tipo, 
   (CASE WHEN T.TipoCxP='10' THEN '01-REG' 
         WHEN T.TipoCxP='30' THEN '03-REG' 
         WHEN T.TipoCxP='81' THEN '03-REG' 
         WHEN T.TipoCxP='82' THEN '03-REG' 
         WHEN SUBSTRING(T.TipoCxP,1,1)='2' THEN '02-REG' END) AS Reg,
   T.FechaE,  
   T.FechaI, 
   T.FechaT, 
   T.ID3, 
   P.CODPROV, 
   T.Descrip, 
   (Case when P.TipoPrv=1 Then (Select RIF     From SACONF WITH (NOLOCK)) ELSE T.ID3 END) AS ID3Ex, 
   (Case when P.TipoPrv=1 Then (Select Descrip From SACONF WITH (NOLOCK)) ELSE T.Descrip END) AS DescripEx, 
   T.CodOper,
   (CASE WHEN T.TipoCxP='10' THEN 'FAC' 
         WHEN T.TipoCxP='30' THEN 'N/C' 
         WHEN T.TipoCxP='81' THEN 'RET' 
         WHEN T.TipoCxP='82' THEN 'RET' 
         WHEN T.TipoCxP='21' THEN 'N/D' END) AS TIPODOC,
   T.NUMEROD,
   T.NumeroN, 
   T.NroCtrol, 
   Null As Planilla_Import,
   T.Monto*(CASE WHEN P.TipoPrv=0 THEN
                      (CASE WHEN T.TipoCxP in ('10','30') THEN 1 ELSE - 1 END) 
            ELSE 0 END) AS TotalNac, 
   T.Monto*(CASE WHEN P.TipoPrv = 1 THEN
                      (CASE WHEN T.TipoCxP in ('10','30') THEN 1 ELSE - 1 END) 
            ELSE 0 END) AS TotalExt, 
   T.MontoNETO*(CASE WHEN T.TipoCxP in ('10','30') THEN 1 ELSE - 1 END) AS TOTALCOMPRA,
   (T.MontoNeto+T.MtoTax)*(CASE WHEN T.TipoCxP in ('10','30') THEN 1 
                                WHEN T.TipoCxP in ('81')        THEN 0 
                                ELSE - 1 END) AS TOTALCOMPRACONIVA,
   T.MtoTax*(CASE WHEN T.TipoCxP in ('10','30') THEN 1 
                  WHEN T.TipoCxP in ('81') THEN 0 
                  ELSE - 1 END) AS TOTALALICUOTA, 
   (CASE WHEN T.TipoCxP in ('10','30') THEN 1 
         WHEN T.TipoCxP in ('81') THEN 0 
         ELSE - 1 END)*
   ((CASE WHEN T.MontoNeto=0 THEN
               T.MONTO-(CASE WHEN T.ORGTAX=0 THEN T.MTOTAX ELSE T.OrgTax END)
                          ELSE T.MontoNETO END)-T.BaseImpo),
   (CASE WHEN T.TipoCxP in ('10','30') THEN 1 ELSE - 1 END)*T.BaseImpo, (Case when P.TipoPrv=0 Then
   (CASE WHEN T.TipoCxP in ('10','30') THEN 1 ELSE - 1 END)*
    IsNull((Select top 1 tP.tgravable 
       From SATAXCXP TP WITH (NOLOCK) 
       Where (tp.codtaxs='IAL') And 
   (tp.nroppal=T.nrounico)),0) Else 0 End) AS MtoGravable_IAL, 
 (Case when P.TipoPrv=0 Then
   (CASE WHEN T.TipoCxP in ('10','30') THEN 1 ELSE - 1 END)*
    IsNull((Select top 1 tP.Monto 
             From  SATAXCXP tP WITH (NOLOCK) 
             Where (tP.codtaxs='IAL') And 
  (tp.nroppal=T.nrounico)),0) Else 0 End) As Monto_IAL,
 (Case when P.TipoPrv=0 Then
   (CASE WHEN T.TipoCxP in ('10','30') THEN 1 ELSE - 1 END)*
    IsNull((Select top 1 tP.MtoTax 
             From  SATAXCXP tP WITH (NOLOCK) 
             Where (tP.codtaxs='IAL') And 
   (tp.nroppal=T.nrounico)),0) Else 0 End) As Alicuota_IAL,
 (Case when P.TipoPrv=1 Then
   (CASE WHEN T.TipoCxP in ('10','30') THEN 1 ELSE - 1 END)*
    IsNull((Select top 1 tP.tgravable 
       From SATAXCXP TP WITH (NOLOCK) 
       Where (tp.codtaxs='IAL') And 
   (tp.nroppal=T.nrounico)),0) Else 0 End) AS MtoGravableImpo_IAL, 
 (Case when P.TipoPrv=1 Then
   (CASE WHEN T.TipoCxP in ('10','30') THEN 1 ELSE - 1 END)*
    IsNull((Select top 1 tP.Monto 
             From  SATAXCXP tP WITH (NOLOCK) 
             Where (tP.codtaxs='IAL') And 
  (tp.nroppal=T.nrounico)),0) Else 0 End) As MontoImpo_IAL,
 (Case when P.TipoPrv=1 Then
   (CASE WHEN T.TipoCxP in ('10','30') THEN 1 ELSE - 1 END)*
    IsNull((Select top 1 tP.MtoTax 
             From  SATAXCXP tP WITH (NOLOCK) 
             Where (tP.codtaxs='IAL') And 
   (tp.nroppal=T.nrounico)),0) Else 0 End) As AlicuotaImpo_IAL,
 (Case when P.TipoPrv=0 Then
   (CASE WHEN T.TipoCxP in ('10','30') THEN 1 ELSE - 1 END)*
    IsNull((Select top 1 tP.tgravable 
       From SATAXCXP TP WITH (NOLOCK) 
       Where (tp.codtaxs='IVA') And 
   (tp.nroppal=T.nrounico)),0) Else 0 End) AS MtoGravable_IVA, 
 (Case when P.TipoPrv=0 Then
   (CASE WHEN T.TipoCxP in ('10','30') THEN 1 ELSE - 1 END)*
    IsNull((Select top 1 tP.Monto 
             From  SATAXCXP tP WITH (NOLOCK) 
             Where (tP.codtaxs='IVA') And 
  (tp.nroppal=T.nrounico)),0) Else 0 End) As Monto_IVA,
 (Case when P.TipoPrv=0 Then
   (CASE WHEN T.TipoCxP in ('10','30') THEN 1 ELSE - 1 END)*
    IsNull((Select top 1 tP.MtoTax 
             From  SATAXCXP tP WITH (NOLOCK) 
             Where (tP.codtaxs='IVA') And 
   (tp.nroppal=T.nrounico)),0) Else 0 End) As Alicuota_IVA,
 (Case when P.TipoPrv=1 Then
   (CASE WHEN T.TipoCxP in ('10','30') THEN 1 ELSE - 1 END)*
    IsNull((Select top 1 tP.tgravable 
       From SATAXCXP TP WITH (NOLOCK) 
       Where (tp.codtaxs='IVA') And 
   (tp.nroppal=T.nrounico)),0) Else 0 End) AS MtoGravableImpo_IVA, 
 (Case when P.TipoPrv=1 Then
   (CASE WHEN T.TipoCxP in ('10','30') THEN 1 ELSE - 1 END)*
    IsNull((Select top 1 tP.Monto 
             From  SATAXCXP tP WITH (NOLOCK) 
             Where (tP.codtaxs='IVA') And 
  (tp.nroppal=T.nrounico)),0) Else 0 End) As MontoImpo_IVA,
 (Case when P.TipoPrv=1 Then
   (CASE WHEN T.TipoCxP in ('10','30') THEN 1 ELSE - 1 END)*
    IsNull((Select top 1 tP.MtoTax 
             From  SATAXCXP tP WITH (NOLOCK) 
             Where (tP.codtaxs='IVA') And 
   (tp.nroppal=T.nrounico)),0) Else 0 End) As AlicuotaImpo_IVA,
 (Case when P.TipoPrv=0 Then
   (CASE WHEN T.TipoCxP in ('10','30') THEN 1 ELSE - 1 END)*
    IsNull((Select top 1 tP.tgravable 
       From SATAXCXP TP WITH (NOLOCK) 
       Where (tp.codtaxs='IVA5') And 
   (tp.nroppal=T.nrounico)),0) Else 0 End) AS MtoGravable_IVA5, 
 (Case when P.TipoPrv=0 Then
   (CASE WHEN T.TipoCxP in ('10','30') THEN 1 ELSE - 1 END)*
    IsNull((Select top 1 tP.Monto 
             From  SATAXCXP tP WITH (NOLOCK) 
             Where (tP.codtaxs='IVA5') And 
  (tp.nroppal=T.nrounico)),0) Else 0 End) As Monto_IVA5,
 (Case when P.TipoPrv=0 Then
   (CASE WHEN T.TipoCxP in ('10','30') THEN 1 ELSE - 1 END)*
    IsNull((Select top 1 tP.MtoTax 
             From  SATAXCXP tP WITH (NOLOCK) 
             Where (tP.codtaxs='IVA5') And 
   (tp.nroppal=T.nrounico)),0) Else 0 End) As Alicuota_IVA5,
 (Case when P.TipoPrv=1 Then
   (CASE WHEN T.TipoCxP in ('10','30') THEN 1 ELSE - 1 END)*
    IsNull((Select top 1 tP.tgravable 
       From SATAXCXP TP WITH (NOLOCK) 
       Where (tp.codtaxs='IVA5') And 
   (tp.nroppal=T.nrounico)),0) Else 0 End) AS MtoGravableImpo_IVA5, 
 (Case when P.TipoPrv=1 Then
   (CASE WHEN T.TipoCxP in ('10','30') THEN 1 ELSE - 1 END)*
    IsNull((Select top 1 tP.Monto 
             From  SATAXCXP tP WITH (NOLOCK) 
             Where (tP.codtaxs='IVA5') And 
  (tp.nroppal=T.nrounico)),0) Else 0 End) As MontoImpo_IVA5,
 (Case when P.TipoPrv=1 Then
   (CASE WHEN T.TipoCxP in ('10','30') THEN 1 ELSE - 1 END)*
    IsNull((Select top 1 tP.MtoTax 
             From  SATAXCXP tP WITH (NOLOCK) 
             Where (tP.codtaxs='IVA5') And 
   (tp.nroppal=T.nrounico)),0) Else 0 End) As AlicuotaImpo_IVA5,
 (CASE WHEN T.TipoCxP in ('10','30','81') THEN 1 ELSE - 1 END)*T.RetenIVA AS RetencionIVA,
 (CASE when T.RetenIVA<>0 Then
      (CASE WHEN T.TipoCxP in ('10','30','81') THEN 1 ELSE - 1 END)*
      (T.MtoTax-T.RetenIVA)
   Else 0 End) As DifRetencion,
 (Case when T.MtoTax<>0 Then
     (CASE WHEN T.TipoCxP in ('10','30','81') THEN 1 ELSE - 1 END)*
     Round(T.RetenIVA/T.MtoTax*100,2)
  Else 0 End) As PorctReten,
 (CASE WHEN T.TipoCxP IN ('10','30') THEN 
            (SELECT TOP 1 NUMEROD FROM SAACXP WHERE NROREGI=T.NROUNICO AND TIPOCXP='81')
       WHEN T.TipoCxP='81' THEN T.NUMEROD 
  ELSE NULL END) AS NRORETENCION,
 (CASE WHEN T.TipoCxP IN ('10','30') THEN T.fechaR 
       WHEN T.TipoCxP='81' THEN T.FECHAE 
  ELSE NULL END) AS FechaRetencion,
 T.NroUnico As NroUnico
 FROM SAACXP T WITH (NOLOCK) 
 LEFT JOIN SAPROV P ON 
  (T.CodProv = P.CodProv)
 WHERE (T.FROMTRAN = 1) AND (T.EsLibroI = 1) AND 
       (T.TipoCxP IN ('10','21','30','81','82')))
go

