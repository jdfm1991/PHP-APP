CREATE FUNCTION [dbo].[costos]
(
@codprod as varchar(max),
@codubic as varchar(max)
)
RETURNS decimal(28,4)
AS
BEGIN
       declare @result as decimal;

       select
       @result =
       sum(
       case when cantempaq > 0 then (saexis.exunidad + (saexis.Existen * cantempaq)) * (saprod_01.costo/cantempaq)
       else saexis.Existen * saprod_01.costo end
       )
       from saexis
       inner join saprod on saexis.CodProd = saprod.codprod
       inner join saprod_01 on saexis.codprod = saprod_01.codprod
       where SAEXIS.CodProd = @codprod and SAEXIS.CodUbic = @codubic


return @result;
END
go

