-- =============================================
-- Autor:		<Pablo De Genaro>
-- Fecha de Creacion: <05/05/2020>
-- Modificado date: 07/09/2020>
-- Descripcion:	<Trigger que almacena el detalle de la nota de entrea en SAITEMNOTA>
-- =============================================
CREATE TRIGGER [dbo].[DETALLENOTA]
   ON  [dbo].[SAITEMFAC]
   AFTER INSERT
AS
BEGIN
/* VARIBLES GENERALES DE LA OPERACION*/
DECLARE 
@NUMEROD AS VARCHAR(MAX), @TIPO AS VARCHAR(MAX), @CODITEM AS VARCHAR(MAX), @DESCRIPCION AS VARCHAR(MAX), @LINEA AS INT, @CANTIDAD AS DECIMAL(28,4), @TOTALITEM AS DECIMAL(28,4), @ESUNIDAD AS SMALLINT, 
@ESEXENTO AS SMALLINT, @CODVEND AS VARCHAR(MAX), @FECHA AS DATETIME, @TIPOPVP AS SMALLINT, @PRECIO1B AS DECIMAL(28,4), @PRECIO1P AS DECIMAL(28,4), @PRECIO2B AS DECIMAL(28,4), @PRECIO2P AS DECIMAL(28,4),
@PRECIO3B AS DECIMAL(28,4), @PRECIO3P AS DECIMAL(28,4), @MTOTAL AS DECIMAL(28,4), @TOTALITEMFINAL AS DECIMAL(28,4), @DESCUENTOBS AS DECIMAL(28,4), @TOTALDESCUENTOPRD AS DECIMAL(28,4), 
@PORCENTAJE AS DECIMAL(28,4), @PRICEO AS DECIMAL(28,4), @DESCUENTOFAC AS DECIMAL(28,4), @TOTALPRDFAC AS DECIMAL(28,4), @TOTALPRDFACD AS DECIMAL(28,4), @PORCENTAJET AS DECIMAL(28,4), @TOTALD AS DECIMAL(28,4),
@MTOTALDESCUENTO AS DECIMAL(28,4), @MTOTALDESCUENTOFINAL AS DECIMAL(28,4), @TOTALITEM1B AS DECIMAL(28,4), @TOTALITEM2B AS DECIMAL(28,4), @TOTALITEM3B AS DECIMAL(28,4), @TOTALITEM1P AS DECIMAL(28,4),
@TOTALITEM2P AS DECIMAL(28,4), @TOTALITEM3P AS DECIMAL(28,4), @DESCUENTOBS1 AS DECIMAL(28,4)


/* PROCESO DE OBTENCION DE DATOS DE CADA LINEA DE ITEM PARA INSERTAR*/
SELECT @NUMEROD = numerod, @TIPO = TipoFac, @CODITEM = CodItem, @DESCRIPCION = Descrip1, @LINEA = NroLinea,  @CANTIDAD = Cantidad, @ESUNIDAD = EsUnid,  @ESEXENTO = EsExento, @CODVEND = CodVend, @FECHA = FechaE, @TIPOPVP = TipoPVP from inserted

/* llENAMOS LAS VARIABLES DE PRECIOS*/
SELECT @PRECIO1B = Precio1_B, @PRECIO2B = Precio2_B, @PRECIO3B = Precio3_B from SAPROD_01 where CodProd= @CODITEM
SELECT @PRECIO1P = Precio1_P, @PRECIO2P = Precio2_P, @PRECIO3P = Precio3_P  from SAPROD_01 where CodProd= @CODITEM

/* PROCESO DE TOTALIZACION DE LINEA POR ITEM*/
SET @TOTALITEM1B = (@CANTIDAD * @PRECIO1B)
SET @TOTALITEM2B = (@CANTIDAD * @PRECIO2B)
SET @TOTALITEM3B = (@CANTIDAD * @PRECIO3B)

SET @TOTALITEM1P = (@CANTIDAD * @PRECIO1P)
SET @TOTALITEM2P = (@CANTIDAD * @PRECIO2P)
SET @TOTALITEM3P = (@CANTIDAD * @PRECIO3P)


/* PROCESO DE OBTENCION DE LOS DESCUENTOS POR ITEM*/
SELECT @DESCUENTOBS1 = Descto from inserted
IF (@DESCUENTOBS1 < 0)
	BEGIN
		SET @DESCUENTOBS = (@DESCUENTOBS1 * -1)
	END
ELSE
	BEGIN
		SET @DESCUENTOBS = @DESCUENTOBS1
	END


SELECT @PRICEO = PriceO from inserted

SELECT @DESCUENTOFAC = Descto1, @TOTALPRDFAC = TotalPrd FROM SAFACT WHERE NUMEROD = @NUMEROD and TipoFac = @TIPO


/* CONDICION TIPO DE DOCUMENTO NOTA O DEVOLUCION */
IF (@TIPO ='C' OR @TIPO ='D')
    BEGIN
	    IF (@PRICEO >0)
		    BEGIN
			    SET @PORCENTAJE = (@DESCUENTOBS * 100) / @PRICEO
		    END
	    ELSE
		    BEGIN
			    SET @PORCENTAJE = 0
		    END
/*CONDICION TIPO DE UNIDAD DE MEDIDA SI ES PAQUETE */
        IF (@ESUNIDAD = 1)
            BEGIN
		        IF (@TIPOPVP = 1)
			        BEGIN
				        IF (@PORCENTAJE > 0)
					        BEGIN
						        SET @TOTALDESCUENTOPRD = ((@TOTALITEM1P * @PORCENTAJE) / 100)
						        SET @TOTALITEMFINAL =   @TOTALITEM1P - @TOTALDESCUENTOPRD
					        END
				        ELSE
					        BEGIN
						        SET @TOTALITEMFINAL =  @TOTALITEM1P
					        END
										
                            INSERT INTO [SAITEMNOTA] (numerod, tipofac, coditem, descripcion, nrolinea, cantidad, precio, totalitem, esunidad, esexento, codvend, fechae, tipopvp, descuento, total)
                            VALUES (@NUMEROD, @TIPO, @CODITEM, @DESCRIPCION, @LINEA, @CANTIDAD, @PRECIO1P, @TOTALITEM1P, @ESUNIDAD, @ESEXENTO, @CODVEND, @FECHA, @TIPOPVP, @TOTALDESCUENTOPRD,@TOTALITEMFINAL)
                    END
		        ELSE IF (@TIPOPVP = 2)
			        BEGIN
				        IF (@PORCENTAJE > 0)
					        BEGIN
						        SET @TOTALDESCUENTOPRD = ((@TOTALITEM2P * @PORCENTAJE) / 100)
						        SET @TOTALITEMFINAL =   @TOTALITEM2P - @TOTALDESCUENTOPRD
					        END
				        ELSE
					        BEGIN
						        SET @TOTALITEMFINAL =  @TOTALITEM2P
					        END
				
                            INSERT INTO [SAITEMNOTA] (numerod, tipofac, coditem, descripcion, nrolinea, cantidad, precio, totalitem, esunidad, esexento, codvend, fechae, tipopvp, descuento, total)
                            VALUES (@NUMEROD, @TIPO, @CODITEM, @DESCRIPCION, @LINEA, @CANTIDAD, @PRECIO2P, @TOTALITEM2P, @ESUNIDAD, @ESEXENTO, @CODVEND, @FECHA, @TIPOPVP, @TOTALDESCUENTOPRD,@TOTALITEMFINAL)
                    END
		        ELSE
			        BEGIN
				        IF (@PORCENTAJE > 0)
					        BEGIN
						        SET @TOTALDESCUENTOPRD = ((@TOTALITEM3P * @PORCENTAJE) / 100)
						        SET @TOTALITEMFINAL =   @TOTALITEM3P - @TOTALDESCUENTOPRD
					        END
				        ELSE
					        BEGIN
						        SET @TOTALITEMFINAL =  @TOTALITEM3P
				            END
				
                            INSERT INTO [SAITEMNOTA] (numerod, tipofac, coditem, descripcion, nrolinea, cantidad, precio, totalitem, esunidad, esexento, codvend, fechae, tipopvp, descuento, total)
                            VALUES (@NUMEROD, @TIPO, @CODITEM, @DESCRIPCION, @LINEA, @CANTIDAD, @PRECIO3P, @TOTALITEM3P, @ESUNIDAD, @ESEXENTO, @CODVEND, @FECHA, @TIPOPVP, @TOTALDESCUENTOPRD,@TOTALITEMFINAL)
			        END
            END
	/*FIN CONDICION TIPO DE UNIDAD DE MEDIDA PAQUETE */
	/*CONDICION TIPO DE UNIDAD DE MEDIDA SI ES BULTO */
	    ELSE
	        BEGIN
		        IF (@TIPOPVP = 1)
			        BEGIN
				        IF (@PORCENTAJE > 0)
					        BEGIN
						        SET @TOTALDESCUENTOPRD = ((@TOTALITEM1B * @PORCENTAJE) / 100)
						        SET @TOTALITEMFINAL =   @TOTALITEM1B - @TOTALDESCUENTOPRD
					        END
				        ELSE
					        BEGIN
					        	SET @TOTALITEMFINAL =  @TOTALITEM1B
					        END
				
                            INSERT INTO [SAITEMNOTA] (numerod, tipofac, coditem, descripcion, nrolinea, cantidad, precio, totalitem, esunidad, esexento, codvend, fechae, tipopvp,  descuento, total)
                            VALUES (@NUMEROD, @TIPO, @CODITEM, @DESCRIPCION, @LINEA, @CANTIDAD, @PRECIO1B, @TOTALITEM1B, @ESUNIDAD, @ESEXENTO, @CODVEND, @FECHA, @TIPOPVP, @TOTALDESCUENTOPRD,@TOTALITEMFINAL)
			        END
		        ELSE IF (@TIPOPVP = 2)
			        BEGIN
				        IF @PORCENTAJE > 0
					        BEGIN
						        SET @TOTALDESCUENTOPRD = ((@TOTALITEM2B * @PORCENTAJE) / 100)
						        SET @TOTALITEMFINAL =   @TOTALITEM2B - @TOTALDESCUENTOPRD
					        END
				        ELSE
					        BEGIN
					        	SET @TOTALITEMFINAL =  @TOTALITEM2B
					        END
				
                            INSERT INTO [SAITEMNOTA] (numerod, tipofac, coditem, descripcion, nrolinea, cantidad, precio, totalitem, esunidad, esexento, codvend, fechae, tipopvp, descuento, total)
                            VALUES (@NUMEROD, @TIPO, @CODITEM, @DESCRIPCION, @LINEA, @CANTIDAD, @PRECIO2B, @TOTALITEM2B, @ESUNIDAD, @ESEXENTO, @CODVEND, @FECHA, @TIPOPVP, @TOTALDESCUENTOPRD,@TOTALITEMFINAL)
                    END
		        ELSE
			        BEGIN
				        IF (@PORCENTAJE > 0)
				        	BEGIN
						        SET @TOTALDESCUENTOPRD = ((@TOTALITEM3B * @PORCENTAJE) / 100)
						        SET @TOTALITEMFINAL =   @TOTALITEM3B - @TOTALDESCUENTOPRD
					        END
				        ELSE
					        BEGIN
						        SET @TOTALITEMFINAL =  @TOTALITEM3B
					        END
				
                            INSERT INTO [SAITEMNOTA] (numerod, tipofac, coditem, descripcion, nrolinea, cantidad, precio, totalitem, esunidad, esexento, codvend, fechae, tipopvp, descuento, total)
                            VALUES (@NUMEROD, @TIPO, @CODITEM, @DESCRIPCION, @LINEA, @CANTIDAD, @PRECIO3B, @TOTALITEM3B, @ESUNIDAD, @ESEXENTO, @CODVEND, @FECHA, @TIPOPVP, @TOTALDESCUENTOPRD,@TOTALITEMFINAL)
			        END
            END
				/*FIN CONDICION TIPO DE UNIDAD DE MEDIDA BULTO */


				/*CALCULO PARA EL SUBTOTAL DE SANOTA */
				BEGIN
					SET @MTOTAL = (SELECT sum(total) as total FROM saitemnota WHERE numerod =@NUMEROD AND TIPOFAC = @TIPO)
					UPDATE SANOTA SET subtotal = @MTOTAL where numerod = @NUMEROD AND TIPOFAC = @TIPO
				END					
					
				
				BEGIN
					SELECT @TOTALPRDFACD = subtotal FROM SANOTA WHERE NUMEROD = @NUMEROD and TipoFac = @TIPO
					SET @PORCENTAJET = (@DESCUENTOFAC * 100) / @TOTALPRDFAC
					
					IF (@PORCENTAJET > 0)
						BEGIN
							SET @TOTALD = (( @TOTALPRDFACD * @PORCENTAJET) / 100)
							SET @MTOTAL =   @TOTALPRDFACD - @TOTALD
						END
					ELSE
						BEGIN
							SET @MTOTAL = @TOTALPRDFACD
						END
						END

					UPDATE SANOTA SET TOTAL = @MTOTAL, descuento = @TOTALD where numerod = @NUMEROD AND TIPOFAC = @TIPO
				END
				SET NOCOUNT ON;
END
go

disable trigger DETALLENOTA on SAITEMFAC
go

