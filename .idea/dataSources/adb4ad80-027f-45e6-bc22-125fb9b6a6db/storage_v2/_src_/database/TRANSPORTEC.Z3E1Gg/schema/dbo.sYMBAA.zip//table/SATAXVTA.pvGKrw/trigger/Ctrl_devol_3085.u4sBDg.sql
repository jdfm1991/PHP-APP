
CREATE trigger [dbo].[Ctrl_devol_3085]
on [dbo].[SATAXVTA]
after insert
as


declare 
@NumeroR varchar(50),
@NumeroDD varchar(50),
@MtoImp decimal(24,4),
@CodTax varchar(50),
@TipoFac varchar(2)

--select @NumeroR = NumeroR from inserted;
select @NumeroDD = NumeroD from inserted;
select @TipoFac = TipoFac from inserted;





if @TipoFac = 'B'

begin
select @NumeroR = NumeroR from SAFACT where TipoFac = @TipoFac and NumeroD = @NumeroDD;
select @MtoImp = MtoTax  from sataxvta where NumeroD = @NumeroR and TipoFac = 'A';
select @CodTax = CodTaxs  from sataxvta where NumeroD = @NumeroR and TipoFac = 'A';

begin

--select @NumeroR, @MtoImp, @CodTax

update SATAXVTA set CodTaxs = @CodTax, Monto = TGravable*(@MtoImp/100), MtoTax = @MtoImp
where NumeroD = @NumeroDD and TipoFac = @TipoFac and CodTaxs in ('IVA9', 'IVA7', 'IVA')

begin

update safact set MtoTax = (SELECT SUM(Monto) FROM SATAXVTA WHERE NumeroD = @NumeroDD AND TipoFac = @TipoFac)
WHERE NumeroD = @NumeroDD AND TipoFac = @TipoFac

BEGIN

UPDATE SAFACT SET MtoTotal = Monto+MtoTax, Credito = MtoTotal-Contado, Contado = MtoTotal-Credito
where NumeroD = @NumeroDD AND TipoFac = @TipoFac

END
end
end
end
go

