-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[saldo] 
   ON  [dbo].[SAACXC]
   AFTER INSERT,DELETE,UPDATE
AS 
BEGIN
/* PROCESO PARA ACTUALIZAR LOS SALDOS DEL ESTADO DE CUENTA DEL CLIENTES */
	   DECLARE @CodProv    varchar(15)
       DECLARE @ActProv    varchar(15)
       DECLARE @Monto      decimal(28,4)
       DECLARE @NroUnico   INT
       DECLARE @Saldo      decimal(28,4)
       DECLARE @FECHAE     datetime
       DECLARE @NumeroD    varchar(10)
       DECLARE @TipoCxC    varchar(2)
       DECLARE @Saldoact   decimal(28,4)
       DECLARE @FACTOR     SMALLINT
       DECLARE @Saldoant   DECIMAL(28,4)
	   DECLARE @pago	   DECIMAL(28,4) 	
       DECLARE @CLIENTE	   VARCHAR(25)
	   /* CURSOR PRINCIPAL PARA OBTENER EL CLIENTE */
set @CLIENTE = (SELECT TOP 1 CodClie FROM inserted)
	   DECLARE MProv CURSOR FOR
       SELECT A.CodClie
       FROM SACLIE A--, SAACXP as B
       Where A.CodClie = @CLIENTE
       Order By A.CodClie
       OPEN MProv
       FETCH NEXT FROM MProv INTO @ACTProv
       	WHILE @@FETCH_STATUS=0 BEGIN
       	   SET @SALDOANT=0 
		   SET @PAGO=0
                  DECLARE MCURSOR CURSOR FOR
                  SELECT A.CodClie, A.FechaE, A.NroUnico, A.NumeroD,
                         A.TipoCxc, A.Monto,  A.Saldo,    A.Saldoact
                  FROM SAACXC as A
       	   Where A.CodClie = @ActProv
                  ORDER BY /*CodClie, A.FechaE*/ A.NroUnico
                  OPEN Mcursor
                  FETCH NEXT FROM Mcursor INTO @CodProv, @FECHAE, @NroUnico, @NumeroD,
                                            @TipoCxC, @Monto,  @Saldo,    @Saldoact
                  WHILE (@@FETCH_STATUS<>-1)
                   BEGIN
                     IF (@@FETCH_STATUS<>-2)
                        BEGIN
                          SET @FACTOR=CASE @TIPOCxC
                                       WHEN '10' THEN 1
                                       --WHEN '21' THEN -1
                                       --WHEN '30' THEN 1
                                       WHEN '41' THEN -1
                                       WHEN '20' THEN 1
                                       WHEN '31' THEN -1
                                       --WHEN '82' THEN 1
                                       WHEN '81' THEN -1  
                                      END
                          IF (@TIPOCxC<>'50' )
							IF (@TipoCxC='41')
								begin
									UPDATE SAACXC SET Monto= CancelT+CancelC+CancelE where TipoCxc=41 and CodClie=@ActProv
								end
                             SET @SALDOANT=@SALDOANT+@FACTOR*@MONTO
						  UPDATE SAACXC
                          SET SALDOACT = @saldoant
                          WHERE NroUnico = @NroUnico
						--  SELECT @Saldoant,@Saldoact,@TipoCxC,@NumeroD,@Monto,@NroUnico,@SALDOANT+@FACTOR*@MONTO
                        END
                     FETCH NEXT
                     FROM Mcursor
                     INTO @Codprov, @FECHAE, @NroUnico, @NumeroD,
                          @TipoCxC, @Monto,  @Saldo, @Saldoact
                   END
                  CLOSE MCursor
                  DEALLOCATE MCursor
       	   FETCH NEXT FROM MProv INTO @ACTProv
       END
       CLOSE MProv
       DEALLOCATE MProv
END
go

